﻿using System;using System.Diagnostics;
using System.Threading.Tasks;
using Microsoft.Web.WebView2.Wpf;
using Microsoft.Web.WebView2.Core;

namespace AlertAutomator._02_LatoFunzioni._01_SistemaPuliziaPrePartenza
{
    /// <summary>
    /// FILE: sistemapuliziaprepartenza.cs
    /// SCOPO: Sistema di pulizia ULTRA POTENZIATO per WebView2
    /// VERSIONE: 3.0 DEFINITIVA - COPIATO PARI PARI DAL MAKER
    /// </summary>
    public class SistemaPuliziaPrePartenza
    {
        #region Campi Privati
        
        private WebView2 _webView;
        private string _sessionIdCorrente;
        private int _secondiRimanenti;
        private const string URL_TRADINGVIEW = "https://www.tradingview.com/chart/";
        private static bool _puliziaInCorso = false;
        private static SistemaPuliziaPrePartenza _instance;
        
        #endregion

        #region Eventi e Proprietà Statiche

        /// <summary>
        /// Evento per notificare inizio/fine pulizia
        /// </summary>
        public static event EventHandler<bool> StatoPuliziaCambiato;

        /// <summary>
        /// Proprietà per verificare se pulizia in corso
        /// </summary>
        public static bool IsPuliziaInCorso => _puliziaInCorso;
        
        /// <summary>
        /// Singleton instance
        /// </summary>
        public static SistemaPuliziaPrePartenza Instance
        {
            get
            {
                if (_instance == null)
                    _instance = new SistemaPuliziaPrePartenza();
                return _instance;
            }
        }
        
        /// <summary>
        /// Metodo pubblico per notificare cambio stato dall'esterno
        /// </summary>
        public static void NotificaCambioStato(bool inCorso)
        {
            _puliziaInCorso = inCorso;
            StatoPuliziaCambiato?.Invoke(null, inCorso);
        }

        #endregion

        #region Inizializzazione

        /// <summary>
        /// Inizializza il servizio di pulizia con riferimento al WebView2
        /// </summary>
        public void Inizializza(WebView2 webView)
        {
            _webView = webView;
            Debug.WriteLine("PuliziaWebView2: Sistema ULTRA POTENZIATO inizializzato");
        }

        /// <summary>
        /// Ottiene WebView2 dall'applicazione se non inizializzato
        /// </summary>
        private bool OttieniWebView()
        {
            if (_webView != null && _webView.CoreWebView2 != null)
                return true;
                
            try
            {
                // Cerca WebView2 nella finestra principale
                var mainWindow = System.Windows.Application.Current.MainWindow;
                if (mainWindow != null)
                {
                    _webView = TrovaWebView2(mainWindow);
                    if (_webView != null && _webView.CoreWebView2 != null)
                    {
                        Debug.WriteLine("PuliziaWebView2: WebView2 trovato automaticamente");
                        return true;
                    }
                }
            }
            catch { }
            
            return false;
        }

        private WebView2 TrovaWebView2(System.Windows.DependencyObject parent)
        {
            if (parent == null) return null;
            
            if (parent is WebView2 webView)
                return webView;
                
            int childCount = System.Windows.Media.VisualTreeHelper.GetChildrenCount(parent);
            for (int i = 0; i < childCount; i++)
            {
                var child = System.Windows.Media.VisualTreeHelper.GetChild(parent, i);
                var result = TrovaWebView2(child);
                if (result != null) return result;
            }
            
            return null;
        }

        #endregion

        #region Metodo Principale

        /// <summary>
        /// Esegue pulizia ULTRA COMPLETA mantenendo sessionId
        /// </summary>
        public async Task<bool> EseguiPuliziaCompleta(string sessionIdDaMantenere = null)
        {
            try
            {
                // Imposta flag e notifica inizio pulizia
                _puliziaInCorso = true;
                StatoPuliziaCambiato?.Invoke(null, true);
                
                Debug.WriteLine("╔═══════════════════════════════════════════════════════╗");
                Debug.WriteLine("║   PULIZIA ULTRA POTENZIATA v3.0 - INIZIO PROCEDURA   ║");
                Debug.WriteLine("╚═══════════════════════════════════════════════════════╝");
                
                // Validazione WebView2
                if (!OttieniWebView())
                {
                    Debug.WriteLine("PuliziaWebView2: ❌ WebView2 non inizializzato");
                    _puliziaInCorso = false;
                    StatoPuliziaCambiato?.Invoke(null, false);
                    return false;
                }
                
                _sessionIdCorrente = sessionIdDaMantenere;
                
                // STEP 1: COUNTDOWN 15 SECONDI
                Debug.WriteLine("PULIZIA - Avvio countdown 15 secondi");
                await AvviaCountdown();
                
                // STEP 2: SALVA SESSIONE E DATI CRITICI
                string sessionIdSalvato = null;
                string urlCorrente = _webView.Source?.ToString();
                
                if (!string.IsNullOrEmpty(_sessionIdCorrente))
                {
                    sessionIdSalvato = await SalvaSessionId();
                    Debug.WriteLine($"PULIZIA - SessionId salvato: {sessionIdSalvato?.Substring(0, Math.Min(10, sessionIdSalvato.Length))}...");
                }
                
                // STEP 3: PULIZIA JAVASCRIPT PROFONDA
                Debug.WriteLine("PULIZIA - Esecuzione pulizia JavaScript profonda...");
                await PuliziaJavaScriptProfonda();
                
                // STEP 4: PULIZIA CACHE ULTRA COMPLETA
                Debug.WriteLine("PULIZIA - Avvio pulizia cache TOTALE...");
                await PulisciCacheUltraCompleta();
                
                // STEP 5: PULIZIA COOKIE SELETTIVA
                Debug.WriteLine("PULIZIA - Pulizia cookie selettiva...");
                await PulisciCookieSelettivi();
                
                // STEP 6: GARBAGE COLLECTION FORZATO
                Debug.WriteLine("PULIZIA - Garbage Collection .NET e JavaScript...");
                await ForzaGarbageCollectionCompleto();
                
                // STEP 7: REFRESH BROWSER
                Debug.WriteLine("PULIZIA - Refresh browser eseguito");
                _webView.Reload();
                
                // STEP 8: ATTESA CARICAMENTO
                Debug.WriteLine("PULIZIA - Attesa caricamento pagina (3 secondi)...");
                await Task.Delay(3000);
                
                // STEP 9: RIPRISTINA SESSIONID
                if (!string.IsNullOrEmpty(sessionIdSalvato))
                {
                    await RipristinaSessionId(sessionIdSalvato);
                    Debug.WriteLine("PULIZIA - SessionId ripristinato");
                }
                
                // STEP 10: VERIFICA SESSIONE
                bool sessioneOk = await VerificaSessione();
                if (!sessioneOk)
                {
                    Debug.WriteLine("PULIZIA - ⚠️ ATTENZIONE: Sessione potrebbe essere persa");
                }
                else
                {
                    Debug.WriteLine("PULIZIA - ✅ Sessione mantenuta correttamente");
                }
                
                // STEP 11: VERIFICA MEMORIA FINALE
                await VerificaMemoria();
                
                Debug.WriteLine("╔═══════════════════════════════════════════════════════╗");
                Debug.WriteLine("║   PULIZIA ULTRA POTENZIATA - COMPLETATA CON SUCCESSO  ║");
                Debug.WriteLine("╚═══════════════════════════════════════════════════════╝");
                
                // Reset flag e notifica fine pulizia
                _puliziaInCorso = false;
                StatoPuliziaCambiato?.Invoke(null, false);
                
                return true;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"PULIZIA - ❌ ERRORE CRITICO: {ex.Message}");
                Debug.WriteLine($"PULIZIA - StackTrace: {ex.StackTrace}");
                
                // Reset flag anche in caso di errore
                _puliziaInCorso = false;
                StatoPuliziaCambiato?.Invoke(null, false);
                
                return false;
            }
        }

        #endregion

        #region Metodi di Pulizia

        /// <summary>
        /// Pulizia cache ULTRA COMPLETA
        /// </summary>
        private async Task PulisciCacheUltraCompleta()
        {
            try
            {
                var profile = _webView.CoreWebView2.Profile;
                if (profile != null)
                {
                    await profile.ClearBrowsingDataAsync(
                        CoreWebView2BrowsingDataKinds.AllDomStorage |
                        CoreWebView2BrowsingDataKinds.DiskCache |
                        CoreWebView2BrowsingDataKinds.LocalStorage |
                        CoreWebView2BrowsingDataKinds.CacheStorage |
                        CoreWebView2BrowsingDataKinds.FileSystems |
                        CoreWebView2BrowsingDataKinds.IndexedDb |
                        CoreWebView2BrowsingDataKinds.WebSql |
                        CoreWebView2BrowsingDataKinds.ServiceWorkers
                    );
                    
                    Debug.WriteLine("PULIZIA - ✅ Cache ULTRA pulita (10 tipologie)");
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"PULIZIA - ⚠️ Errore pulizia cache: {ex.Message}");
            }
        }

        /// <summary>
        /// Pulizia JavaScript PROFONDA
        /// </summary>
        private async Task PuliziaJavaScriptProfonda()
        {
            try
            {
                string scriptPulizia = @"
                    (function() {
                        try {
                            var cleanedCount = 0;
                            
                            // Pulisci variabili globali non essenziali
                            var keysToDelete = [];
                            for (var key in window) {
                                if (!key.match(/^(document|window|navigator|location|history|screen|console|chrome|CSS|TV|tradingview|Chart)/i) &&
                                    typeof window[key] !== 'function' &&
                                    !key.startsWith('__')) {
                                    keysToDelete.push(key);
                                }
                            }
                            
                            keysToDelete.forEach(function(key) {
                                try { 
                                    delete window[key]; 
                                    cleanedCount++;
                                } catch(e) {}
                            });
                            
                            // Clear tutti i timer
                            var highestTimeoutId = setTimeout(';');
                            for (var i = 0; i < highestTimeoutId; i++) {
                                clearTimeout(i);
                            }
                            
                            var highestIntervalId = setInterval(';');
                            for (var j = 0; j < highestIntervalId; j++) {
                                clearInterval(j);
                            }
                            
                            // Clear console
                            if (console.clear) console.clear();
                            
                            // Clear performance entries
                            if (performance && performance.clearMarks) {
                                performance.clearMarks();
                                performance.clearMeasures();
                                performance.clearResourceTimings();
                            }
                            
                            // Clear sessionStorage e localStorage
                            if (sessionStorage) sessionStorage.clear();
                            if (localStorage) localStorage.clear();
                            
                            // Rimuovi event listeners orfani
                            var allElements = document.querySelectorAll('*');
                            allElements.forEach(function(el) {
                                if (!el.id?.includes('tradingview') && 
                                    !el.className?.includes('tv-') &&
                                    !el.className?.includes('chart')) {
                                    var clone = el.cloneNode(true);
                                    if (el.parentNode) {
                                        try {
                                            el.parentNode.replaceChild(clone, el);
                                        } catch(e) {}
                                    }
                                }
                            });
                            
                            // Clear WebWorkers cache
                            if ('caches' in window) {
                                caches.keys().then(function(names) {
                                    names.forEach(function(name) {
                                        caches.delete(name);
                                    });
                                });
                            }
                            
                            return 'Pulizia JS completata. Elementi puliti: ' + cleanedCount;
                        } catch(e) {
                            return 'Errore pulizia JS: ' + e.message;
                        }
                    })();
                ";
                
                var risultato = await _webView.CoreWebView2.ExecuteScriptAsync(scriptPulizia);
                Debug.WriteLine($"PULIZIA - JavaScript: {risultato?.Trim('"')}");
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"PULIZIA - ⚠️ Errore pulizia JS: {ex.Message}");
            }
        }

        /// <summary>
        /// Garbage Collection completo
        /// </summary>
        private async Task ForzaGarbageCollectionCompleto()
        {
            try
            {
                // GC .NET - Triplo passaggio
                for (int i = 0; i < 3; i++)
                {
                    GC.Collect(GC.MaxGeneration, GCCollectionMode.Forced, true);
                    GC.WaitForPendingFinalizers();
                }
                GC.Collect();
                
                // GC JavaScript
                string scriptGC = @"
                    (function() {
                        if (window.gc) {
                            window.gc();
                            window.gc();
                            return 'GC JavaScript eseguito';
                        }
                        return 'GC non disponibile (normale in produzione)';
                    })();
                ";
                
                var risultato = await _webView.CoreWebView2.ExecuteScriptAsync(scriptGC);
                Debug.WriteLine($"PULIZIA - GC: {risultato?.Trim('"')}");
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"PULIZIA - ⚠️ Errore GC: {ex.Message}");
            }
        }

        /// <summary>
        /// Pulisce cookie selettivamente
        /// </summary>
        private async Task PulisciCookieSelettivi()
        {
            try
            {
                var cookieManager = _webView.CoreWebView2.CookieManager;
                var cookies = await cookieManager.GetCookiesAsync("https://www.tradingview.com");
                
                int cookieRimossi = 0;
                foreach (var cookie in cookies)
                {
                    if (cookie.Name != "sessionid" && 
                        !cookie.Name.StartsWith("tv_") &&
                        !cookie.Name.Contains("chart"))
                    {
                        cookieManager.DeleteCookie(cookie);
                        cookieRimossi++;
                    }
                }
                
                Debug.WriteLine($"PULIZIA - Cookie rimossi: {cookieRimossi} (sessionId preservato)");
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"PULIZIA - ⚠️ Errore pulizia cookie: {ex.Message}");
            }
        }

        #endregion

        #region Metodi Helper

        /// <summary>
        /// Countdown 15 secondi
        /// </summary>
        private async Task AvviaCountdown()
        {
            try
            {
                _secondiRimanenti = 15;
                
                while (_secondiRimanenti > 0)
                {
                    if (_secondiRimanenti == 15)
                    {
                        Debug.WriteLine("PULIZIA - Countdown: 15 secondi - INIZIO PULIZIA");
                    }
                    else if (_secondiRimanenti == 10)
                    {
                        Debug.WriteLine("PULIZIA - Countdown: 10 secondi - 10 sec to GO");
                    }
                    else if (_secondiRimanenti == 5)
                    {
                        Debug.WriteLine("PULIZIA - Countdown: 5 secondi - Facendo il pieno di 100 ottani");
                    }
                    else if (_secondiRimanenti <= 3)
                    {
                        Debug.WriteLine($"PULIZIA - Countdown: {_secondiRimanenti} secondi rimanenti");
                    }
                    
                    await Task.Delay(1000);
                    _secondiRimanenti--;
                }
                
                Debug.WriteLine("PULIZIA - Countdown: 0 secondi - COUNTDOWN COMPLETATO");
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"PULIZIA - Errore countdown: {ex.Message}");
            }
        }

        /// <summary>
        /// Salva sessionId
        /// </summary>
        private async Task<string> SalvaSessionId()
        {
            try
            {
                string script = @"
                    (function() {
                        var cookies = document.cookie.split(';');
                        for (var i = 0; i < cookies.length; i++) {
                            var cookie = cookies[i].trim();
                            if (cookie.startsWith('sessionid=')) {
                                return cookie.substring(10);
                            }
                        }
                        return '';
                    })();
                ";
                
                var risultato = await _webView.CoreWebView2.ExecuteScriptAsync(script);
                return risultato?.Trim('"') ?? "";
            }
            catch
            {
                return "";
            }
        }

        /// <summary>
        /// Ripristina sessionId
        /// </summary>
        private async Task RipristinaSessionId(string sessionId)
        {
            try
            {
                if (string.IsNullOrEmpty(sessionId)) return;
                
                string script = $@"
                    document.cookie = 'sessionid={sessionId}; domain=.tradingview.com; path=/; secure; samesite=none';
                ";
                
                await _webView.CoreWebView2.ExecuteScriptAsync(script);
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"PULIZIA - ⚠️ Errore ripristino sessionId: {ex.Message}");
            }
        }

        /// <summary>
        /// Verifica sessione
        /// </summary>
        private async Task<bool> VerificaSessione()
        {
            try
            {
                string scriptVerifica = @"
                    (function() {
                        try {
                            var userMenu = document.querySelector('[data-name=""header-user-menu""]');
                            var signInButton = document.querySelector('[data-name=""header-user-menu-sign-in""]');
                            var isLoggedIn = userMenu && !signInButton;
                            
                            return JSON.stringify({
                                loggedIn: isLoggedIn,
                                hasUserMenu: !!userMenu,
                                hasSignInButton: !!signInButton
                            });
                        } catch(e) {
                            return JSON.stringify({
                                error: e.toString()
                            });
                        }
                    })();
                ";

                string risultato = await _webView.CoreWebView2.ExecuteScriptAsync(scriptVerifica);
                risultato = risultato.Trim('"').Replace("\\\"", "\"");
                
                bool isLoggedIn = risultato.Contains("\"loggedIn\":true");
                return isLoggedIn;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"PULIZIA - Errore verifica sessione: {ex.Message}");
                return false;
            }
        }

        /// <summary>
        /// Verifica memoria
        /// </summary>
        private async Task VerificaMemoria()
        {
            try
            {
                string scriptMemoria = @"
                    (function() {
                        var info = {
                            memoria: 'N/D',
                            heap: 'N/D'
                        };
                        
                        if (performance && performance.memory) {
                            var mb = 1024 * 1024;
                            info.memoria = Math.round(performance.memory.usedJSHeapSize / mb) + ' MB';
                            info.heap = Math.round(performance.memory.totalJSHeapSize / mb) + ' MB';
                        }
                        
                        return JSON.stringify(info);
                    })();
                ";
                
                var risultato = await _webView.CoreWebView2.ExecuteScriptAsync(scriptMemoria);
                Debug.WriteLine($"PULIZIA - Memoria JS: {risultato?.Trim('"')}");
                
                var memoriaProcesso = GC.GetTotalMemory(false) / (1024 * 1024);
                Debug.WriteLine($"PULIZIA - Memoria .NET: {memoriaProcesso} MB");
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"PULIZIA - ⚠️ Errore verifica memoria: {ex.Message}");
            }
        }

       
        #endregion

        #region Pulizia all'avvio

        /// <summary>
        /// Esegue pulizia automatica all'avvio dell'applicazione
        /// </summary>
        public static async Task EseguiPuliziaAvvio()
        {
            try
            {
                var pulizia = Instance;
                Console.WriteLine("╔═══════════════════════════════════════════════════════╗");
                Console.WriteLine("║     PULIZIA AUTOMATICA ALL'AVVIO DELL'APPLICAZIONE    ║");
                Console.WriteLine("╚═══════════════════════════════════════════════════════╝");
                
                await pulizia.EseguiPuliziaCompleta();
                
                Console.WriteLine("Pulizia all'avvio completata");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Errore pulizia all'avvio: {ex.Message}");
            }
        }

        #endregion
    }
}
using System;using System.Diagnostics; // Sistema base
using System.Threading.Tasks; // Task asincroni
using Microsoft.Web.WebView2.Wpf; // WebView2
using Microsoft.Web.WebView2.Core; // Core WebView2


namespace AlertAutomator._02_LatoFunzioni._02_EngineAutomation._02_AzioniProduzione._03_ClickOk._02_VerificaDialog
{
    /// <summary>
    /// Verifica presenza dialog parametri
    /// </summary>
    public class VerificaDialog
    {
        #region Metodo Principale

        /// <summary>
        /// Verifica se il dialog parametri � presente
        /// </summary>
        public static async Task<(bool successo, bool dialogPresente)> Esegui(WebView2 webView)
        {
            try
            {
                Debug.WriteLine("VERIFICA DIALOG: Inizio verifica presenza dialog"); // Log

                // Validazione WebView
                if (webView?.CoreWebView2 == null)
                {
                    Debug.WriteLine("VERIFICA DIALOG ERRORE: WebView non valido"); // Log errore
                    return (false, false); // Fallimento
                }

                // Script per verificare presenza dialog
                string scriptVerificaDialog = @"
                    (function() {
                        try {
                            console.log('Verifica Dialog - Inizio ricerca');
                            
                            // Selettore principale del dialog
                            var dialogSelector = '#overlap-manager-root > div:nth-child(3) > div > div.dialog-qyCw0PaN.dialog-b8SxMnzX.dialog-aRAWUDhF.rounded-aRAWUDhF.shadowed-aRAWUDhF > div > div.scrollable-vwgPOHG8 > div';
                            var dialog = document.querySelector(dialogSelector);
                            
                            if (dialog) {
                                console.log('Verifica Dialog - Dialog trovato');
                                return JSON.stringify({
                                    success: true,
                                    found: true,
                                    info: 'Dialog parametri trovato'
                                });
                            }
                            
                            // Prova selettore alternativo pi� generico
                            var dialogAlt = document.querySelector('[class*=""dialog-qyCw0PaN""]');
                            if (dialogAlt) {
                                console.log('Verifica Dialog - Dialog trovato con selettore alternativo');
                                return JSON.stringify({
                                    success: true,
                                    found: true,
                                    info: 'Dialog trovato con selettore alternativo'
                                });
                            }
                            
                            console.log('Verifica Dialog - Dialog non trovato');
                            return JSON.stringify({
                                success: true,
                                found: false,
                                info: 'Dialog non presente'
                            });
                            
                        } catch (e) {
                            return JSON.stringify({
                                success: false,
                                found: false,
                                error: e.toString()
                            });
                        }
                    })();
                "; // Fine script

                // Esegui script
                Debug.WriteLine("VERIFICA DIALOG: Esecuzione script verifica..."); // Log
                string risultatoJson = await webView.CoreWebView2.ExecuteScriptAsync(scriptVerificaDialog); // Esegui
                
                // Pulisci risultato
                risultatoJson = risultatoJson.Trim('"').Replace("\\\"", "\""); // Pulisci
                Debug.WriteLine($"VERIFICA DIALOG: Risultato raw: {risultatoJson}"); // Log debug

                // Parse risultato
                bool success = risultatoJson.Contains("\"success\":true"); // Verifica successo
                bool found = risultatoJson.Contains("\"found\":true"); // Verifica presenza
                
                if (!success)
                {
                    Debug.WriteLine("VERIFICA DIALOG ERRORE: Script verifica fallito"); // Log errore
                    return (false, false); // Fallimento
                }

                if (found)
                {
                    Debug.WriteLine("VERIFICA DIALOG: ? Dialog parametri presente"); // Log successo
                    return (true, true); // Successo, dialog presente
                }
                else
                {
                    Debug.WriteLine("VERIFICA DIALOG: Dialog non trovato"); // Log
                    
                    // Debug DOM se non trovato
                    string scriptDebug = @"
                        (function() {
                            var info = 'Debug DOM - ';
                            var root = document.querySelector('#overlap-manager-root');
                            if (root) {
                                info += 'Root trovato. ';
                                var children = root.children.length;
                                info += 'Figli: ' + children + '. ';
                            } else {
                                info += 'Root non trovato. ';
                            }
                            var dialogs = document.querySelectorAll('[class*=""dialog""]');
                            info += 'Dialogs con class: ' + dialogs.length;
                            return info;
                        })();
                    "; // Script debug
                    
                    string debugInfo = await webView.CoreWebView2.ExecuteScriptAsync(scriptDebug); // Debug
                    Debug.WriteLine($"VERIFICA DIALOG DEBUG: {debugInfo}"); // Log debug
                    
                    return (true, false); // Successo verifica, dialog non presente
                }

            }
            catch (Exception ex)
            {
                Debug.WriteLine($"VERIFICA DIALOG ERRORE: {ex.Message}"); // Log errore
                return (false, false); // Fallimento
            }
        }

        #endregion

        #region Helper

      

        #endregion
    }
}
﻿using System;using System.Diagnostics; // Sistema base
using System.Threading.Tasks; // Task asincroni
using Microsoft.Web.WebView2.Wpf; // WebView2
using Microsoft.Web.WebView2.Core; // Core WebView2
using System.Diagnostics; // per debugwriteline

namespace AlertAutomator._02_LatoFunzioni._02_EngineAutomation._02_AzioniProduzione._03_ClickOk._01_CollegatiAlBroswer
{
    /// <summary>
    /// Verifica collegamento al browser
    /// </summary>
    public class CollegatiAlBrowser
    {
        #region Metodo Principale

        /// <summary>
        /// Verifica che WebView sia collegato e pronto
        /// </summary>
        public static async Task<bool> Esegui(WebView2 webView)
        {
            try
            {
                Debug.WriteLine("COLLEGATI BROWSER: Inizio verifica collegamento"); // Log

                // Validazione WebView
                if (webView == null)
                {
                    Debug.WriteLine("COLLEGATI BROWSER ERRORE: WebView nullo"); // Log errore
                    return false; // Fallimento
                }

                // Verifica CoreWebView2
                if (webView.CoreWebView2 == null)
                {
                    Debug.WriteLine("COLLEGATI BROWSER ERRORE: CoreWebView2 non inizializzato"); // Log errore
                    return false; // Fallimento
                }

                // Test esecuzione script semplice
                string scriptTest = @"
                    (function() {
                        return 'browser_ready';
                    })();
                "; // Script test

                try
                {
                    string risultato = await webView.CoreWebView2.ExecuteScriptAsync(scriptTest); // Test
                    risultato = risultato.Trim('"'); // Pulisci

                    if (risultato == "browser_ready")
                    {
                        Debug.WriteLine("COLLEGATI BROWSER: ✓ Browser collegato e pronto"); // Log successo
                        
                        // Attendi per stabilizzazione
                        await Task.Delay(50); // Pausa
                        
                        return true; // Successo
                    }
                    else
                    {
                        Debug.WriteLine($"COLLEGATI BROWSER ERRORE: Risultato inatteso: {risultato}"); // Log errore
                        return false; // Fallimento
                    }
                }
                catch (Exception scriptEx)
                {
                    Debug.WriteLine($"COLLEGATI BROWSER ERRORE: Script test fallito - {scriptEx.Message}"); // Log errore
                    return false; // Fallimento
                }

            }
            catch (Exception ex)
            {
                Debug.WriteLine($"COLLEGATI BROWSER ERRORE: {ex.Message}"); // Log errore
                return false; // Fallimento
            }
        }

        #endregion

        #region Helper

     
        #endregion
    }
}
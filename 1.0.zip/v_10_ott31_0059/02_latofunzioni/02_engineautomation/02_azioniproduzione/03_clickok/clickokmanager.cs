﻿using AlertAutomator._02_LatoFunzioni._02_EngineAutomation._02_AzioniProduzione._03_ClickOk._01_CollegatiAlBroswer;
using AlertAutomator._02_LatoFunzioni._02_EngineAutomation._02_AzioniProduzione._03_ClickOk._02_VerificaDialog;
using AlertAutomator._02_LatoFunzioni._02_EngineAutomation._02_AzioniProduzione._03_ClickOk._03_VerificaPulsanteOk;
using AlertAutomator._02_LatoFunzioni._02_EngineAutomation._02_AzioniProduzione._03_ClickOk._04_CliccaOk;
using AlertAutomator._02_LatoFunzioni._02_EngineAutomation._02_AzioniProduzione._03_ClickOk._05_VerificaChiusuraDialog;
using Microsoft.Web.WebView2.Wpf;
using System;
using System.Diagnostics;
using System.Diagnostics;
using System.Threading.Tasks;

namespace AlertAutomator._02_LatoFunzioni._02_EngineAutomation._02_AzioniProduzione._03_ClickOk
{
    public class ClickOkManager
    {
        public static async Task<bool> Esegui(WebView2 webView)
        {
            try
            {
                if (webView == null)
                {
                    Debug.WriteLine("[CLICK OK MANAGER] ERRORE: WebView nullo");
                    return false;
                }

                Debug.WriteLine("----------------------------------------------------");
                Debug.WriteLine("[CLICK OK MANAGER] FASE 1: Collegati al browser");

                var successo1 = await CollegatiAlBrowser.Esegui(webView);
                if (!successo1)
                {
                    Debug.WriteLine("[CLICK OK MANAGER] ERRORE: Fase 1 fallita");
                    return false;
                }

                Debug.WriteLine("----------------------------------------------------");
                Debug.WriteLine("[CLICK OK MANAGER] FASE 2: Verifica presenza dialog");

                var (successo2, dialogPresente) = await VerificaDialog.Esegui(webView);
                if (!successo2 || !dialogPresente)
                {
                    Debug.WriteLine("[CLICK OK MANAGER] ERRORE: Dialog non trovato");
                    return false;
                }

                Debug.WriteLine("----------------------------------------------------");
                Debug.WriteLine("[CLICK OK MANAGER] FASE 3: Verifica pulsante OK");

                var (successo3, pulsantePresente) = await VerificaPulsanteOk.Esegui(webView);
                if (!successo3 || !pulsantePresente)
                {
                    Debug.WriteLine("[CLICK OK MANAGER] ERRORE: Pulsante OK non trovato");
                    return false;
                }

                Debug.WriteLine("----------------------------------------------------");
                Debug.WriteLine("[CLICK OK MANAGER] FASE 4: Clicca OK");

                var successo4 = await CliccaOk.Esegui(webView);
                if (!successo4)
                {
                    Debug.WriteLine("[CLICK OK MANAGER] ERRORE: Click notgo");
                    return false;
                }

                Debug.WriteLine("----------------------------------------------------");
                Debug.WriteLine("[CLICK OK MANAGER] FASE 5: Verifica chiusura dialog");

                var (successo5, dialogChiuso) = await VerificaChiusuraDialog.Esegui(webView);
                if (!successo5 || !dialogChiuso)
                {
                    Debug.WriteLine("[CLICK OK MANAGER] WARNING: Dialog non chiuso completamente");
                }

                Debug.WriteLine("----------------------------------------------------");
                Debug.WriteLine("[CLICK OK MANAGER] ✓ Processo completato con successo!");
                Debug.WriteLine("----------------------------------------------------");

                return true;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[CLICK OK MANAGER] ERRORE CRITICO: {ex.Message}");
                Debug.WriteLine("----------------------------------------------------");
                return false;
            }
        }
    }
}
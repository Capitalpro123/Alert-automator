using System;using System.Diagnostics; // Sistema base
using System.Threading.Tasks; // Task asincroni
using Microsoft.Web.WebView2.Wpf; // WebView2
using Microsoft.Web.WebView2.Core; // Core WebView2


namespace AlertAutomator._02_LatoFunzioni._02_EngineAutomation._02_AzioniProduzione._03_ClickOk._04_CliccaOk
{
    /// <summary>
    /// Clicca il pulsante OK
    /// </summary>
    public class CliccaOk
    {
        #region Metodo Principale

        /// <summary>
        /// Esegue click sul pulsante OK
        /// </summary>
        public static async Task<bool> Esegui(WebView2 webView)
        {
            try
            {
                Debug.WriteLine("CLICCA OK: Inizio click pulsante"); // Log

                // Validazione WebView
                if (webView?.CoreWebView2 == null)
                {
                    Debug.WriteLine("CLICCA OK ERRORE: WebView non valido"); // Log errore
                    return false; // Fallimento
                }

                // Script per cliccare OK
                string scriptClickOk = @"
                    (function() {
                        try {
                            console.log('Clicca OK - Inizio ricerca e click');
                            
                            // Prova selettore principale
                            var button = document.querySelector('#overlap-manager-root > div:nth-child(3) > div > div.dialog-qyCw0PaN.dialog-b8SxMnzX.dialog-aRAWUDhF.rounded-aRAWUDhF.shadowed-aRAWUDhF > div > div.footer-PhMf7PhQ > div > span > button');
                            
                            // Se non trovato, prova selettore alternativo
                            if (!button) {
                                console.log('Clicca OK - Provo selettore alternativo');
                                button = document.querySelector('#overlap-manager-root > div:nth-child(3) > div > div.dialog-qyCw0PaN.dialog-b8SxMnzX.dialog-aRAWUDhF.rounded-aRAWUDhF.shadowed-aRAWUDhF > div > div.footer-PhMf7PhQ > div > button.button-xNqEcuN2.size-medium-xNqEcuN2.variant-primary-xNqEcuN2.color-brand-xNqEcuN2.apply-overflow-tooltip.dialogButtons-89_pADJo');
                            }
                            
                            // Se ancora non trovato, cerca per testo
                            if (!button) {
                                console.log('Clicca OK - Cerco per testo');
                                var footer = document.querySelector('#overlap-manager-root > div:nth-child(3) > div > div.dialog-qyCw0PaN.dialog-b8SxMnzX.dialog-aRAWUDhF.rounded-aRAWUDhF.shadowed-aRAWUDhF > div > div.footer-PhMf7PhQ');
                                if (footer) {
                                    var buttons = footer.querySelectorAll('button');
                                    for (var i = 0; i < buttons.length; i++) {
                                        var btn = buttons[i];
                                        var text = btn.textContent.trim();
                                        if (text.toLowerCase() === 'ok' || text === 'OK' || text === 'Ok') {
                                            button = btn;
                                            console.log('Clicca OK - Trovato per testo');
                                            break;
                                        }
                                    }
                                }
                            }
                            
                            if (button) {
                                console.log('Clicca OK - Pulsante trovato, eseguo click');
                                button.click();
                                return JSON.stringify({
                                    success: true,
                                    clicked: true,
                                    info: 'Click eseguito con successo'
                                });
                            }
                            
                            console.log('Clicca OK - Pulsante non trovato');
                            return JSON.stringify({
                                success: true,
                                clicked: false,
                                info: 'Pulsante non trovato'
                            });
                            
                        } catch (e) {
                            return JSON.stringify({
                                success: false,
                                clicked: false,
                                error: e.toString()
                            });
                        }
                    })();
                "; // Fine script

                // Esegui script
                Debug.WriteLine("CLICCA OK: Esecuzione click..."); // Log
                string risultatoJson = await webView.CoreWebView2.ExecuteScriptAsync(scriptClickOk); // Esegui
                
                // Pulisci risultato
                risultatoJson = risultatoJson.Trim('"').Replace("\\\"", "\""); // Pulisci
                Debug.WriteLine($"CLICCA OK: Risultato raw: {risultatoJson}"); // Log debug

                // Parse risultato
                bool success = risultatoJson.Contains("\"success\":true"); // Verifica successo
                bool clicked = risultatoJson.Contains("\"clicked\":true"); // Verifica click
                
                if (!success)
                {
                    Debug.WriteLine("CLICCA OK ERRORE: Script click fallito"); // Log errore
                    return false; // Fallimento
                }

                if (clicked)
                {
                    Debug.WriteLine("CLICCA OK: ? Click eseguito con successo"); // Log successo
                    
                    // Attendi elaborazione
                    await Task.Delay(100); // Pausa
                    
                    return true; // Successo
                }
                else
                {
                    Debug.WriteLine("CLICCA OK ERRORE: Pulsante non trovato per il click"); // Log errore
                    return false; // 
                }

            }
            catch (Exception ex)
            {
                Debug.WriteLine($"CLICCA OK ERRORE: {ex.Message}"); // Log errore
                return false; // Fallimento
            }
        }

        #endregion

        #region Helper

      

        #endregion
    }
}
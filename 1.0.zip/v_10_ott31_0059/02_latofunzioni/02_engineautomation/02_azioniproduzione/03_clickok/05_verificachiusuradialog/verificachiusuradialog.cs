using System;using System.Diagnostics; // Sistema base
using System.Threading.Tasks; // Task asincroni
using Microsoft.Web.WebView2.Wpf; // WebView2
using Microsoft.Web.WebView2.Core; // Core WebView2
using System.Diagnostics; // per debugwriteline

namespace AlertAutomator._02_LatoFunzioni._02_EngineAutomation._02_AzioniProduzione._03_ClickOk._05_VerificaChiusuraDialog
{
    /// <summary>
    /// Verifica chiusura dialog dopo click OK
    /// </summary>
    public class VerificaChiusuraDialog
    {
        #region Metodo Principale

        /// <summary>
        /// Verifica che il dialog si sia chiuso
        /// </summary>
        public static async Task<(bool successo, bool dialogChiuso)> Esegui(WebView2 webView)
        {
            try
            {
                Debug.WriteLine("VERIFICA CHIUSURA: Inizio verifica chiusura dialog"); // Log

                // Validazione WebView
                if (webView?.CoreWebView2 == null)
                {
                    Debug.WriteLine("VERIFICA CHIUSURA ERRORE: WebView non valido"); // Log errore
                    return (false, false); // Fallimento
                }

                // Attesa iniziale per permettere animazione chiusura
                await Task.Delay(100); // Pausa

                // Script per verificare chiusura
                string scriptVerificaChiusura = @"
                    (function() {
                        try {
                            // Cerca dialog principale
                            var dialog = document.querySelector('#overlap-manager-root > div:nth-child(3) > div > div.dialog-qyCw0PaN');
                            
                            // Cerca anche con selettore alternativo
                            if (!dialog) {
                                dialog = document.querySelector('[class*=""dialog-qyCw0PaN""]');
                            }
                            
                            if (dialog) {
                                // Verifica se � visibile
                                var style = window.getComputedStyle(dialog);
                                var isVisible = style.display !== 'none' && style.visibility !== 'hidden';
                                
                                if (isVisible) {
                                    return JSON.stringify({
                                        success: true,
                                        closed: false,
                                        info: 'Dialog ancora presente e visibile'
                                    });
                                } else {
                                    return JSON.stringify({
                                        success: true,
                                        closed: true,
                                        info: 'Dialog presente ma nascosto'
                                    });
                                }
                            }
                            
                            // Dialog non trovato = chiuso
                            return JSON.stringify({
                                success: true,
                                closed: true,
                                info: 'Dialog non presente nel DOM'
                            });
                            
                        } catch (e) {
                            return JSON.stringify({
                                success: false,
                                closed: false,
                                error: e.toString()
                            });
                        }
                    })();
                "; // Fine script

                // Attendi con timeout
                int maxTentativi = 10; // Max 10 tentativi
                int tentativi = 0; // Contatore
                bool chiuso = false; // Flag chiusura

                while (tentativi < maxTentativi && !chiuso)
                {
                    // Esegui verifica
                    string risultatoJson = await webView.CoreWebView2.ExecuteScriptAsync(scriptVerificaChiusura); // Verifica
                    
                    // Pulisci risultato
                    risultatoJson = risultatoJson.Trim('"').Replace("\\\"", "\""); // Pulisci
                    
                    // Parse risultato
                    bool success = risultatoJson.Contains("\"success\":true"); // Verifica successo
                    chiuso = risultatoJson.Contains("\"closed\":true"); // Verifica chiusura
                    
                    if (!success)
                    {
                        Debug.WriteLine("VERIFICA CHIUSURA ERRORE: Script verifica fallito"); // Log errore
                        return (false, false); // Fallimento
                    }

                    if (chiuso)
                    {
                        Debug.WriteLine("VERIFICA CHIUSURA: Dialog chiuso con successo"); // Log
                        break; // Esci dal loop
                    }

                    Debug.WriteLine($"VERIFICA CHIUSURA: Dialog ancora aperto, tentativo {tentativi + 1}/{maxTentativi}"); // Log
                    await Task.Delay(100); // Attendi
                    tentativi++; // Incrementa
                }

                if (chiuso)
                {
                    Debug.WriteLine("VERIFICA CHIUSURA: ? Dialog chiuso correttamente"); // Log successo
                    
                    // Attendi stabilizzazione finale
                    await Task.Delay(10); // Pausa finale
                    
                    return (true, true); // Successo
                }
                else
                {
                    Debug.WriteLine("VERIFICA CHIUSURA WARNING: Dialog non chiuso nel tempo previsto"); // Log warning
                    return (true, false); // Successo verifica, dialog non chiuso
                }

            }
            catch (Exception ex)
            {
                Debug.WriteLine($"VERIFICA CHIUSURA ERRORE: {ex.Message}"); // Log errore
                return (false, false); // Fallimento
            }
        }

        #endregion

        #region Helper

        #endregion
    }
}
using System;using System.Diagnostics; // Sistema base
using System.Threading.Tasks; // Task asincroni
using Microsoft.Web.WebView2.Wpf; // WebView2
using Microsoft.Web.WebView2.Core; // Core WebView2


namespace AlertAutomator._02_LatoFunzioni._02_EngineAutomation._02_AzioniProduzione._03_ClickOk._03_VerificaPulsanteOk
{
    /// <summary>
    /// Verifica presenza pulsante OK
    /// </summary>
    public class VerificaPulsanteOk
    {
        #region Metodo Principale

        /// <summary>
        /// Verifica se il pulsante OK � presente
        /// </summary>
        public static async Task<(bool successo, bool pulsantePresente)> Esegui(WebView2 webView)
        {
            try
            {
                Debug.WriteLine("VERIFICA PULSANTE OK: Inizio verifica"); // Log

                // Validazione WebView
                if (webView?.CoreWebView2 == null)
                {
                    Debug.WriteLine("VERIFICA PULSANTE OK ERRORE: WebView non valido"); // Log errore
                    return (false, false); // Fallimento
                }

                // Script per verificare pulsante OK
                string scriptVerificaPulsante = @"
                    (function() {
                        try {
                            console.log('Verifica Pulsante - Inizio ricerca');
                            
                            // Verifica prima il footer
                            var footerSelector = '#overlap-manager-root > div:nth-child(3) > div > div.dialog-qyCw0PaN.dialog-b8SxMnzX.dialog-aRAWUDhF.rounded-aRAWUDhF.shadowed-aRAWUDhF > div > div.footer-PhMf7PhQ';
                            var footer = document.querySelector(footerSelector);
                            
                            if (!footer) {
                                console.log('Verifica Pulsante - Footer non trovato');
                                return JSON.stringify({
                                    success: true,
                                    found: false,
                                    info: 'Footer non presente'
                                });
                            }
                            
                            console.log('Verifica Pulsante - Footer trovato');
                            
                            // Cerca pulsante con selettore principale
                            var buttonSelector = '#overlap-manager-root > div:nth-child(3) > div > div.dialog-qyCw0PaN.dialog-b8SxMnzX.dialog-aRAWUDhF.rounded-aRAWUDhF.shadowed-aRAWUDhF > div > div.footer-PhMf7PhQ > div > span > button';
                            var button = document.querySelector(buttonSelector);
                            
                            if (button) {
                                console.log('Verifica Pulsante - Pulsante trovato con selettore principale');
                                return JSON.stringify({
                                    success: true,
                                    found: true,
                                    text: button.textContent.trim(),
                                    info: 'Pulsante OK trovato'
                                });
                            }
                            
                            // Prova selettore alternativo
                            var buttonAlt = document.querySelector('#overlap-manager-root > div:nth-child(3) > div > div.dialog-qyCw0PaN.dialog-b8SxMnzX.dialog-aRAWUDhF.rounded-aRAWUDhF.shadowed-aRAWUDhF > div > div.footer-PhMf7PhQ > div > button.button-xNqEcuN2.size-medium-xNqEcuN2.variant-primary-xNqEcuN2.color-brand-xNqEcuN2.apply-overflow-tooltip.dialogButtons-89_pADJo');
                            
                            if (buttonAlt) {
                                console.log('Verifica Pulsante - Pulsante trovato con selettore alternativo');
                                return JSON.stringify({
                                    success: true,
                                    found: true,
                                    text: buttonAlt.textContent.trim(),
                                    info: 'Pulsante OK trovato (alt)'
                                });
                            }
                            
                            // Cerca per testo
                            var buttons = footer.querySelectorAll('button');
                            console.log('Verifica Pulsante - Totale bottoni nel footer: ' + buttons.length);
                            
                            for (var i = 0; i < buttons.length; i++) {
                                var btn = buttons[i];
                                var text = btn.textContent.trim();
                                console.log('Verifica Pulsante - Bottone ' + i + ': ' + text);
                                
                                if (text.toLowerCase() === 'ok' || text === 'OK' || text === 'Ok') {
                                    console.log('Verifica Pulsante - Trovato bottone OK per testo!');
                                    return JSON.stringify({
                                        success: true,
                                        found: true,
                                        text: text,
                                        info: 'Pulsante OK trovato per testo'
                                    });
                                }
                            }
                            
                            console.log('Verifica Pulsante - Pulsante OK non trovato');
                            return JSON.stringify({
                                success: true,
                                found: false,
                                info: 'Pulsante OK non trovato'
                            });
                            
                        } catch (e) {
                            return JSON.stringify({
                                success: false,
                                found: false,
                                error: e.toString()
                            });
                        }
                    })();
                "; // Fine script

                // Esegui script
                Debug.WriteLine("VERIFICA PULSANTE OK: Esecuzione script..."); // Log
                string risultatoJson = await webView.CoreWebView2.ExecuteScriptAsync(scriptVerificaPulsante); // Esegui
                
                // Pulisci risultato
                risultatoJson = risultatoJson.Trim('"').Replace("\\\"", "\""); // Pulisci
                Debug.WriteLine($"VERIFICA PULSANTE OK: Risultato raw: {risultatoJson}"); // Log debug

                // Parse risultato
                bool success = risultatoJson.Contains("\"success\":true"); // Verifica successo
                bool found = risultatoJson.Contains("\"found\":true"); // Verifica presenza
                
                if (!success)
                {
                    Debug.WriteLine("VERIFICA PULSANTE OK ERRORE: Script verifica fallito"); // Log errore
                    return (false, false); // Fallimento
                }

                if (found)
                {
                    // Estrai testo pulsante se presente
                    int textStart = risultatoJson.IndexOf("\"text\":\""); // Trova inizio
                    if (textStart > -1)
                    {
                        textStart += 8; // Sposta dopo "text":"
                        int textEnd = risultatoJson.IndexOf("\"", textStart); // Trova fine
                        string buttonText = risultatoJson.Substring(textStart, textEnd - textStart); // Estrai
                        Debug.WriteLine($"VERIFICA PULSANTE OK: ? Pulsante trovato con testo: '{buttonText}'"); // Log
                    }
                    else
                    {
                        Debug.WriteLine("VERIFICA PULSANTE OK: ? Pulsante trovato"); // Log
                    }
                    
                    return (true, true); // Successo, pulsante presente
                }
                else
                {
                    Debug.WriteLine("VERIFICA PULSANTE OK: Pulsante non trovato"); // Log
                    return (true, false); // Successo verifica, pulsante non presente
                }

            }
            catch (Exception ex)
            {
                Debug.WriteLine($"VERIFICA PULSANTE OK ERRORE: {ex.Message}"); // Log errore
                return (false, false); // Fallimento
            }
        }

        #endregion

        #region Helper

      

        #endregion
    }
}
using System;using System.Diagnostics;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading.Tasks;
using Microsoft.Web.WebView2.Wpf;
using AlertAutomator._02_LatoFunzioni._02_EngineAutomation._02_AzioniProduzione._03_ClickOk;
using AlertAutomator._02_LatoFunzioni._02_EngineAutomation._02_AzioniProduzione._04_DialogAlert;
using AlertAutomator._02_LatoFunzioni._02_EngineAutomation._02_AzioniProduzione._01_CtrlP;
using AlertAutomator._02_LatoFunzioni._02_EngineAutomation._02_AzioniProduzione._02_FillParametri;

namespace AlertAutomator.Funzioni.EngineAutomation.AzioneProduzione
{
    public class AzioniProduzioneManager
    {
        public static async Task<bool> Esegui(Dictionary<string, string> riga, int numeroRiga)
        {
            try
            {
                Debug.WriteLine("╔════════════════════════════════════════════════════════╗");
                Debug.WriteLine($"║   AZIONI PRODUZIONE - RIGA {numeroRiga}                     ║");
                Debug.WriteLine("╚════════════════════════════════════════════════════════╝");

                WebView2 webView = GetWebView();
                if (webView == null)
                {
                    Debug.WriteLine("[AZIONI PRODUZIONE] ERRORE: WebView non disponibile");
                    return false;
                }

                Debug.WriteLine($"[AZIONI PRODUZIONE] Elaborazione riga {numeroRiga}");

                // 1. CTRL+P
                Debug.WriteLine("[AZIONI PRODUZIONE] STEP 1: CTRL+P");
                bool ctrlpOk = await CtrlPManager.Esegui(webView);
                if (!ctrlpOk)
                {
                    Debug.WriteLine("[AZIONI PRODUZIONE] ERRORE: CTRL+P fallito");
                    return false;
                }

                // 2. Fill Parametri
                Debug.WriteLine("[AZIONI PRODUZIONE] STEP 2: Fill Parametri");
                bool parametriOk = await FillParametriManager.Esegui(webView, riga);
                if (!parametriOk)
                {
                    Debug.WriteLine("[AZIONI PRODUZIONE] ERRORE: Fill Parametri fallito");
                    return false;
                }

                // 3. Click OK
                Debug.WriteLine("[AZIONI PRODUZIONE] STEP 3: Click OK");
                bool okOk = await ClickOkManager.Esegui(webView);
                if (!okOk)
                {
                    Debug.WriteLine("[AZIONI PRODUZIONE] ERRORE: Click OK fallito");
                    return false;
                }

                // 4. Dialog Alert
                Debug.WriteLine("[AZIONI PRODUZIONE] STEP 4: Dialog Alert");
                bool alertOk = await DialogAlertManager.Esegui(webView, riga);
                if (!alertOk)
                {
                    Debug.WriteLine("[AZIONI PRODUZIONE] ERRORE: Dialog Alert fallito");
                    return false;
                }

                Debug.WriteLine("╔════════════════════════════════════════════════════════╗");
                Debug.WriteLine($"║   AZIONI PRODUZIONE RIGA {numeroRiga} - COMPLETATO          ║");
                Debug.WriteLine("╚════════════════════════════════════════════════════════╝");

                return true;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[AZIONI PRODUZIONE] ERRORE CRITICO: {ex.Message}");
                Debug.WriteLine($"[AZIONI PRODUZIONE] StackTrace: {ex.StackTrace}");
                return false;
            }
        }

       private static WebView2 GetWebView()
{
    try
    {
        Debug.WriteLine("[AZIONI PRODUZIONE] Inizio ricerca WebView...");
        
        var mainWindow = System.Windows.Application.Current.MainWindow;
        if (mainWindow == null)
        {
            Debug.WriteLine("[AZIONI PRODUZIONE] MainWindow non trovata - NOTGO");
            return null;
        }

        Debug.WriteLine("[AZIONI PRODUZIONE] MainWindow trovata, cerco WebView...");

        // Ricerca ricorsiva profonda nel visual tree
        WebView2 webView = TrovaWebViewRicorsivo(mainWindow);
        
        if (webView != null)
        {
            Debug.WriteLine("[AZIONI PRODUZIONE] WebView trovato con successo!");
            return webView;
        }

        Debug.WriteLine("[AZIONI PRODUZIONE] WebView non trovato - NOTGO");
        return null;
    }
    catch (Exception ex)
    {
        Debug.WriteLine($"[AZIONI PRODUZIONE] ERRORE recupero WebView: {ex.Message}");
        return null;
            }
        }

        private static WebView2 TrovaWebViewRicorsivo(System.Windows.DependencyObject parent)
        {
            if (parent == null) return null;

            // Se è già un WebView2, ritornalo
            if (parent is WebView2 webView)
            {
                Debug.WriteLine("[AZIONI PRODUZIONE] WebView2 trovato direttamente!");
                return webView;
            }

            int childCount = System.Windows.Media.VisualTreeHelper.GetChildrenCount(parent);

            for (int i = 0; i < childCount; i++)
            {
                var child = System.Windows.Media.VisualTreeHelper.GetChild(parent, i);

                // Controllo tipo per nome
                if (child.GetType().Name == "_01_webviewmonitor")
                {
                    Debug.WriteLine("[AZIONI PRODUZIONE] Trovato _01_webviewmonitor!");

                    // Cerca il WebView2 al suo interno
                    var webViewInterno = TrovaWebViewRicorsivo(child);
                    if (webViewInterno != null)
                        return webViewInterno;
                }

                // Ricerca ricorsiva
                var risultato = TrovaWebViewRicorsivo(child);
                if (risultato != null)
                {
                    return risultato;
                }
            }

            return null;
        }

    }
}
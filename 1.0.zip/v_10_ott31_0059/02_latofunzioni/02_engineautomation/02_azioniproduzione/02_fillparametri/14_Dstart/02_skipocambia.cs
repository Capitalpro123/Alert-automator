using System;
using System.Diagnostics;
using System.Threading.Tasks;

namespace AlertAutomator._02_LatoFunzioni._02_EngineAutomation._02_AzioniProduzione._02_FillParametri._14_Dstart
{
    public class SkipOCambia
    {
        public static async Task<bool> Decidi(string valoreCorrente, string valoreTarget)
        {
            try
            {
                Debug.WriteLine("[SKIP O CAMBIA DSTART] Confronto valori...");
                Debug.WriteLine($"[SKIP O CAMBIA DSTART] Corrente = '{valoreCorrente}'");
                Debug.WriteLine($"[SKIP O CAMBIA DSTART] Target = '{valoreTarget}'");

                if (valoreCorrente == valoreTarget)
                {
                    Debug.WriteLine("[SKIP O CAMBIA DSTART] Valori identici - SKIP");
                    return false;
                }
                else
                {
                    Debug.WriteLine("[SKIP O CAMBIA DSTART] Valori diversi - CAMBIO NECESSARIO");
                    return true;
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[SKIP O CAMBIA DSTART] ERRORE: {ex.Message}");
                return true;
            }
        }
    }
}
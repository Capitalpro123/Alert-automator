using System;
using System.Diagnostics;
using System.Threading.Tasks;
using Microsoft.Web.WebView2.Wpf;

namespace AlertAutomator._02_LatoFunzioni._02_EngineAutomation._02_AzioniProduzione._02_FillParametri._14_Dstart
{
    public class LeggiValoreCorrente
    {
        public static async Task<string> Esegui(WebView2 webView)
        {
            try
            {
                Debug.WriteLine("[LEGGI VALORE DSTART] Lettura campo div:nth-child(42)...");

                string scriptLeggiValore = @"
                    (function() {
                        var input = document.querySelector('#overlap-manager-root > div:nth-child(3) > div > div.dialog-qyCw0PaN.dialog-b8SxMnzX.dialog-aRAWUDhF.rounded-aRAWUDhF.shadowed-aRAWUDhF > div > div.scrollable-vwgPOHG8 > div > div:nth-child(42) > span:nth-child(1) > div:nth-child(2) > div > span > span.inner-slot-W53jtLjw.inner-middle-slot-W53jtLjw > input');
                        if (input) {
                            console.log('LEGGI VALORE DSTART: Input trovato con selettore child(42)');
                            return input.value || '';
                        }
                        
                        var allInputs = document.querySelectorAll('#overlap-manager-root input');
                        console.log('LEGGI VALORE DSTART: Trovati ' + allInputs.length + ' input totali');
                        
                        var visibleCount = 0;
                        for (var i = 0; i < allInputs.length; i++) {
                            if (allInputs[i].offsetParent !== null) {
                                visibleCount++;
                                if (visibleCount === 14) {
                                    console.log('LEGGI VALORE DSTART: Usando quattordicesimo input visibile');
                                    return allInputs[i].value || '';
                                }
                            }
                        }
                        
                        return 'INPUT_NON_TROVATO';
                    })();
                ";

                var risultato = await webView.ExecuteScriptAsync(scriptLeggiValore);
                risultato = risultato.Trim('"');

                if (risultato == "INPUT_NON_TROVATO")
                {
                    Debug.WriteLine("[LEGGI VALORE DSTART] ERRORE: Input Dstart (child 42) non trovato nel DOM");
                    return null;
                }

                Debug.WriteLine($"[LEGGI VALORE DSTART] Valore letto = '{risultato}'");
                return risultato;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[LEGGI VALORE DSTART] ERRORE: {ex.Message}");
                return null;
            }
        }
    }
}
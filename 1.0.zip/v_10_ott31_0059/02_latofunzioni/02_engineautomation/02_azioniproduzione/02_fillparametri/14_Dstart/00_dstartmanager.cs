using System;
using System.Diagnostics;
using System.Threading.Tasks;
using Microsoft.Web.WebView2.Wpf;

namespace AlertAutomator._02_LatoFunzioni._02_EngineAutomation._02_AzioniProduzione._02_FillParametri._14_Dstart
{
    public class DstartManager
    {
        public static async Task<bool> Esegui(WebView2 webView, string dstartTarget)
        {
            try
            {
                Debug.WriteLine($"[DSTART MANAGER] Valore target: '{dstartTarget}'");

                if (webView == null)
                {
                    Debug.WriteLine("[DSTART MANAGER] ERRORE: WebView nullo");
                    return false;
                }

                if (string.IsNullOrWhiteSpace(dstartTarget))
                {
                    Debug.WriteLine("[DSTART MANAGER] WARNING: Dstart vuoto o nullo, skip");
                    return true;
                }

                Debug.WriteLine("[DSTART MANAGER] Fase 1 - Lettura valore attuale");
                string valoreCorrente = await LeggiValoreCorrente.Esegui(webView);

                if (valoreCorrente == null)
                {
                    Debug.WriteLine("[DSTART MANAGER] WARNING: Impossibile leggere valore corrente");
                    return false;
                }

                Debug.WriteLine("[DSTART MANAGER] Fase 2 - Decisione skip/cambia");
                bool deveImpostare = await SkipOCambia.Decidi(valoreCorrente, dstartTarget);

                if (!deveImpostare)
                {
                    Debug.WriteLine("[DSTART MANAGER] Valore gi� corretto, skip");
                    Debug.WriteLine("----------------------------------------------------");
                    return true;
                }

                Debug.WriteLine("[DSTART MANAGER] Fase 3 - Click per focus");
                bool clickRiuscito = await ClickSullInputPerFocus.Esegui(webView);

                if (!clickRiuscito)
                {
                    Debug.WriteLine("[DSTART MANAGER] WARNING: Click input NOTGO");
                    return false;
                }

                Debug.WriteLine("[DSTART MANAGER] Fase 4 - Selezione testo");
                bool selezioneRiuscita = await CtrlASelectAll.Esegui(webView);

                if (!selezioneRiuscita)
                {
                    Debug.WriteLine("[DSTART MANAGER] WARNING: Selezione testo NOTGO");
                }

                Debug.WriteLine("[DSTART MANAGER] Fase 5 - Digitazione valore");
                bool digitazioneRiuscita = await DigitazioneCaratterePerCarattere.Esegui(webView, dstartTarget);

                if (!digitazioneRiuscita)
                {
                    Debug.WriteLine("[DSTART MANAGER] WARNING: Digitazione NOTGO");
                    return false;
                }

                Debug.WriteLine("[DSTART MANAGER] Fase 6 - Conferma con ENTER");
                bool enterRiuscito = await EnterPerConfermare.Esegui(webView);

                if (!enterRiuscito)
                {
                    Debug.WriteLine("[DSTART MANAGER] WARNING: ENTER NOTGO");
                    return false;
                }

                Debug.WriteLine("[DSTART MANAGER] Fase 7 - Verifica finale");
                await Task.Delay(300);

                string valoreFinale = await LeggiValoreCorrente.Esegui(webView);

                if (valoreFinale == dstartTarget)
                {
                    Debug.WriteLine("[DSTART MANAGER] Processo completato con successo");
                    Debug.WriteLine("----------------------------------------------------");
                    return true;
                }
                else
                {
                    Debug.WriteLine($"[DSTART MANAGER] WARNING: Valore finale '{valoreFinale}' diverso da target '{dstartTarget}'");
                    Debug.WriteLine("----------------------------------------------------");
                    return false;
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[DSTART MANAGER] ERRORE: {ex.Message}");
                Debug.WriteLine("----------------------------------------------------");
                return false;
            }
        }
    }
}
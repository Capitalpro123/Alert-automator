using System;using System.Diagnostics;
using System.Diagnostics;
using System.Threading.Tasks;

namespace AlertAutomator._02_LatoFunzioni._02_EngineAutomation._02_AzioniProduzione._02_FillParametri._13_TimezoneB
{
    public class SkipOCambia
    {
        public static async Task<bool> Decidi(string valoreCorrente, string valoreTarget)
        {
            try
            {
                Debug.WriteLine("[SKIP O CAMBIA TIMEZONEB] Confronto valori...");
                Debug.WriteLine($"[SKIP O CAMBIA TIMEZONEB] Corrente = '{valoreCorrente}'");
                Debug.WriteLine($"[SKIP O CAMBIA TIMEZONEB] Target = '{valoreTarget}'");

                if (valoreCorrente == valoreTarget)
                {
                    Debug.WriteLine("[SKIP O CAMBIA TIMEZONEB] Valori identici - SKIP");
                    return false;
                }
                else
                {
                    Debug.WriteLine("[SKIP O CAMBIA TIMEZONEB] Valori diversi - CAMBIO NECESSARIO");
                    return true;
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[SKIP O CAMBIA TIMEZONEB] ERRORE: {ex.Message}");
                return true;
            }
        }
    }
}
using System;using System.Diagnostics;
using System.Diagnostics;
using System.Threading.Tasks;
using Microsoft.Web.WebView2.Wpf;

namespace AlertAutomator._02_LatoFunzioni._02_EngineAutomation._02_AzioniProduzione._02_FillParametri._12_TimezoneA
{
    public class EnterPerConfermare
    {
        public static async Task<bool> Esegui(WebView2 webView)
        {
            try
            {
                Debug.WriteLine("[ENTER TIMEZONEA] Invio ENTER per conferma...");

                await Task.Delay(100);

                await webView.CoreWebView2.CallDevToolsProtocolMethodAsync(
                    "Input.dispatchKeyEvent",
                    @"{
                        ""type"": ""keyDown"",
                        ""key"": ""Enter"",
                        ""code"": ""Enter"",
                        ""windowsVirtualKeyCode"": 13,
                        ""nativeVirtualKeyCode"": 13
                    }"
                );

                Debug.WriteLine("[ENTER TIMEZONEA] KeyDown inviato");

                await Task.Delay(50);

                await webView.CoreWebView2.CallDevToolsProtocolMethodAsync(
                    "Input.dispatchKeyEvent",
                    @"{
                        ""type"": ""keyUp"",
                        ""key"": ""Enter"",
                        ""code"": ""Enter"",
                        ""windowsVirtualKeyCode"": 13,
                        ""nativeVirtualKeyCode"": 13
                    }"
                );

                Debug.WriteLine("[ENTER TIMEZONEA] KeyUp inviato");

                await Task.Delay(500);

                Debug.WriteLine("[ENTER TIMEZONEA] Conferma completata");
                return true;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[ENTER TIMEZONEA] ERRORE: {ex.Message}");
                return false;
            }
        }
    }
}
using System;using System.Diagnostics;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading.Tasks;
using Microsoft.Web.WebView2.Wpf;
using AlertAutomator._02_LatoFunzioni._02_EngineAutomation._02_AzioniProduzione._02_FillParametri._01_UserID;
using AlertAutomator._02_LatoFunzioni._02_EngineAutomation._02_AzioniProduzione._02_FillParametri._02_LotSize;
using AlertAutomator._02_LatoFunzioni._02_EngineAutomation._02_AzioniProduzione._02_FillParametri._03_TradingSymbol;
using AlertAutomator._02_LatoFunzioni._02_EngineAutomation._02_AzioniProduzione._02_FillParametri._04_TpPips;
using AlertAutomator._02_LatoFunzioni._02_EngineAutomation._02_AzioniProduzione._02_FillParametri._05_SlPips;
using AlertAutomator._02_LatoFunzioni._02_EngineAutomation._02_AzioniProduzione._02_FillParametri._06_Comment;
using AlertAutomator._02_LatoFunzioni._02_EngineAutomation._02_AzioniProduzione._02_FillParametri._07_SessionStart;
using AlertAutomator._02_LatoFunzioni._02_EngineAutomation._02_AzioniProduzione._02_FillParametri._08_SessionEnd;
using AlertAutomator._02_LatoFunzioni._02_EngineAutomation._02_AzioniProduzione._02_FillParametri._09_EMALength;
using AlertAutomator._02_LatoFunzioni._02_EngineAutomation._02_AzioniProduzione._02_FillParametri._10_StopLoss;
using AlertAutomator._02_LatoFunzioni._02_EngineAutomation._02_AzioniProduzione._02_FillParametri._11_RR;
using AlertAutomator._02_LatoFunzioni._02_EngineAutomation._02_AzioniProduzione._02_FillParametri._12_TimezoneA;
using AlertAutomator._02_LatoFunzioni._02_EngineAutomation._02_AzioniProduzione._02_FillParametri._13_TimezoneB;
using AlertAutomator._02_LatoFunzioni._02_EngineAutomation._02_AzioniProduzione._02_FillParametri._14_Dstart;
using AlertAutomator._02_LatoFunzioni._02_EngineAutomation._02_AzioniProduzione._02_FillParametri._15_Mstart;
using AlertAutomator._02_LatoFunzioni._02_EngineAutomation._02_AzioniProduzione._02_FillParametri._16_Dend;
using AlertAutomator._02_LatoFunzioni._02_EngineAutomation._02_AzioniProduzione._02_FillParametri._17_Mend;

namespace AlertAutomator._02_LatoFunzioni._02_EngineAutomation._02_AzioniProduzione._02_FillParametri

{
    public class FillParametriManager
    {
        public static async Task<bool> Esegui(WebView2 webView, Dictionary<string, string> riga)
        {
            try
            {
                Debug.WriteLine("╔════════════════════════════════════════════════════════╗");
                Debug.WriteLine("║   FILL PARAMETRI MANAGER - INIZIO                      ║");
                Debug.WriteLine("╚════════════════════════════════════════════════════════╝");

                if (webView == null)
                {
                    Debug.WriteLine("[FILL PARAMETRI] ERRORE: WebView nullo");
                    return false;
                }

                Debug.WriteLine("[FILL PARAMETRI] STEP 1: UserID");
                if (!await UserIDManager.Esegui(webView, GetValoreDaRiga(riga, "A")))
                    return false;

                Debug.WriteLine("[FILL PARAMETRI] STEP 2: LotSize");
                if (!await LotSizeManager.Esegui(webView, GetValoreDaRiga(riga, "B")))
                    return false;

                Debug.WriteLine("[FILL PARAMETRI] STEP 3: TradingSymbol");
                if (!await TradingSymbolManager.Esegui(webView, GetValoreDaRiga(riga, "C")))
                    return false;

                Debug.WriteLine("[FILL PARAMETRI] STEP 4: TpPips");
                if (!await TpPipsManager.Esegui(webView, GetValoreDaRiga(riga, "D")))
                    return false;

                Debug.WriteLine("[FILL PARAMETRI] STEP 5: SlPips");
                if (!await SlPipsManager.Esegui(webView, GetValoreDaRiga(riga, "E")))
                    return false;

                Debug.WriteLine("[FILL PARAMETRI] STEP 6: Comment");
                if (!await CommentManager.Esegui(webView, GetValoreDaRiga(riga, "F")))
                    return false;

                Debug.WriteLine("[FILL PARAMETRI] STEP 7: SessionStart");
                if (!await SessionStartManager.Esegui(webView, GetValoreDaRiga(riga, "G")))
                    return false;

                Debug.WriteLine("[FILL PARAMETRI] STEP 8: SessionEnd");
                if (!await SessionEndManager.Esegui(webView, GetValoreDaRiga(riga, "H")))
                    return false;

                Debug.WriteLine("[FILL PARAMETRI] STEP 9: EMALength");
                if (!await EMALengthManager.Esegui(webView, GetValoreDaRiga(riga, "J")))
                    return false;

                Debug.WriteLine("[FILL PARAMETRI] STEP 10: StopLoss");
                if (!await StopLossManager.Esegui(webView, GetValoreDaRiga(riga, "K")))
                    return false;

                Debug.WriteLine("[FILL PARAMETRI] STEP 11: RR");
                if (!await RRManager.Esegui(webView, GetValoreDaRiga(riga, "L")))
                    return false;

                Debug.WriteLine("[FILL PARAMETRI] STEP 12: TimezoneA");
                if (!await TimezoneAManager.Esegui(webView, GetValoreDaRiga(riga, "M")))
                    return false;

                Debug.WriteLine("[FILL PARAMETRI] STEP 13: Dstart");
                if (!await DstartManager.Esegui(webView, GetValoreDaRiga(riga, "N")))
                    return false;

                Debug.WriteLine("[FILL PARAMETRI] STEP 14: Mstart");
                if (!await MstartManager.Esegui(webView, GetValoreDaRiga(riga, "O")))
                    return false;

                Debug.WriteLine("[FILL PARAMETRI] STEP 15: Dend");
                if (!await DendManager.Esegui(webView, GetValoreDaRiga(riga, "P")))
                    return false;

                Debug.WriteLine("[FILL PARAMETRI] STEP 16: Mend");
                if (!await MendManager.Esegui(webView, GetValoreDaRiga(riga, "Q")))
                    return false;

                Debug.WriteLine("[FILL PARAMETRI] STEP 17: TimezoneB");
                if (!await TimezoneBManager.Esegui(webView, GetValoreDaRiga(riga, "R")))
                    return false;

                Debug.WriteLine("╔════════════════════════════════════════════════════════╗");
                Debug.WriteLine("║   FILL PARAMETRI MANAGER - COMPLETATO                  ║");
                Debug.WriteLine("╚════════════════════════════════════════════════════════╝");

                return true;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[FILL PARAMETRI] ERRORE: {ex.Message}");
                Debug.WriteLine($"[FILL PARAMETRI] StackTrace: {ex.StackTrace}");
                return false;
            }
        }

        private static string GetValoreDaRiga(Dictionary<string, string> riga, string colonna)
        {
            return riga.ContainsKey(colonna) ? riga[colonna] : "";
        }
    }
}
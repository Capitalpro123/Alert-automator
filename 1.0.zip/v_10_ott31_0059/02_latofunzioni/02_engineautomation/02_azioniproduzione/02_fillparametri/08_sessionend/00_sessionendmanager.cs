using System;using System.Diagnostics;
using System.Diagnostics;
using System.Threading.Tasks;
using Microsoft.Web.WebView2.Wpf;

namespace AlertAutomator._02_LatoFunzioni._02_EngineAutomation._02_AzioniProduzione._02_FillParametri._08_SessionEnd
{
    public class SessionEndManager
    {
        public static async Task<bool> Esegui(WebView2 webView, string sessionEndTarget)
        {
            try
            {
                Debug.WriteLine($"[SESSIONEND MANAGER] Valore target: '{sessionEndTarget}'");

                if (webView == null)
                {
                    Debug.WriteLine("[SESSIONEND MANAGER] ERRORE: WebView nullo");
                    return false;
                }

                if (string.IsNullOrWhiteSpace(sessionEndTarget))
                {
                    Debug.WriteLine("[SESSIONEND MANAGER] WARNING: SessionEnd vuoto o nullo, skip");
                    return true;
                }

                Debug.WriteLine("[SESSIONEND MANAGER] Fase 1 - Lettura valore attuale");
                string valoreCorrente = await LeggiValoreCorrente.Esegui(webView);

                if (valoreCorrente == null)
                {
                    Debug.WriteLine("[SESSIONEND MANAGER] WARNING: Impossibile leggere valore corrente");
                    return false;
                }

                Debug.WriteLine("[SESSIONEND MANAGER] Fase 2 - Decisione skip/cambia");
                bool deveImpostare = await SkipOCambia.Decidi(valoreCorrente, sessionEndTarget);

                if (!deveImpostare)
                {
                    Debug.WriteLine("[SESSIONEND MANAGER] Valore già corretto, skip");
                    Debug.WriteLine("----------------------------------------------------");
                    return true;
                }

                Debug.WriteLine("[SESSIONEND MANAGER] Fase 3 - Click per focus");
                bool clickRiuscito = await ClickSullInputPerFocus.Esegui(webView);

                if (!clickRiuscito)
                {
                    Debug.WriteLine("[SESSIONEND MANAGER] WARNING: Click input fallito");
                    return false;
                }

                Debug.WriteLine("[SESSIONEND MANAGER] Fase 4 - Selezione testo");
                bool selezioneRiuscita = await CtrlASelectAll.Esegui(webView);

                if (!selezioneRiuscita)
                {
                    Debug.WriteLine("[SESSIONEND MANAGER] WARNING: Selezione testo fallita");
                }

                Debug.WriteLine("[SESSIONEND MANAGER] Fase 5 - Digitazione valore");
                bool digitazioneRiuscita = await DigitazioneCaratterePerCarattere.Esegui(webView, sessionEndTarget);

                if (!digitazioneRiuscita)
                {
                    Debug.WriteLine("[SESSIONEND MANAGER] WARNING: Digitazione fallita");
                    return false;
                }

                Debug.WriteLine("[SESSIONEND MANAGER] Fase 6 - Conferma con ENTER");
                bool enterRiuscito = await EnterPerConfermare.Esegui(webView);

                if (!enterRiuscito)
                {
                    Debug.WriteLine("[SESSIONEND MANAGER] WARNING: ENTER fallito");
                    return false;
                }

                Debug.WriteLine("[SESSIONEND MANAGER] Fase 7 - Verifica finale");
                await Task.Delay(300);

                string valoreFinale = await LeggiValoreCorrente.Esegui(webView);

                if (valoreFinale == sessionEndTarget)
                {
                    Debug.WriteLine("[SESSIONEND MANAGER] Processo completato con successo");
                    Debug.WriteLine("----------------------------------------------------");
                    return true;
                }
                else
                {
                    Debug.WriteLine($"[SESSIONEND MANAGER] WARNING: Valore finale '{valoreFinale}' diverso da target '{sessionEndTarget}'");
                    Debug.WriteLine("----------------------------------------------------");
                    return false;
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[SESSIONEND MANAGER] ERRORE: {ex.Message}");
                Debug.WriteLine("----------------------------------------------------");
                return false;
            }
        }
    }
}
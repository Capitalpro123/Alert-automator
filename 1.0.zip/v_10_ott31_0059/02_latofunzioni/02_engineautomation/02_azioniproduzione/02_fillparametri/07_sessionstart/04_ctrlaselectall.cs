using System;using System.Diagnostics;
using System.Diagnostics;
using System.Threading.Tasks;
using Microsoft.Web.WebView2.Wpf;

namespace AlertAutomator._02_LatoFunzioni._02_EngineAutomation._02_AzioniProduzione._02_FillParametri._07_SessionStart
{
    public class CtrlASelectAll
    {
        public static async Task<bool> Esegui(WebView2 webView)
        {
            try
            {
                Debug.WriteLine("[CTRL+A SESSIONSTART] Selezione testo campo SessionStart...");

                string scriptSelectAll = @"
                    (function() {
                        var input = document.querySelector('#overlap-manager-root > div:nth-child(2) > div > div.dialog-qyCw0PaN.dialog-b8SxMnzX.dialog-aRAWUDhF.rounded-aRAWUDhF.shadowed-aRAWUDhF > div > div.scrollable-vwgPOHG8 > div > div:nth-child(17) > div > span > span.inner-slot-W53jtLjw.inner-middle-slot-W53jtLjw > input');
                        
                        if (!input) {
                            var allInputs = document.querySelectorAll('#overlap-manager-root input');
                            var visibleCount = 0;
                            for (var i = 0; i < allInputs.length; i++) {
                                if (allInputs[i].offsetParent !== null) {
                                    visibleCount++;
                                    if (visibleCount === 7) {
                                        input = allInputs[i];
                                        break;
                                    }
                                }
                            }
                        }
                        
                        if (input) {
                            input.select();
                            input.setSelectionRange(0, input.value.length);
                            console.log('CTRL+A SESSIONSTART: Testo selezionato');
                            return 'selected';
                        }
                        return 'not_found';
                    })();
                ";

                await webView.ExecuteScriptAsync(scriptSelectAll);
                Debug.WriteLine("[CTRL+A SESSIONSTART] Metodo 1 (JavaScript) eseguito");

                await Task.Delay(100);

                Debug.WriteLine("[CTRL+A SESSIONSTART] Invio combinazione tasti...");

                await webView.CoreWebView2.CallDevToolsProtocolMethodAsync(
                    "Input.dispatchKeyEvent",
                    @"{
                        ""type"": ""keyDown"",
                        ""key"": ""Control"",
                        ""code"": ""ControlLeft"",
                        ""windowsVirtualKeyCode"": 17,
                        ""nativeVirtualKeyCode"": 17,
                        ""modifiers"": 2
                    }"
                );

                await Task.Delay(50);

                await webView.CoreWebView2.CallDevToolsProtocolMethodAsync(
                    "Input.dispatchKeyEvent",
                    @"{
                        ""type"": ""keyDown"",
                        ""key"": ""a"",
                        ""code"": ""KeyA"",
                        ""windowsVirtualKeyCode"": 65,
                        ""nativeVirtualKeyCode"": 65,
                        ""modifiers"": 2
                    }"
                );

                await Task.Delay(50);

                await webView.CoreWebView2.CallDevToolsProtocolMethodAsync(
                    "Input.dispatchKeyEvent",
                    @"{
                        ""type"": ""keyUp"",
                        ""key"": ""a"",
                        ""code"": ""KeyA"",
                        ""windowsVirtualKeyCode"": 65,
                        ""nativeVirtualKeyCode"": 65,
                        ""modifiers"": 2
                    }"
                );

                await Task.Delay(50);

                await webView.CoreWebView2.CallDevToolsProtocolMethodAsync(
                    "Input.dispatchKeyEvent",
                    @"{
                        ""type"": ""keyUp"",
                        ""key"": ""Control"",
                        ""code"": ""ControlLeft"",
                        ""windowsVirtualKeyCode"": 17,
                        ""nativeVirtualKeyCode"": 17,
                        ""modifiers"": 0
                    }"
                );

                Debug.WriteLine("[CTRL+A SESSIONSTART] Metodo 2 (DevTools) eseguito");

                await Task.Delay(200);

                Debug.WriteLine("[CTRL+A SESSIONSTART] Selezione completata");
                return true;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[CTRL+A SESSIONSTART] ERRORE: {ex.Message}");
                return false;
            }
        }
    }
}
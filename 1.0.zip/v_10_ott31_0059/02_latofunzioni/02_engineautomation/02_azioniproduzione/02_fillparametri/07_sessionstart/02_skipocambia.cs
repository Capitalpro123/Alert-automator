using System;using System.Diagnostics;
using System.Diagnostics;
using System.Threading.Tasks;

namespace AlertAutomator._02_LatoFunzioni._02_EngineAutomation._02_AzioniProduzione._02_FillParametri._07_SessionStart
{
    public class SkipOCambia
    {
        public static async Task<bool> Decidi(string valoreCorrente, string valoreTarget)
        {
            try
            {
                Debug.WriteLine("[SKIP O CAMBIA SESSIONSTART] Confronto valori...");
                Debug.WriteLine($"[SKIP O CAMBIA SESSIONSTART] Corrente = '{valoreCorrente}'");
                Debug.WriteLine($"[SKIP O CAMBIA SESSIONSTART] Target = '{valoreTarget}'");

                if (valoreCorrente == valoreTarget)
                {
                    Debug.WriteLine("[SKIP O CAMBIA SESSIONSTART] Valori identici - SKIP");
                    return false;
                }
                else
                {
                    Debug.WriteLine("[SKIP O CAMBIA SESSIONSTART] Valori diversi - CAMBIO NECESSARIO");
                    return true;
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[SKIP O CAMBIA SESSIONSTART] ERRORE: {ex.Message}");
                return true;
            }
        }
    }
}
using System;using System.Diagnostics;
using System.Diagnostics;
using System.Threading.Tasks;
using Microsoft.Web.WebView2.Wpf;

namespace AlertAutomator._02_LatoFunzioni._02_EngineAutomation._02_AzioniProduzione._02_FillParametri._07_SessionStart
{
    public class ClickSullInputPerFocus
    {
        public static async Task<bool> Esegui(WebView2 webView)
        {
            try
            {
                Debug.WriteLine("[CLICK FOCUS SESSIONSTART] Click su input div:nth-child(17)...");

                string scriptClickInput = @"
                    (function() {
                        var input = document.querySelector('#overlap-manager-root > div:nth-child(2) > div > div.dialog-qyCw0PaN.dialog-b8SxMnzX.dialog-aRAWUDhF.rounded-aRAWUDhF.shadowed-aRAWUDhF > div > div.scrollable-vwgPOHG8 > div > div:nth-child(17) > div > span > span.inner-slot-W53jtLjw.inner-middle-slot-W53jtLjw > input');
                        if (input) {
                            input.click();
                            input.focus();
                            console.log('CLICK SESSIONSTART: Cliccato su child(17)');
                            return 'clicked_sessionstart_child17';
                        }
                        
                        var allInputs = document.querySelectorAll('#overlap-manager-root input');
                        var visibleCount = 0;
                        
                        for (var i = 0; i < allInputs.length; i++) {
                            if (allInputs[i].offsetParent !== null) {
                                visibleCount++;
                                if (visibleCount === 7) {
                                    allInputs[i].click();
                                    allInputs[i].focus();
                                    console.log('CLICK SESSIONSTART: Cliccato settimo input visibile');
                                    return 'clicked_settimo_input_visibile';
                                }
                            }
                        }
                        
                        return 'not_found';
                    })();
                ";

                var risultato = await webView.ExecuteScriptAsync(scriptClickInput);
                risultato = risultato.Trim('"');

                Debug.WriteLine($"[CLICK FOCUS SESSIONSTART] Risultato = {risultato}");

                await Task.Delay(200);

                if (risultato != "not_found")
                {
                    Debug.WriteLine("[CLICK FOCUS SESSIONSTART] Click riuscito su SessionStart (child 17)");
                    return true;
                }
                else
                {
                    Debug.WriteLine("[CLICK FOCUS SESSIONSTART] ERRORE: Input SessionStart non trovato");
                    return false;
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[CLICK FOCUS SESSIONSTART] ERRORE: {ex.Message}");
                return false;
            }
        }
    }
}
using System;using System.Diagnostics;
using System.Diagnostics;
using System.Threading.Tasks;
using Microsoft.Web.WebView2.Wpf;

namespace AlertAutomator._02_LatoFunzioni._02_EngineAutomation._02_AzioniProduzione._02_FillParametri._01_UserID
{
    public class DigitazioneCaratterePerCarattere
    {
        public static async Task<bool> Esegui(WebView2 webView, string valoreTarget)
        {
            try
            {
                Debug.WriteLine($"[DIGITAZIONE USERID] Inizio digitazione '{valoreTarget}'");
                Debug.WriteLine($"[DIGITAZIONE USERID] Lunghezza testo = {valoreTarget.Length} caratteri");

                int caratteriDigitati = 0;

                foreach (char carattere in valoreTarget)
                {
                    await webView.CoreWebView2.CallDevToolsProtocolMethodAsync(
                        "Input.dispatchKeyEvent",
                        @"{
                            ""type"": ""char"",
                            ""text"": """ + carattere + @"""
                        }"
                    );

                    caratteriDigitati++;

                    await Task.Delay(30);
                }

                Debug.WriteLine($"[DIGITAZIONE USERID] Completata ({caratteriDigitati} caratteri)");
                return true;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[DIGITAZIONE USERID] ERRORE: {ex.Message}");
                return false;
            }
        }
    }
}
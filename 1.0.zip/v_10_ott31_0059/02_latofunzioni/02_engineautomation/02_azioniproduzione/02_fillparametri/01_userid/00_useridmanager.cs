using System;using System.Diagnostics;
using System.Diagnostics;
using System.Threading.Tasks;
using Microsoft.Web.WebView2.Wpf;

namespace AlertAutomator._02_LatoFunzioni._02_EngineAutomation._02_AzioniProduzione._02_FillParametri._01_UserID

{
    public class UserIDManager
    {
        public static async Task<bool> Esegui(WebView2 webView, string userIDTarget)
        {
            try
            {
                Debug.WriteLine($"[USERID MANAGER] Valore target: '{userIDTarget}'");

                if (webView == null)
                {
                    Debug.WriteLine("[USERID MANAGER] ERRORE: WebView nullo");
                    return false;
                }

                if (string.IsNullOrWhiteSpace(userIDTarget))
                {
                    Debug.WriteLine("[USERID MANAGER] WARNING: UserID vuoto o nullo, skip");
                    return true;
                }

                Debug.WriteLine("[USERID MANAGER] Fase 1 - Lettura valore attuale");
                string valoreCorrente = await LeggiValoreCorrente.Esegui(webView);

                if (valoreCorrente == null)
                {
                    Debug.WriteLine("[USERID MANAGER] WARNING: Impossibile leggere valore corrente");
                    return false;
                }

                Debug.WriteLine("[USERID MANAGER] Fase 2 - Decisione skip/cambia");
                bool deveImpostare = await SkipOCambia.Decidi(valoreCorrente, userIDTarget);

                if (!deveImpostare)
                {
                    Debug.WriteLine("[USERID MANAGER] Valore già corretto, skip");
                    Debug.WriteLine("----------------------------------------------------");
                    return true;
                }

                Debug.WriteLine("[USERID MANAGER] Fase 3 - Click per focus");
                bool clickRiuscito = await ClickSullInputPerFocus.Esegui(webView);

                if (!clickRiuscito)
                {
                    Debug.WriteLine("[USERID MANAGER] WARNING: Click input fallito");
                    return false;
                }

                Debug.WriteLine("[USERID MANAGER] Fase 4 - Selezione testo");
                bool selezioneRiuscita = await CtrlASelectAll.Esegui(webView);

                if (!selezioneRiuscita)
                {
                    Debug.WriteLine("[USERID MANAGER] WARNING: Selezione testo fallita");
                }

                Debug.WriteLine("[USERID MANAGER] Fase 5 - Digitazione valore");
                bool digitazioneRiuscita = await DigitazioneCaratterePerCarattere.Esegui(webView, userIDTarget);

                if (!digitazioneRiuscita)
                {
                    Debug.WriteLine("[USERID MANAGER] WARNING: Digitazione fallita");
                    return false;
                }

                Debug.WriteLine("[USERID MANAGER] Fase 6 - Conferma con ENTER");
                bool enterRiuscito = await EnterPerConfermare.Esegui(webView);

                if (!enterRiuscito)
                {
                    Debug.WriteLine("[USERID MANAGER] WARNING: ENTER fallito");
                    return false;
                }

                Debug.WriteLine("[USERID MANAGER] Fase 7 - Verifica finale");
                await Task.Delay(300);

                string valoreFinale = await LeggiValoreCorrente.Esegui(webView);

                if (valoreFinale == userIDTarget)
                {
                    Debug.WriteLine("[USERID MANAGER] Processo completato con successo");
                    Debug.WriteLine("----------------------------------------------------");
                    return true;
                }
                else
                {
                    Debug.WriteLine($"[USERID MANAGER] WARNING: Valore finale '{valoreFinale}' diverso da target '{userIDTarget}'");
                    Debug.WriteLine("----------------------------------------------------");
                    return false;
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[USERID MANAGER] ERRORE: {ex.Message}");
                Debug.WriteLine("----------------------------------------------------");
                return false;
            }
        }
    }
}
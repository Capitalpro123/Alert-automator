using System;using System.Diagnostics;
using System.Diagnostics;
using System.Threading.Tasks;
using Microsoft.Web.WebView2.Wpf;

namespace AlertAutomator._02_LatoFunzioni._02_EngineAutomation._02_AzioniProduzione._02_FillParametri._09_EMALength
{
    public class LeggiValoreCorrente
    {
        public static async Task<string> Esegui(WebView2 webView)
        {
            try
            {
                Debug.WriteLine("[LEGGI VALORE EMALENGTH] Lettura campo div:nth-child(27)...");

                string scriptLeggiValore = @"
                    (function() {
                        var input = document.querySelector('#overlap-manager-root > div:nth-child(3) > div > div.dialog-qyCw0PaN.dialog-b8SxMnzX.dialog-aRAWUDhF.rounded-aRAWUDhF.shadowed-aRAWUDhF > div > div.scrollable-vwgPOHG8 > div > div:nth-child(27) > div > span > span.inner-slot-W53jtLjw.inner-middle-slot-W53jtLjw > input');
                        if (input) {
                            console.log('LEGGI VALORE EMALENGTH: Input trovato con selettore child(27)');
                            return input.value || '';
                        }
                        
                        var allInputs = document.querySelectorAll('#overlap-manager-root input');
                        console.log('LEGGI VALORE EMALENGTH: Trovati ' + allInputs.length + ' input totali');
                        
                        var visibleCount = 0;
                        for (var i = 0; i < allInputs.length; i++) {
                            if (allInputs[i].offsetParent !== null) {
                                visibleCount++;
                                if (visibleCount === 9) {
                                    console.log('LEGGI VALORE EMALENGTH: Usando nono input visibile');
                                    return allInputs[i].value || '';
                                }
                            }
                        }
                        
                        return 'INPUT_NON_TROVATO';
                    })();
                ";

                var risultato = await webView.ExecuteScriptAsync(scriptLeggiValore);
                risultato = risultato.Trim('"');

                if (risultato == "INPUT_NON_TROVATO")
                {
                    Debug.WriteLine("[LEGGI VALORE EMALENGTH] ERRORE: Input EMALength (child 27) non trovato nel DOM");
                    return null;
                }

                Debug.WriteLine($"[LEGGI VALORE EMALENGTH] Valore letto = '{risultato}'");
                return risultato;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[LEGGI VALORE EMALENGTH] ERRORE: {ex.Message}");
                return null;
            }
        }
    }
}
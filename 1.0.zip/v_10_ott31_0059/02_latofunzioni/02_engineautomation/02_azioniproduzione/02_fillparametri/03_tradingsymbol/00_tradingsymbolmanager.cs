using System;using System.Diagnostics;
using System.Diagnostics;
using System.Threading.Tasks;
using Microsoft.Web.WebView2.Wpf;

namespace AlertAutomator._02_LatoFunzioni._02_EngineAutomation._02_AzioniProduzione._02_FillParametri._03_TradingSymbol
{
    public class TradingSymbolManager
    {
        public static async Task<bool> Esegui(WebView2 webView, string tradingSymbolTarget)
        {
            try
            {
                Debug.WriteLine($"[TRADINGSYMBOL MANAGER] Valore target: '{tradingSymbolTarget}'");

                if (webView == null)
                {
                    Debug.WriteLine("[TRADINGSYMBOL MANAGER] ERRORE: WebView nullo");
                    return false;
                }

                if (string.IsNullOrWhiteSpace(tradingSymbolTarget))
                {
                    Debug.WriteLine("[TRADINGSYMBOL MANAGER] WARNING: TradingSymbol vuoto o nullo, skip");
                    return true;
                }

                Debug.WriteLine("[TRADINGSYMBOL MANAGER] Fase 1 - Lettura valore attuale");
                string valoreCorrente = await LeggiValoreCorrente.Esegui(webView);

                if (valoreCorrente == null)
                {
                    Debug.WriteLine("[TRADINGSYMBOL MANAGER] WARNING: Impossibile leggere valore corrente");
                    return false;
                }

                Debug.WriteLine("[TRADINGSYMBOL MANAGER] Fase 2 - Decisione skip/cambia");
                bool deveImpostare = await SkipOCambia.Decidi(valoreCorrente, tradingSymbolTarget);

                if (!deveImpostare)
                {
                    Debug.WriteLine("[TRADINGSYMBOL MANAGER] Valore già corretto, skip");
                    Debug.WriteLine("----------------------------------------------------");
                    return true;
                }

                Debug.WriteLine("[TRADINGSYMBOL MANAGER] Fase 3 - Click per focus");
                bool clickRiuscito = await ClickSullInputPerFocus.Esegui(webView);

                if (!clickRiuscito)
                {
                    Debug.WriteLine("[TRADINGSYMBOL MANAGER] WARNING: Click input fallito");
                    return false;
                }

                Debug.WriteLine("[TRADINGSYMBOL MANAGER] Fase 4 - Selezione testo");
                bool selezioneRiuscita = await CtrlASelectAll.Esegui(webView);

                if (!selezioneRiuscita)
                {
                    Debug.WriteLine("[TRADINGSYMBOL MANAGER] WARNING: Selezione testo fallita");
                }

                Debug.WriteLine("[TRADINGSYMBOL MANAGER] Fase 5 - Digitazione valore");
                bool digitazioneRiuscita = await DigitazioneCaratterePerCarattere.Esegui(webView, tradingSymbolTarget);

                if (!digitazioneRiuscita)
                {
                    Debug.WriteLine("[TRADINGSYMBOL MANAGER] WARNING: Digitazione fallita");
                    return false;
                }

                Debug.WriteLine("[TRADINGSYMBOL MANAGER] Fase 6 - Conferma con ENTER");
                bool enterRiuscito = await EnterPerConfermare.Esegui(webView);

                if (!enterRiuscito)
                {
                    Debug.WriteLine("[TRADINGSYMBOL MANAGER] WARNING: ENTER fallito");
                    return false;
                }

                Debug.WriteLine("[TRADINGSYMBOL MANAGER] Fase 7 - Verifica finale");
                await Task.Delay(300);

                string valoreFinale = await LeggiValoreCorrente.Esegui(webView);

                if (valoreFinale == tradingSymbolTarget)
                {
                    Debug.WriteLine("[TRADINGSYMBOL MANAGER] Processo completato con successo");
                    Debug.WriteLine("----------------------------------------------------");
                    return true;
                }
                else
                {
                    Debug.WriteLine($"[TRADINGSYMBOL MANAGER] WARNING: Valore finale '{valoreFinale}' diverso da target '{tradingSymbolTarget}'");
                    Debug.WriteLine("----------------------------------------------------");
                    return false;
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[TRADINGSYMBOL MANAGER] ERRORE: {ex.Message}");
                Debug.WriteLine("----------------------------------------------------");
                return false;
            }
        }
    }
}
using System;using System.Diagnostics;
using System.Diagnostics;
using System.Threading.Tasks;
using Microsoft.Web.WebView2.Wpf;

namespace AlertAutomator._02_LatoFunzioni._02_EngineAutomation._02_AzioniProduzione._02_FillParametri._06_Comment
{
    public class DigitazioneCaratterePerCarattere
    {
        public static async Task<bool> Esegui(WebView2 webView, string valoreTarget)
        {
            try
            {
                Debug.WriteLine($"[DIGITAZIONE COMMENT] Inizio digitazione '{valoreTarget}'");
                Debug.WriteLine($"[DIGITAZIONE COMMENT] Lunghezza testo = {valoreTarget.Length} caratteri");

                int caratteriDigitati = 0;

                foreach (char carattere in valoreTarget)
                {
                    await webView.CoreWebView2.CallDevToolsProtocolMethodAsync(
                        "Input.dispatchKeyEvent",
                        @"{
                            ""type"": ""char"",
                            ""text"": """ + carattere + @"""
                        }"
                    );

                    caratteriDigitati++;

                    if (caratteriDigitati % 10 == 0)
                    {
                        Debug.WriteLine($"[DIGITAZIONE COMMENT] Progresso {caratteriDigitati}/{valoreTarget.Length}");
                    }

                    await Task.Delay(25);
                }

                Debug.WriteLine($"[DIGITAZIONE COMMENT] Completata ({caratteriDigitati} caratteri)");
                return true;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[DIGITAZIONE COMMENT] ERRORE: {ex.Message}");
                return false;
            }
        }
    }
}
using System;using System.Diagnostics;
using System.Diagnostics;
using System.Threading.Tasks;

namespace AlertAutomator._02_LatoFunzioni._02_EngineAutomation._02_AzioniProduzione._02_FillParametri._05_SlPips
{
    public class SkipOCambia
    {
        public static async Task<bool> Decidi(string valoreCorrente, string valoreTarget)
        {
            try
            {
                Debug.WriteLine("[SKIP O CAMBIA SLPIPS] Confronto valori...");
                Debug.WriteLine($"[SKIP O CAMBIA SLPIPS] Corrente = '{valoreCorrente}'");
                Debug.WriteLine($"[SKIP O CAMBIA SLPIPS] Target = '{valoreTarget}'");

                if (valoreCorrente == valoreTarget)
                {
                    Debug.WriteLine("[SKIP O CAMBIA SLPIPS] Valori identici - SKIP");
                    return false;
                }
                else
                {
                    Debug.WriteLine("[SKIP O CAMBIA SLPIPS] Valori diversi - CAMBIO NECESSARIO");
                    return true;
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[SKIP O CAMBIA SLPIPS] ERRORE: {ex.Message}");
                return true;
            }
        }
    }
}
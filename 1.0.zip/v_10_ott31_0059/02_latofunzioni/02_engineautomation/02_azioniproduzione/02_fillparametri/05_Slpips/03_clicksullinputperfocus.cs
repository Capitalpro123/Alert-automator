using System;using System.Diagnostics;
using System.Diagnostics;
using System.Threading.Tasks;
using Microsoft.Web.WebView2.Wpf;

namespace AlertAutomator._02_LatoFunzioni._02_EngineAutomation._02_AzioniProduzione._02_FillParametri._05_SlPips
{
    public class ClickSullInputPerFocus
    {
        public static async Task<bool> Esegui(WebView2 webView)
        {
            try
            {
                Debug.WriteLine("[CLICK FOCUS SLPIPS] Click su input div:nth-child(11)...");

                string scriptClickInput = @"
                    (function() {
                        var input = document.querySelector('#overlap-manager-root > div:nth-child(2) > div > div.dialog-qyCw0PaN.dialog-b8SxMnzX.dialog-aRAWUDhF.rounded-aRAWUDhF.shadowed-aRAWUDhF > div > div.scrollable-vwgPOHG8 > div > div:nth-child(11) > div > span > span.inner-slot-W53jtLjw.inner-middle-slot-W53jtLjw > input');
                        if (input) {
                            input.click();
                            input.focus();
                            console.log('CLICK SLPIPS: Cliccato su child(11)');
                            return 'clicked_slpips_child11';
                        }
                        
                        var allInputs = document.querySelectorAll('#overlap-manager-root input');
                        var visibleCount = 0;
                        
                        for (var i = 0; i < allInputs.length; i++) {
                            if (allInputs[i].offsetParent !== null) {
                                visibleCount++;
                                if (visibleCount === 5) {
                                    allInputs[i].click();
                                    allInputs[i].focus();
                                    console.log('CLICK SLPIPS: Cliccato quinto input visibile');
                                    return 'clicked_quinto_input_visibile';
                                }
                            }
                        }
                        
                        return 'not_found';
                    })();
                ";

                var risultato = await webView.ExecuteScriptAsync(scriptClickInput);
                risultato = risultato.Trim('"');

                Debug.WriteLine($"[CLICK FOCUS SLPIPS] Risultato = {risultato}");

                await Task.Delay(200);

                if (risultato != "not_found")
                {
                    Debug.WriteLine("[CLICK FOCUS SLPIPS] Click riuscito su SlPips (child 11)");
                    return true;
                }
                else
                {
                    Debug.WriteLine("[CLICK FOCUS SLPIPS] ERRORE: Input SlPips non trovato");
                    return false;
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[CLICK FOCUS SLPIPS] ERRORE: {ex.Message}");
                return false;
            }
        }
    }
}
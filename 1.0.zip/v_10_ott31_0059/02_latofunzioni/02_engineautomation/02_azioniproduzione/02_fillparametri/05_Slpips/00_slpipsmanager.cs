using System;using System.Diagnostics;
using System.Diagnostics;
using System.Threading.Tasks;
using Microsoft.Web.WebView2.Wpf;

namespace AlertAutomator._02_LatoFunzioni._02_EngineAutomation._02_AzioniProduzione._02_FillParametri._05_SlPips
{
    public class SlPipsManager
    {
        public static async Task<bool> Esegui(WebView2 webView, string slPipsTarget)
        {
            try
            {
                Debug.WriteLine($"[SLPIPS MANAGER] Valore target: '{slPipsTarget}'");

                if (webView == null)
                {
                    Debug.WriteLine("[SLPIPS MANAGER] ERRORE: WebView nullo");
                    return false;
                }

                if (string.IsNullOrWhiteSpace(slPipsTarget))
                {
                    Debug.WriteLine("[SLPIPS MANAGER] WARNING: SlPips vuoto o nullo, skip");
                    return true;
                }

                Debug.WriteLine("[SLPIPS MANAGER] Fase 1 - Lettura valore attuale");
                string valoreCorrente = await LeggiValoreCorrente.Esegui(webView);

                if (valoreCorrente == null)
                {
                    Debug.WriteLine("[SLPIPS MANAGER] WARNING: Impossibile leggere valore corrente");
                    return false;
                }

                Debug.WriteLine("[SLPIPS MANAGER] Fase 2 - Decisione skip/cambia");
                bool deveImpostare = await SkipOCambia.Decidi(valoreCorrente, slPipsTarget);

                if (!deveImpostare)
                {
                    Debug.WriteLine("[SLPIPS MANAGER] Valore già corretto, skip");
                    Debug.WriteLine("----------------------------------------------------");
                    return true;
                }

                Debug.WriteLine("[SLPIPS MANAGER] Fase 3 - Click per focus");
                bool clickRiuscito = await ClickSullInputPerFocus.Esegui(webView);

                if (!clickRiuscito)
                {
                    Debug.WriteLine("[SLPIPS MANAGER] WARNING: Click input fallito");
                    return false;
                }

                Debug.WriteLine("[SLPIPS MANAGER] Fase 4 - Selezione testo");
                bool selezioneRiuscita = await CtrlASelectAll.Esegui(webView);

                if (!selezioneRiuscita)
                {
                    Debug.WriteLine("[SLPIPS MANAGER] WARNING: Selezione testo fallita");
                }

                Debug.WriteLine("[SLPIPS MANAGER] Fase 5 - Digitazione valore");
                bool digitazioneRiuscita = await DigitazioneCaratterePerCarattere.Esegui(webView, slPipsTarget);

                if (!digitazioneRiuscita)
                {
                    Debug.WriteLine("[SLPIPS MANAGER] WARNING: Digitazione fallita");
                    return false;
                }

                Debug.WriteLine("[SLPIPS MANAGER] Fase 6 - Conferma con ENTER");
                bool enterRiuscito = await EnterPerConfermare.Esegui(webView);

                if (!enterRiuscito)
                {
                    Debug.WriteLine("[SLPIPS MANAGER] WARNING: ENTER fallito");
                    return false;
                }

                Debug.WriteLine("[SLPIPS MANAGER] Fase 7 - Verifica finale");
                await Task.Delay(300);

                string valoreFinale = await LeggiValoreCorrente.Esegui(webView);

                if (valoreFinale == slPipsTarget)
                {
                    Debug.WriteLine("[SLPIPS MANAGER] Processo completato con successo");
                    Debug.WriteLine("----------------------------------------------------");
                    return true;
                }
                else
                {
                    Debug.WriteLine($"[SLPIPS MANAGER] WARNING: Valore finale '{valoreFinale}' diverso da target '{slPipsTarget}'");
                    Debug.WriteLine("----------------------------------------------------");
                    return false;
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[SLPIPS MANAGER] ERRORE: {ex.Message}");
                Debug.WriteLine("----------------------------------------------------");
                return false;
            }
        }
    }
}
using System;using System.Diagnostics;
using System.Diagnostics;
using System.Threading.Tasks;
using Microsoft.Web.WebView2.Wpf;

namespace AlertAutomator._02_LatoFunzioni._02_EngineAutomation._02_AzioniProduzione._02_FillParametri._10_StopLoss
{
    public class StopLossManager
    {
        public static async Task<bool> Esegui(WebView2 webView, string stopLossTarget)
        {
            try
            {
                Debug.WriteLine($"[STOPLOSS MANAGER] Valore target: '{stopLossTarget}'");

                if (webView == null)
                {
                    Debug.WriteLine("[STOPLOSS MANAGER] ERRORE: WebView nullo");
                    return false;
                }

                if (string.IsNullOrWhiteSpace(stopLossTarget))
                {
                    Debug.WriteLine("[STOPLOSS MANAGER] WARNING: StopLoss vuoto o nullo, skip");
                    return true;
                }

                Debug.WriteLine("[STOPLOSS MANAGER] Fase 1 - Lettura valore attuale");
                string valoreCorrente = await LeggiValoreCorrente.Esegui(webView);

                if (valoreCorrente == null)
                {
                    Debug.WriteLine("[STOPLOSS MANAGER] WARNING: Impossibile leggere valore corrente");
                    return false;
                }

                Debug.WriteLine("[STOPLOSS MANAGER] Fase 2 - Decisione skip/cambia");
                bool deveImpostare = await SkipOCambia.Decidi(valoreCorrente, stopLossTarget);

                if (!deveImpostare)
                {
                    Debug.WriteLine("[STOPLOSS MANAGER] Valore gi� corretto, skip");
                    Debug.WriteLine("----------------------------------------------------");
                    return true;
                }

                Debug.WriteLine("[STOPLOSS MANAGER] Fase 3 - Click per focus");
                bool clickRiuscito = await ClickSullInputPerFocus.Esegui(webView);

                if (!clickRiuscito)
                {
                    Debug.WriteLine("[STOPLOSS MANAGER] WARNING: Click input fallito");
                    return false;
                }

                Debug.WriteLine("[STOPLOSS MANAGER] Fase 4 - Selezione testo");
                bool selezioneRiuscita = await CtrlASelectAll.Esegui(webView);

                if (!selezioneRiuscita)
                {
                    Debug.WriteLine("[STOPLOSS MANAGER] WARNING: Selezione testo fallita");
                }

                Debug.WriteLine("[STOPLOSS MANAGER] Fase 5 - Digitazione valore");
                bool digitazioneRiuscita = await DigitazioneCaratterePerCarattere.Esegui(webView, stopLossTarget);

                if (!digitazioneRiuscita)
                {
                    Debug.WriteLine("[STOPLOSS MANAGER] WARNING: Digitazione fallita");
                    return false;
                }

                Debug.WriteLine("[STOPLOSS MANAGER] Fase 6 - Conferma con ENTER");
                bool enterRiuscito = await EnterPerConfermare.Esegui(webView);

                if (!enterRiuscito)
                {
                    Debug.WriteLine("[STOPLOSS MANAGER] WARNING: ENTER fallito");
                    return false;
                }

                Debug.WriteLine("[STOPLOSS MANAGER] Fase 7 - Verifica finale");
                await Task.Delay(300);

                string valoreFinale = await LeggiValoreCorrente.Esegui(webView);

                if (valoreFinale == stopLossTarget)
                {
                    Debug.WriteLine("[STOPLOSS MANAGER] Processo completato con successo");
                    Debug.WriteLine("----------------------------------------------------");
                    return true;
                }
                else
                {
                    Debug.WriteLine($"[STOPLOSS MANAGER] WARNING: Valore finale '{valoreFinale}' diverso da target '{stopLossTarget}'");
                    Debug.WriteLine("----------------------------------------------------");
                    return false;
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[STOPLOSS MANAGER] ERRORE: {ex.Message}");
                Debug.WriteLine("----------------------------------------------------");
                return false;
            }
        }
    }
}
using System;using System.Diagnostics;
using System.Diagnostics;
using System.Threading.Tasks;

namespace AlertAutomator._02_LatoFunzioni._02_EngineAutomation._02_AzioniProduzione._02_FillParametri._15_Mstart
{
    public class SkipOCambia
    {
        public static async Task<bool> Decidi(string valoreCorrente, string valoreTarget)
        {
            try
            {
                Debug.WriteLine("[SKIP O CAMBIA MSTART] Confronto valori...");
                Debug.WriteLine($"[SKIP O CAMBIA MSTART] Corrente = '{valoreCorrente}'");
                Debug.WriteLine($"[SKIP O CAMBIA MSTART] Target = '{valoreTarget}'");

                if (valoreCorrente == valoreTarget)
                {
                    Debug.WriteLine("[SKIP O CAMBIA MSTART] Valori identici - SKIP");
                    return false;
                }
                else
                {
                    Debug.WriteLine("[SKIP O CAMBIA MSTART] Valori diversi - CAMBIO NECESSARIO");
                    return true;
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[SKIP O CAMBIA MSTART] ERRORE: {ex.Message}");
                return true;
            }
        }
    }
}
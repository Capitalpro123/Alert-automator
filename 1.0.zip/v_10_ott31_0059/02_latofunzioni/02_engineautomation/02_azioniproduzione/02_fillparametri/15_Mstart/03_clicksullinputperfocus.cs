using System;using System.Diagnostics;
using System.Diagnostics;
using System.Threading.Tasks;
using Microsoft.Web.WebView2.Wpf;

namespace AlertAutomator._02_LatoFunzioni._02_EngineAutomation._02_AzioniProduzione._02_FillParametri._15_Mstart
{
    public class ClickSullInputPerFocus
    {
        public static async Task<bool> Esegui(WebView2 webView)
        {
            try
            {
                Debug.WriteLine("[CLICK FOCUS MSTART] Click su input div:nth-child(43)...");

                string scriptClickInput = @"
                    (function() {
                        var input = document.querySelector('#overlap-manager-root > div:nth-child(3) > div > div.dialog-qyCw0PaN.dialog-b8SxMnzX.dialog-aRAWUDhF.rounded-aRAWUDhF.shadowed-aRAWUDhF > div > div.scrollable-vwgPOHG8 > div > div:nth-child(42) > span:nth-child(2) > div:nth-child(2) > div > span > span.inner-slot-W53jtLjw.inner-middle-slot-W53jtLjw > input');
                        if (input) {
                            input.click();
                            input.focus();
                            console.log('CLICK MSTART: Cliccato su child(43)');
                            return 'clicked_mstart_child43';
                        }
                        
                        var allInputs = document.querySelectorAll('#overlap-manager-root input');
                        var visibleCount = 0;
                        
                        for (var i = 0; i < allInputs.length; i++) {
                            if (allInputs[i].offsetParent !== null) {
                                visibleCount++;
                                if (visibleCount === 15) {
                                    allInputs[i].click();
                                    allInputs[i].focus();
                                    console.log('CLICK MSTART: Cliccato quindicesimo input visibile');
                                    return 'clicked_quindicesimo_input_visibile';
                                }
                            }
                        }
                        
                        return 'not_found';
                    })();
                ";

                var risultato = await webView.ExecuteScriptAsync(scriptClickInput);
                risultato = risultato.Trim('"');

                Debug.WriteLine($"[CLICK FOCUS MSTART] Risultato = {risultato}");

                await Task.Delay(200);

                if (risultato != "not_found")
                {
                    Debug.WriteLine("[CLICK FOCUS MSTART] Click riuscito su Mstart (child 43)");
                    return true;
                }
                else
                {
                    Debug.WriteLine("[CLICK FOCUS MSTART] ERRORE: Input Mstart non trovato");
                    return false;
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[CLICK FOCUS MSTART] ERRORE: {ex.Message}");
                return false;
            }
        }
    }
}
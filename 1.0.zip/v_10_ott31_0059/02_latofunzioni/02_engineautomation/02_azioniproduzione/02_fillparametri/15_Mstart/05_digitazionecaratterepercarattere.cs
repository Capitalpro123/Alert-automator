using System;using System.Diagnostics;
using System.Diagnostics;
using System.Threading.Tasks;
using Microsoft.Web.WebView2.Wpf;

namespace AlertAutomator._02_LatoFunzioni._02_EngineAutomation._02_AzioniProduzione._02_FillParametri._15_Mstart
{
    public class DigitazioneCaratterePerCarattere
    {
        public static async Task<bool> Esegui(WebView2 webView, string valoreTarget)
        {
            try
            {
                Debug.WriteLine($"[DIGITAZIONE MSTART] Inizio digitazione '{valoreTarget}'");
                Debug.WriteLine($"[DIGITAZIONE MSTART] Lunghezza testo = {valoreTarget.Length} caratteri");

                int caratteriDigitati = 0;

                foreach (char carattere in valoreTarget)
                {
                    await webView.CoreWebView2.CallDevToolsProtocolMethodAsync(
                        "Input.dispatchKeyEvent",
                        @"{
                            ""type"": ""char"",
                            ""text"": """ + carattere + @"""
                        }"
                    );

                    caratteriDigitati++;

                    await Task.Delay(30);
                }

                Debug.WriteLine($"[DIGITAZIONE MSTART] Completata ({caratteriDigitati} caratteri)");
                return true;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[DIGITAZIONE MSTART] ERRORE: {ex.Message}");
                return false;
            }
        }
    }
}
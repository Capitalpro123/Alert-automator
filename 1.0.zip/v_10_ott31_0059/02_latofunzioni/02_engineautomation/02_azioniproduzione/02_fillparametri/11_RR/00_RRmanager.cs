using System;using System.Diagnostics;
using System.Diagnostics;
using System.Threading.Tasks;
using Microsoft.Web.WebView2.Wpf;

namespace AlertAutomator._02_LatoFunzioni._02_EngineAutomation._02_AzioniProduzione._02_FillParametri._11_RR
{
    public class RRManager
    {
        public static async Task<bool> Esegui(WebView2 webView, string rrTarget)
        {
            try
            {
                Debug.WriteLine($"[RR MANAGER] Valore target: '{rrTarget}'");

                if (webView == null)
                {
                    Debug.WriteLine("[RR MANAGER] ERRORE: WebView nullo");
                    return false;
                }

                if (string.IsNullOrWhiteSpace(rrTarget))
                {
                    Debug.WriteLine("[RR MANAGER] WARNING: RR vuoto o nullo, skip");
                    return true;
                }

                Debug.WriteLine("[RR MANAGER] Fase 1 - Lettura valore attuale");
                string valoreCorrente = await LeggiValoreCorrente.Esegui(webView);

                if (valoreCorrente == null)
                {
                    Debug.WriteLine("[RR MANAGER] WARNING: Impossibile leggere valore corrente");
                    return false;
                }

                Debug.WriteLine("[RR MANAGER] Fase 2 - Decisione skip/cambia");
                bool deveImpostare = await SkipOCambia.Decidi(valoreCorrente, rrTarget);

                if (!deveImpostare)
                {
                    Debug.WriteLine("[RR MANAGER] Valore gi� corretto, skip");
                    Debug.WriteLine("----------------------------------------------------");
                    return true;
                }

                Debug.WriteLine("[RR MANAGER] Fase 3 - Click per focus");
                bool clickRiuscito = await ClickSullInputPerFocus.Esegui(webView);

                if (!clickRiuscito)
                {
                    Debug.WriteLine("[RR MANAGER] WARNING: Click input fallito");
                    return false;
                }

                Debug.WriteLine("[RR MANAGER] Fase 4 - Selezione testo");
                bool selezioneRiuscita = await CtrlASelectAll.Esegui(webView);

                if (!selezioneRiuscita)
                {
                    Debug.WriteLine("[RR MANAGER] WARNING: Selezione testo fallita");
                }

                Debug.WriteLine("[RR MANAGER] Fase 5 - Digitazione valore");
                bool digitazioneRiuscita = await DigitazioneCaratterePerCarattere.Esegui(webView, rrTarget);

                if (!digitazioneRiuscita)
                {
                    Debug.WriteLine("[RR MANAGER] WARNING: Digitazione fallita");
                    return false;
                }

                Debug.WriteLine("[RR MANAGER] Fase 6 - Conferma con ENTER");
                bool enterRiuscito = await EnterPerConfermare.Esegui(webView);

                if (!enterRiuscito)
                {
                    Debug.WriteLine("[RR MANAGER] WARNING: ENTER fallito");
                    return false;
                }

                Debug.WriteLine("[RR MANAGER] Fase 7 - Verifica finale");
                await Task.Delay(300);

                string valoreFinale = await LeggiValoreCorrente.Esegui(webView);

                if (valoreFinale == rrTarget)
                {
                    Debug.WriteLine("[RR MANAGER] Processo completato con successo");
                    Debug.WriteLine("----------------------------------------------------");
                    return true;
                }
                else
                {
                    Debug.WriteLine($"[RR MANAGER] WARNING: Valore finale '{valoreFinale}' diverso da target '{rrTarget}'");
                    Debug.WriteLine("----------------------------------------------------");
                    return false;
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[RR MANAGER] ERRORE: {ex.Message}");
                Debug.WriteLine("----------------------------------------------------");
                return false;
            }
        }
    }
}
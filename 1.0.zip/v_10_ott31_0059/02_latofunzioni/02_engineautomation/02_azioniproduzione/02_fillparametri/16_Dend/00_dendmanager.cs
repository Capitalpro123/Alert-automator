using System;using System.Diagnostics;
using System.Diagnostics;
using System.Threading.Tasks;
using Microsoft.Web.WebView2.Wpf;

namespace AlertAutomator._02_LatoFunzioni._02_EngineAutomation._02_AzioniProduzione._02_FillParametri._16_Dend
{
    public class DendManager
    {
        public static async Task<bool> Esegui(WebView2 webView, string dendTarget)
        {
            try
            {
                Debug.WriteLine($"[DEND MANAGER] Valore target: '{dendTarget}'");

                if (webView == null)
                {
                    Debug.WriteLine("[DEND MANAGER] ERRORE: WebView nullo");
                    return false;
                }

                if (string.IsNullOrWhiteSpace(dendTarget))
                {
                    Debug.WriteLine("[DEND MANAGER] WARNING: Dend vuoto o nullo, skip");
                    return true;
                }

                Debug.WriteLine("[DEND MANAGER] Fase 1 - Lettura valore attuale");
                string valoreCorrente = await LeggiValoreCorrente.Esegui(webView);

                if (valoreCorrente == null)
                {
                    Debug.WriteLine("[DEND MANAGER] WARNING: Impossibile leggere valore corrente");
                    return false;
                }

                Debug.WriteLine("[DEND MANAGER] Fase 2 - Decisione skip/cambia");
                bool deveImpostare = await SkipOCambia.Decidi(valoreCorrente, dendTarget);

                if (!deveImpostare)
                {
                    Debug.WriteLine("[DEND MANAGER] Valore gi� corretto, skip");
                    Debug.WriteLine("----------------------------------------------------");
                    return true;
                }

                Debug.WriteLine("[DEND MANAGER] Fase 3 - Click per focus");
                bool clickRiuscito = await ClickSullInputPerFocus.Esegui(webView);

                if (!clickRiuscito)
                {
                    Debug.WriteLine("[DEND MANAGER] WARNING: Click input fallito");
                    return false;
                }

                Debug.WriteLine("[DEND MANAGER] Fase 4 - Selezione testo");
                bool selezioneRiuscita = await CtrlASelectAll.Esegui(webView);

                if (!selezioneRiuscita)
                {
                    Debug.WriteLine("[DEND MANAGER] WARNING: Selezione testo fallita");
                }

                Debug.WriteLine("[DEND MANAGER] Fase 5 - Digitazione valore");
                bool digitazioneRiuscita = await DigitazioneCaratterePerCarattere.Esegui(webView, dendTarget);

                if (!digitazioneRiuscita)
                {
                    Debug.WriteLine("[DEND MANAGER] WARNING: Digitazione fallita");
                    return false;
                }

                Debug.WriteLine("[DEND MANAGER] Fase 6 - Conferma con ENTER");
                bool enterRiuscito = await EnterPerConfermare.Esegui(webView);

                if (!enterRiuscito)
                {
                    Debug.WriteLine("[DEND MANAGER] WARNING: ENTER fallito");
                    return false;
                }

                Debug.WriteLine("[DEND MANAGER] Fase 7 - Verifica finale");
                await Task.Delay(300);

                string valoreFinale = await LeggiValoreCorrente.Esegui(webView);

                if (valoreFinale == dendTarget)
                {
                    Debug.WriteLine("[DEND MANAGER] Processo completato con successo");
                    Debug.WriteLine("----------------------------------------------------");
                    return true;
                }
                else
                {
                    Debug.WriteLine($"[DEND MANAGER] WARNING: Valore finale '{valoreFinale}' diverso da target '{dendTarget}'");
                    Debug.WriteLine("----------------------------------------------------");
                    return false;
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[DEND MANAGER] ERRORE: {ex.Message}");
                Debug.WriteLine("----------------------------------------------------");
                return false;
            }
        }
    }
}
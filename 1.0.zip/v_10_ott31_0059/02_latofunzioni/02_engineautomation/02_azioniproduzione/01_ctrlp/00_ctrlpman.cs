using System;using System.Diagnostics;
using System.Diagnostics;
using System.Threading.Tasks;
using Microsoft.Web.WebView2.Wpf;

namespace AlertAutomator._02_LatoFunzioni._02_EngineAutomation._02_AzioniProduzione._01_CtrlP
{
    public class CtrlPManager
    {
        public static async Task<bool> Esegui(WebView2 webView)
        {
            try
            {
                Debug.WriteLine("╔════════════════════════════════════════════════════════╗");
                Debug.WriteLine("║   CTRL+P MANAGER - INIZIO                              ║");
                Debug.WriteLine("╚════════════════════════════════════════════════════════╝");

                if (webView == null)
                {
                    Debug.WriteLine("[CTRL+P MANAGER] ERRORE: WebView nullo");
                    return false;
                }

                bool eseguito = await EseguiCtrlP.Esegui(webView);

                if (eseguito)
                {
                    Debug.WriteLine("[CTRL+P MANAGER] CTRL+P eseguito con successo");
                }
                else
                {
                    Debug.WriteLine("[CTRL+P MANAGER] ERRORE: CTRL+P fallito");
                }

                Debug.WriteLine("╔════════════════════════════════════════════════════════╗");
                Debug.WriteLine("║   CTRL+P MANAGER - COMPLETATO                          ║");
                Debug.WriteLine("╚════════════════════════════════════════════════════════╝");

                return eseguito;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[CTRL+P MANAGER] ERRORE: {ex.Message}");
                Debug.WriteLine($"[CTRL+P MANAGER] StackTrace: {ex.StackTrace}");
                return false;
            }
        }
    }
}
using Microsoft.Web.WebView2.Wpf;

namespace AlertAutomator._02_LatoFunzioni._02_EngineAutomation._02_AzioniProduzione._01_CtrlP
{
    public class CollegatiAlBrowser
    {
        public static WebView2 OttieniWebView()
        {
            return null;
        }
    }
}
using System;using System.Diagnostics;
using System.Diagnostics;
using System.Threading.Tasks;
using Microsoft.Web.WebView2.Wpf;

namespace AlertAutomator._02_LatoFunzioni._02_EngineAutomation._02_AzioniProduzione._01_CtrlP
{
    public class EseguiCtrlP
    {
        public static async Task<bool> Esegui(WebView2 webView)
        {
            try
            {
                Debug.WriteLine("[CTRL+P] Inizio esecuzione combinazione tasti");

                await webView.CoreWebView2.CallDevToolsProtocolMethodAsync(
                    "Input.dispatchKeyEvent",
                    @"{
                        ""type"": ""keyDown"",
                        ""key"": ""Control"",
                        ""code"": ""ControlLeft"",
                        ""windowsVirtualKeyCode"": 17,
                        ""nativeVirtualKeyCode"": 17,
                        ""modifiers"": 2
                    }"
                );

                await Task.Delay(50);

                await webView.CoreWebView2.CallDevToolsProtocolMethodAsync(
                    "Input.dispatchKeyEvent",
                    @"{
                        ""type"": ""keyDown"",
                        ""key"": ""p"",
                        ""code"": ""KeyP"",
                        ""windowsVirtualKeyCode"": 80,
                        ""nativeVirtualKeyCode"": 80,
                        ""modifiers"": 2
                    }"
                );

                await Task.Delay(50);

                await webView.CoreWebView2.CallDevToolsProtocolMethodAsync(
                    "Input.dispatchKeyEvent",
                    @"{
                        ""type"": ""keyUp"",
                        ""key"": ""p"",
                        ""code"": ""KeyP"",
                        ""windowsVirtualKeyCode"": 80,
                        ""nativeVirtualKeyCode"": 80,
                        ""modifiers"": 2
                    }"
                );

                await Task.Delay(50);

                await webView.CoreWebView2.CallDevToolsProtocolMethodAsync(
                    "Input.dispatchKeyEvent",
                    @"{
                        ""type"": ""keyUp"",
                        ""key"": ""Control"",
                        ""code"": ""ControlLeft"",
                        ""windowsVirtualKeyCode"": 17,
                        ""nativeVirtualKeyCode"": 17,
                        ""modifiers"": 0
                    }"
                );

                await Task.Delay(80);

                Debug.WriteLine("[CTRL+P] Combinazione tasti completata");

                Debug.WriteLine("[CTRL+P] Verifica apertura dialog (max 3.5s)...");

                bool dialogAperto = await AttendieVerificaDialog(webView, 3500);

                if (dialogAperto)
                {
                    Debug.WriteLine("[CTRL+P] Dialog aperto con successo");
                    return true;
                }
                else
                {
                    Debug.WriteLine("[CTRL+P] Dialog NON rilevato dopo 3.5s - ATTIVAZIONE FALLBACK");

                    bool fallbackResult = await EseguiFallbackDoppioClick(webView);

                    if (fallbackResult)
                    {
                        await Task.Delay(500);

                        bool dialogApertoDopoFallback = await VerificaDialogAperto(webView);

                        if (dialogApertoDopoFallback)
                        {
                            Debug.WriteLine("[CTRL+P FALLBACK] Dialog aperto con successo tramite doppio click");
                            return true;
                        }
                    }

                    Debug.WriteLine("[CTRL+P FALLBACK] Fallimento - dialog non aperto");
                    return false;
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[CTRL+P] ERRORE: {ex.Message}");
                return false;
            }
        }

        private static async Task<bool> AttendieVerificaDialog(WebView2 webView, int maxWaitMs)
        {
            try
            {
                int intervalloControllo = 200;
                int tempoTrascorso = 0;

                while (tempoTrascorso < maxWaitMs)
                {
                    bool dialogAperto = await VerificaDialogAperto(webView);

                    if (dialogAperto)
                    {
                        return true;
                    }

                    await Task.Delay(intervalloControllo);
                    tempoTrascorso += intervalloControllo;
                }

                return false;
            }
            catch
            {
                return false;
            }
        }

        private static async Task<bool> VerificaDialogAperto(WebView2 webView)
        {
            try
            {
                string scriptVerifica = @"
                    (function() {
                        var dialogSpecifico = document.querySelector('#overlap-manager-root > div:nth-child(3) > div > div.dialog-qyCw0PaN.dialog-b8SxMnzX.dialog-aRAWUDhF.rounded-aRAWUDhF.shadowed-aRAWUDhF > div > div.scrollable-vwgPOHG8 > div');
                        
                        if (dialogSpecifico && dialogSpecifico.offsetParent !== null) {
                            return 'dialog_open';
                        }
                        
                        var dialogSelector = '#overlap-manager-root > div:nth-child(2) > div > div';
                        var dialog = document.querySelector(dialogSelector);
                        
                        if (dialog) {
                            return 'found';
                        }
                        
                        var modals = document.querySelectorAll('[role=""dialog""], .dialog, .modal');
                        if (modals.length > 0) {
                            return 'modal_found';
                        }
                        
                        return 'not_found';
                    })();
                ";

                string risultato = await webView.ExecuteScriptAsync(scriptVerifica);
                risultato = risultato.Trim('"');

                bool trovato = !risultato.Contains("not_found");

                return trovato;
            }
            catch
            {
                return false;
            }
        }

        private static async Task<bool> EseguiFallbackDoppioClick(WebView2 webView)
        {
            try
            {
                Debug.WriteLine("[CTRL+P FALLBACK] Ricerca elemento StrategyA per doppio click preciso");

                string scriptTrova = @"
                    (function() {
                        var elementi = document.querySelectorAll('.item-l31H9iuA, .titleWrapper-l31H9iuA, .mainTitle-l31H9iuA');
                        for (var i = 0; i < elementi.length; i++) {
                            var testo = elementi[i].textContent || '';
                            if (testo.includes('StrategyA')) {
                                var rect = elementi[i].getBoundingClientRect();
                                return {
                                    trovato: true,
                                    x: rect.left + rect.width / 2,
                                    y: rect.top + rect.height / 2,
                                    elemento: elementi[i].tagName,
                                    classe: elementi[i].className,
                                    testo: testo.substring(0, 50)
                                };
                            }
                        }
                        
                        var tuttiElementi = document.querySelectorAll('*');
                        for (var i = 0; i < tuttiElementi.length; i++) {
                            var testo = tuttiElementi[i].textContent || '';
                            if (testo.startsWith('StrategyA 2.3')) {
                                var rect = tuttiElementi[i].getBoundingClientRect();
                                return {
                                    trovato: true,
                                    x: rect.left + rect.width / 2,
                                    y: rect.top + rect.height / 2,
                                    elemento: tuttiElementi[i].tagName,
                                    classe: tuttiElementi[i].className,
                                    testo: testo.substring(0, 50)
                                };
                            }
                        }
                        return { trovato: false };
                    })();
                ";

                string risultatoTrova = await webView.ExecuteScriptAsync(scriptTrova);

                if (!risultatoTrova.Contains("\"trovato\":true"))
                {
                    Debug.WriteLine("[CTRL+P FALLBACK] Elemento StrategyA non trovato - fallback non possibile");
                    return false;
                }

                int xStart = risultatoTrova.IndexOf("\"x\":") + 4;
                int xEnd = risultatoTrova.IndexOf(",", xStart);
                string xStr = risultatoTrova.Substring(xStart, xEnd - xStart);
                double x = double.Parse(xStr, System.Globalization.CultureInfo.InvariantCulture);

                int yStart = risultatoTrova.IndexOf("\"y\":") + 4;
                int yEnd = risultatoTrova.IndexOf(",", yStart);
                if (yEnd == -1) yEnd = risultatoTrova.IndexOf("}", yStart);
                string yStr = risultatoTrova.Substring(yStart, yEnd - yStart);
                double y = double.Parse(yStr, System.Globalization.CultureInfo.InvariantCulture);

                Debug.WriteLine($"[CTRL+P FALLBACK] StrategyA trovato - doppio click a coordinate ({x}, {y})");

                var coreWebView2 = webView.CoreWebView2;

                await coreWebView2.CallDevToolsProtocolMethodAsync(
                    "Input.dispatchMouseEvent",
                    $@"{{
                        ""type"": ""mousePressed"",
                        ""x"": {x.ToString(System.Globalization.CultureInfo.InvariantCulture)},
                        ""y"": {y.ToString(System.Globalization.CultureInfo.InvariantCulture)},
                        ""button"": ""left"",
                        ""clickCount"": 1,
                        ""buttons"": 1
                    }}");

                await Task.Delay(50);

                await coreWebView2.CallDevToolsProtocolMethodAsync(
                    "Input.dispatchMouseEvent",
                    $@"{{
                        ""type"": ""mouseReleased"",
                        ""x"": {x.ToString(System.Globalization.CultureInfo.InvariantCulture)},
                        ""y"": {y.ToString(System.Globalization.CultureInfo.InvariantCulture)},
                        ""button"": ""left"",
                        ""clickCount"": 1,
                        ""buttons"": 0
                    }}");

                await Task.Delay(100);

                await coreWebView2.CallDevToolsProtocolMethodAsync(
                    "Input.dispatchMouseEvent",
                    $@"{{
                        ""type"": ""mousePressed"",
                        ""x"": {x.ToString(System.Globalization.CultureInfo.InvariantCulture)},
                        ""y"": {y.ToString(System.Globalization.CultureInfo.InvariantCulture)},
                        ""button"": ""left"",
                        ""clickCount"": 2,
                        ""buttons"": 1
                    }}");

                await Task.Delay(50);

                await coreWebView2.CallDevToolsProtocolMethodAsync(
                    "Input.dispatchMouseEvent",
                    $@"{{
                        ""type"": ""mouseReleased"",
                        ""x"": {x.ToString(System.Globalization.CultureInfo.InvariantCulture)},
                        ""y"": {y.ToString(System.Globalization.CultureInfo.InvariantCulture)},
                        ""button"": ""left"",
                        ""clickCount"": 2,
                        ""buttons"": 0
                    }}");

                Debug.WriteLine("[CTRL+P FALLBACK] Doppio click su StrategyA completato");
                return true;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[CTRL+P FALLBACK] ERRORE: {ex.Message}");
                return false;
            }
        }
    }
}
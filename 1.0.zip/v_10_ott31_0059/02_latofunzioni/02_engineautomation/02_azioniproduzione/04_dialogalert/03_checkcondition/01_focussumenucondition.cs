using System;
using System.Diagnostics;
using System.Threading.Tasks;
using Microsoft.Web.WebView2.Wpf;

namespace AlertAutomator._02_LatoFunzioni._02_EngineAutomation._02_AzioniProduzione._04_DialogAlert._03_CheckCondition
{
    public class FocusMenuCondition
    {
        public static async Task<bool> Esegui(WebView2 webView)
        {
            try
            {
                Debug.WriteLine("FOCUS MENU CONDITION: INIZIO FOCUS SU CAMPO CONDITION");
                
                string scriptFocus = @"
                    (function() {
                        // Selettore principale del container
                        var container = document.querySelector('#overlap-manager-root > div:nth-child(3) > div > div.dialog-qyCw0PaN.dialog-Tjty10T7.popup-wOMsQ0U9.dialog-aRAWUDhF.rounded-aRAWUDhF.shadowed-aRAWUDhF > form > div.contentWrapper-XZUCVcPz.permanentScroll-XZUCVcPz > div > div:nth-child(3) > div > fieldset > div.fields-column-left-Fddz5wLp > div > div');
                        
                        if (container) {
                            // Cerca lo span cliccabile dentro
                            var span = container.querySelector('span');
                            if (span) {
                                span.focus();
                                console.log('Focus su span condition');
                                return 'FOCUS_OK';
                            }
                        }
                        
                        // Fallback - cerca con classi
                        var element = document.querySelector('.input-LM2kIa9B.baseinput-LM2kIa9B');
                        if (element) {
                            element.focus();
                            return 'FOCUS_OK_FALLBACK';
                        }
                        
                        return 'NOT_FOUND';
                    })();
                ";

                string result = await webView.CoreWebView2.ExecuteScriptAsync(scriptFocus);
                result = result.Trim('"');
                
                Debug.WriteLine($"FOCUS MENU CONDITION: Risultato = {result}");
                
                await Task.Delay(100);
                return result != "NOT_FOUND";
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"FOCUS MENU CONDITION ERRORE: {ex.Message}");
                return false;
            }
        }
    }
}
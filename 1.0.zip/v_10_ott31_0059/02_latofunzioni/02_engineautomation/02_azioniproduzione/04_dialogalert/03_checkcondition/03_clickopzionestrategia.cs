﻿using System;using System.Diagnostics; // Sistema base
using System.Threading.Tasks; // Task asincroni
using Microsoft.Web.WebView2.Wpf; // WebView2
using Microsoft.Web.WebView2.Core; // Core WebView2


namespace AlertAutomator._02_LatoFunzioni._02_EngineAutomation._02_AzioniProduzione._04_DialogAlert._03_CheckCondition
{
    /// <summary>
    /// Click sull'opzione Strategy nel menu dropdown
    /// </summary>
    public class ClickOpzioneStrategia
    {
        #region Metodo Principale

        /// <summary>
        /// Clicca l'opzione che contiene Strategy o User_ o Price
        /// </summary>
        public static async Task<bool> Esegui(WebView2 webView)
        {
            try
            {
                Debug.WriteLine("CLICK OPZIONE STRATEGIA: ---------═════"); // Log
                Debug.WriteLine("CLICK OPZIONE STRATEGIA: INIZIO SELEZIONE OPZIONE DAL MENU"); // Log
                Debug.WriteLine("CLICK OPZIONE STRATEGIA: ---------═════"); // Log
                Debug.WriteLine("CLICK OPZIONE STRATEGIA: Timestamp: " + DateTime.Now.ToString("HH:mm:ss.fff")); // Log

                // Validazione WebView
                if (webView?.CoreWebView2 == null)
                {
                    Debug.WriteLine("CLICK OPZIONE STRATEGIA ERRORE: WebView o CoreWebView2 null"); // Log errore
                    return false; // Errore
                }

                Debug.WriteLine("CLICK OPZIONE STRATEGIA: Preparazione script selezione..."); // Log

                string scriptSelect = @"
                    (function() {
                        try {
                            console.log('SELECT JS: Script avviato');
                            
                            // Selettore per menu items
                            var menuItemSelector = '.menuItem-LM2kIa9B.item-jFqVJoPk';
                            
                            console.log('SELECT JS: Cerco menu items con selettore: ' + menuItemSelector);
                            
                            var menuItems = document.querySelectorAll(menuItemSelector);
                            console.log('SELECT JS: Trovati ' + menuItems.length + ' menu items');
                            
                            if (menuItems.length === 0) {
                                // Prova selettori alternativi
                                console.log('SELECT JS: Provo selettori alternativi...');
                                
                                var altSelectors = [
                                    '[class*=""menuItem-""][class*=""item-""]',
                                    '[class*=""menuItem-LM2kIa9B""]',
                                    '[class*=""item-jFqVJoPk""]',
                                    '.menuItem-LM2kIa9B',
                                    '[role=""option""]'
                                ];
                                
                                for (var s = 0; s < altSelectors.length; s++) {
                                    menuItems = document.querySelectorAll(altSelectors[s]);
                                    if (menuItems.length > 0) {
                                        console.log('SELECT JS: Trovati ' + menuItems.length + ' items con selettore alternativo ' + (s+1));
                                        break;
                                    }
                                }
                            }
                            
                            if (menuItems.length === 0) {
                                console.log('SELECT JS: ERRORE - Nessun menu item trovato');
                                console.log('SELECT JS: Menu probabilmente non ancora aperto');
                                return JSON.stringify({
                                    success: false,
                                    error: 'Menu items non trovati'
                                });
                            }
                            
                            // Array di testi da cercare (in ordine di priorità)
                            var targetTexts = ['Strategy', 'User_'];
                            var targetItem = null;
                            var textFound = null;
                            
                            console.log('SELECT JS: Cerco opzioni con testo: ' + targetTexts.join(', '));
                            
                            // Cerca l'opzione che contiene uno dei testi target
                            for (var i = 0; i < menuItems.length; i++) {
                                var itemText = menuItems[i].textContent || menuItems[i].innerText || '';
                                console.log('SELECT JS: Item ' + (i+1) + ': ""' + itemText + '""');
                                
                                // Controlla se contiene uno dei testi target
                                for (var j = 0; j < targetTexts.length; j++) {
                                    if (itemText.includes(targetTexts[j])) {
                                        targetItem = menuItems[i];
                                        textFound = targetTexts[j];
                                        console.log('SELECT JS: TROVATO! Item contiene ""' + textFound + '""');
                                        break;
                                    }
                                }
                                
                                if (targetItem) break;
                            }
                            
                            // Se non trova con includes, prova con match case-insensitive
                            if (!targetItem) {
                                console.log('SELECT JS: Ricerca case-insensitive...');
                                for (var i = 0; i < menuItems.length; i++) {
                                    var itemText = (menuItems[i].textContent || menuItems[i].innerText || '').toLowerCase();
                                    
                                    for (var j = 0; j < targetTexts.length; j++) {
                                        if (itemText.includes(targetTexts[j].toLowerCase())) {
                                            targetItem = menuItems[i];
                                            textFound = targetTexts[j];
                                            console.log('SELECT JS: TROVATO (case-insensitive)! Item contiene ""' + textFound + '""');
                                            break;
                                        }
                                    }
                                    
                                    if (targetItem) break;
                                }
                            }
                            
                            if (targetItem) {
                                console.log('SELECT JS: Click su opzione: ""' + targetItem.textContent + '""');
                                
                                // Evidenzia brevemente l'elemento
                                var originalBg = targetItem.style.backgroundColor;
                                targetItem.style.backgroundColor = 'yellow';
                                
                                // Esegui click
                                targetItem.click();
                                
                                // Simula eventi mouse per sicurezza
                                var mouseOver = new MouseEvent('mouseover', { bubbles: true });
                                var mouseDown = new MouseEvent('mousedown', { bubbles: true });
                                var mouseUp = new MouseEvent('mouseup', { bubbles: true });
                                var clickEvent = new MouseEvent('click', { bubbles: true });
                                
                                targetItem.dispatchEvent(mouseOver);
                                targetItem.dispatchEvent(mouseDown);
                                targetItem.dispatchEvent(mouseUp);
                                targetItem.dispatchEvent(clickEvent);
                                
                                // Ripristina colore dopo 100ms
                                setTimeout(function() {
                                    targetItem.style.backgroundColor = originalBg;
                                }, 100);
                                
                                console.log('SELECT JS: Click eseguito con successo');
                                
                                return JSON.stringify({
                                    success: true,
                                    selectedText: targetItem.textContent,
                                    matchedKeyword: textFound
                                });
                            } else {
                                console.log('SELECT JS: ERRORE - Nessuna opzione trovata con i testi cercati');
                                console.log('SELECT JS: Testi cercati: ' + targetTexts.join(', '));
                                
                                // Log tutti i testi trovati per debug
                                var allTexts = [];
                                for (var i = 0; i < menuItems.length; i++) {
                                    allTexts.push(menuItems[i].textContent || menuItems[i].innerText || '');
                                }
                                console.log('SELECT JS: Testi disponibili nel menu: ' + allTexts.join(' | '));
                                
                                return JSON.stringify({
                                    success: false,
                                    error: 'Opzione Strategy/User_/Price non trovata',
                                    availableOptions: allTexts
                                });
                            }
                            
                        } catch (e) {
                            return JSON.stringify({
                                success: false,
                                error: e.toString()
                            });
                        }
                    })();
                ";

                // Esecuzione script
                Debug.WriteLine("CLICK OPZIONE STRATEGIA: Esecuzione selezione..."); // Log
                string result = await webView.CoreWebView2.ExecuteScriptAsync(scriptSelect); // Esegui

                // Parse risultato
                if (!string.IsNullOrEmpty(result) && result != "null")
                {
                    result = result.Trim('"').Replace("\\\"", "\"").Replace("\\\\", "\\"); // Clean JSON
                    Debug.WriteLine("CLICK OPZIONE STRATEGIA: Risposta ricevuta"); // Log

                    if (result.Contains("\"success\":true"))
                    {
                        Debug.WriteLine("CLICK OPZIONE STRATEGIA: Selezione riuscita"); // Log successo
                        
                        // Estrai testo selezionato se disponibile
                        if (result.Contains("selectedText"))
                        {
                            try
                            {
                                var textMatch = System.Text.RegularExpressions.Regex.Match(result, @"""selectedText"":""([^""]+)""");
                                if (textMatch.Success)
                                {
                                    Debug.WriteLine($"CLICK OPZIONE STRATEGIA: Opzione selezionata: '{textMatch.Groups[1].Value}'"); // Log testo
                                }
                            }
                            catch { }
                        }
                        
                        // Estrai keyword matchata
                        if (result.Contains("matchedKeyword"))
                        {
                            try
                            {
                                var keywordMatch = System.Text.RegularExpressions.Regex.Match(result, @"""matchedKeyword"":""([^""]+)""");
                                if (keywordMatch.Success)
                                {
                                    Debug.WriteLine($"CLICK OPZIONE STRATEGIA: Match su keyword: '{keywordMatch.Groups[1].Value}'"); // Log keyword
                                }
                            }
                            catch { }
                        }
                        
                        Debug.WriteLine("CLICK OPZIONE STRATEGIA: ---------═════"); // Log
                        return true; // Successo
                    }
                    else
                    {
                        Debug.WriteLine("CLICK OPZIONE STRATEGIA ERRORE: Selezione fallita"); // Log errore
                    }
                }
                else
                {
                    Debug.WriteLine("CLICK OPZIONE STRATEGIA ERRORE: Nessuna risposta dallo script"); // Log errore
                }

                Debug.WriteLine("CLICK OPZIONE STRATEGIA ERRORE: Selezione non riuscita"); // Log errore
                Debug.WriteLine("CLICK OPZIONE STRATEGIA: ---------═════"); // Log
                return false; // Errore

            }
            catch (Exception ex)
            {
                Debug.WriteLine($"CLICK OPZIONE STRATEGIA ERRORE CRITICO: {ex.Message}"); // Log errore
                Debug.WriteLine($"CLICK OPZIONE STRATEGIA STACK: {ex.StackTrace}"); // Log stack
                return false; // Errore
            }
        }

        #endregion

        #region Helper

     

        #endregion
    }
}
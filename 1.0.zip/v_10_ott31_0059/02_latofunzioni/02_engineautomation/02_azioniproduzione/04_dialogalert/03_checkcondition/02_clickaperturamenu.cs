using System;
using System.Diagnostics;
using System.Threading.Tasks;
using Microsoft.Web.WebView2.Wpf;

namespace AlertAutomator._02_LatoFunzioni._02_EngineAutomation._02_AzioniProduzione._04_DialogAlert._03_CheckCondition
{
    public class ClickAperturaMenu
    {
        public static async Task<bool> Esegui(WebView2 webView)
        {
            try
            {
                Debug.WriteLine("CLICK APERTURA MENU: Click su campo condition");

                // UN SOLO CLICK - stesso metodo di fillparametri
                string scriptClick = @"
                    (function() {
                        var element = document.querySelector('#overlap-manager-root > div:nth-child(3) > div > div.dialog-qyCw0PaN.dialog-Tjty10T7.popup-wOMsQ0U9.dialog-aRAWUDhF.rounded-aRAWUDhF.shadowed-aRAWUDhF > form > div.contentWrapper-XZUCVcPz.permanentScroll-XZUCVcPz > div > div:nth-child(3) > div > fieldset > div.fields-column-left-Fddz5wLp > div > div > span');
                        
                        if (element) {
                            element.click();
                            element.focus();
                            console.log('CLICK CONDITION: Cliccato su span condition');
                            return 'clicked_condition_span';
                        }
                        
                        // Fallback se non trova lo span
                        var container = document.querySelector('#overlap-manager-root > div:nth-child(3) > div > div.dialog-qyCw0PaN.dialog-Tjty10T7.popup-wOMsQ0U9.dialog-aRAWUDhF.rounded-aRAWUDhF.shadowed-aRAWUDhF > form > div.contentWrapper-XZUCVcPz.permanentScroll-XZUCVcPz > div > div:nth-child(3) > div > fieldset > div.fields-column-left-Fddz5wLp > div > div');
                        
                        if (container) {
                            container.click();
                            console.log('CLICK CONDITION: Cliccato su container');
                            return 'clicked_condition_container';
                        }
                        
                        return 'not_found';
                    })();
                ";
                
                var risultato = await webView.ExecuteScriptAsync(scriptClick);
                risultato = risultato.Trim('"');
                
                Debug.WriteLine($"CLICK APERTURA MENU: Risultato = {risultato}");
                
                // Pausa per permettere al menu di aprirsi
                await Task.Delay(300);
                
                if (risultato != "not_found")
                {
                    // Verifica se il menu si � aperto
                    string verifyScript = @"
                        (function() {
                            var menuItems = document.querySelectorAll('.menuItem-LM2kIa9B, [class*=""menuItem""]');
                            return menuItems.length;
                        })();
                    ";
                    
                    string menuCount = await webView.CoreWebView2.ExecuteScriptAsync(verifyScript);
                    Debug.WriteLine($"CLICK APERTURA MENU: Menu items trovati = {menuCount}");
                    
                    return int.Parse(menuCount) > 0;
                }
                else
                {
                    Debug.WriteLine("CLICK APERTURA MENU: Elemento non trovato");
                    return false;
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"CLICK APERTURA MENU ERRORE: {ex.Message}");
                return false;
            }
        }
    }
}
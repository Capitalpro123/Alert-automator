﻿using System;using System.Diagnostics; // Sistema base
using System.Threading.Tasks; // Task asincroni
using Microsoft.Web.WebView2.Wpf; // WebView2
using Microsoft.Web.WebView2.Core; // Core WebView2


namespace AlertAutomator._02_LatoFunzioni._02_EngineAutomation._02_AzioniProduzione._04_DialogAlert._06_CheckAlertMessage
{
    /// <summary>
    /// Verifica che alert message sia corretto e fa click sul campo
    /// </summary>
    public class CheckAlertMessage
    {
        #region Metodo Principale

        /// <summary>
        /// Verifica contenuto di alert message e clicca sempre sul campo
        /// </summary>
        public static async Task<(bool successo, bool messaggioCorretto)> Esegui(WebView2 webView)
        {
            try
            {
                Debug.WriteLine("CHECK ALERT MESSAGE: ---------═════"); // Log
                Debug.WriteLine("CHECK ALERT MESSAGE: INIZIO VERIFICA E CLICK SU MESSAGE"); // Log
                Debug.WriteLine("CHECK ALERT MESSAGE: ---------═════"); // Log

                // Validazione WebView
                if (webView?.CoreWebView2 == null)
                {
                    Debug.WriteLine("CHECK ALERT MESSAGE ERRORE: WebView non valido"); // Log errore
                    return (false, false); // Fallimento
                }

                // Valore atteso per alert message
                string valoreAtteso = "{{strategy.order.alert_message}}";
                Debug.WriteLine($"CHECK ALERT MESSAGE: Valore atteso: '{valoreAtteso}'"); // Log

                // Script per verificare alert message e fare click
                string scriptCheckAndClick = @"
                    (function() {
                        try {
                            var logs = [];
                            logs.push('CHECK JS: Script avviato');
                            
                            // Selettore principale
                            var textareaSelector = '#alert-message';
                            var textarea = document.querySelector(textareaSelector);
                            
                            if (!textarea) {
                                logs.push('CHECK JS: Textarea non trovato con ID, provo alternative');
                                textarea = document.querySelector('textarea[id=""alert-message""]') ||
                                          document.querySelector('textarea[name=""alert-message""]') ||
                                          document.querySelector('textarea[placeholder*=""message"" i]') ||
                                          document.querySelector('textarea');
                            }
                            
                            if (!textarea) {
                                logs.push('CHECK JS: ERRORE - Campo alert message non trovato');
                                return JSON.stringify({
                                    success: false,
                                    found: false,
                                    logs: logs
                                });
                            }
                            
                            logs.push('CHECK JS: Campo trovato - ' + textarea.tagName);
                            logs.push('CHECK JS: ID: ' + (textarea.id || 'nessuno'));
                            
                            // Leggi valore corrente
                            var currentValue = textarea.value || '';
                            logs.push('CHECK JS: Valore corrente: ""' + currentValue + '""');
                            
                            // SEMPRE FAI CLICK SUL CAMPO
                            logs.push('CHECK JS: Eseguo click sul campo...');
                            textarea.click();
                            textarea.focus();
                            
                            // Dispatch eventi click
                            var clickEvent = new MouseEvent('click', {
                                bubbles: true,
                                cancelable: true,
                                view: window
                            });
                            textarea.dispatchEvent(clickEvent);
                            
                            logs.push('CHECK JS: Click eseguito');
                            
                            return JSON.stringify({
                                success: true,
                                found: true,
                                value: currentValue,
                                clicked: true,
                                logs: logs
                            });
                            
                        } catch (e) {
                            return JSON.stringify({
                                success: false,
                                error: e.toString()
                            });
                        }
                    })();
                "; // Fine script

                // Esegui verifica e click
                Debug.WriteLine("CHECK ALERT MESSAGE: Lettura valore e click sul campo..."); // Log
                string risultatoJson = await webView.CoreWebView2.ExecuteScriptAsync(scriptCheckAndClick); // Esegui
                
                // Pulisci risultato
                risultatoJson = risultatoJson.Trim('"').Replace("\\\"", "\"").Replace("\\n", "\n"); // Pulisci
                
                // Parse logs
                try 
                {
                    int logsStart = risultatoJson.IndexOf("\"logs\":[");
                    if (logsStart > -1) 
                    {
                        logsStart += 8;
                        int logsEnd = risultatoJson.LastIndexOf("]");
                        if (logsEnd > logsStart) 
                        {
                            string logsSection = risultatoJson.Substring(logsStart, logsEnd - logsStart);
                            string[] logEntries = logsSection.Split(new[] { "\",\"" }, StringSplitOptions.None);
                            
                            foreach (string logEntry in logEntries)
                            {
                                string cleanLog = logEntry.Trim('"', '[', ']');
                                Debug.WriteLine("  JS> " + cleanLog); // Log
                            }
                        }
                    }
                }
                catch { }

                // Parse risultato
                bool success = risultatoJson.Contains("\"success\":true"); // Verifica successo
                bool found = risultatoJson.Contains("\"found\":true"); // Verifica presenza campo
                bool clicked = risultatoJson.Contains("\"clicked\":true"); // Verifica click
                
                if (!success)
                {
                    Debug.WriteLine("CHECK ALERT MESSAGE ERRORE: Script verifica fallito"); // Log errore
                    return (false, false); // Fallimento
                }

                if (!found)
                {
                    Debug.WriteLine("CHECK ALERT MESSAGE ERRORE: Campo alert message non trovato"); // Log errore
                    return (true, false); // Successo verifica, messaggio non corretto
                }

                if (clicked)
                {
                    Debug.WriteLine("CHECK ALERT MESSAGE: ✓ Click eseguito sul campo"); // Log
                }

                // Estrai valore corrente
                int valueStart = risultatoJson.IndexOf("\"value\":\""); // Trova
                string currentValue = "";
                
                if (valueStart > -1)
                {
                    valueStart += 9; // Sposta dopo "value":"
                    int valueEnd = risultatoJson.IndexOf("\"", valueStart); // Trova fine
                    currentValue = risultatoJson.Substring(valueStart, valueEnd - valueStart); // Estrai
                    Debug.WriteLine($"CHECK ALERT MESSAGE: Valore corrente: '{currentValue}'"); // Log
                }

                // Confronta con valore atteso
                bool isCorrect = currentValue == valoreAtteso; // Verifica

                if (isCorrect)
                {
                    Debug.WriteLine("CHECK ALERT MESSAGE: ✓ Messaggio corretto"); // Log successo
                    await Task.Delay(30); // Pausa dopo click
                    Debug.WriteLine("CHECK ALERT MESSAGE: ---------═════"); // Log
                    return (true, true); // Successo, messaggio corretto
                }
                else
                {
                    Debug.WriteLine($"CHECK ALERT MESSAGE: ⚠ Messaggio diverso da atteso"); // Log warning
                    Debug.WriteLine($"CHECK ALERT MESSAGE: Atteso: '{valoreAtteso}'"); // Log
                    Debug.WriteLine($"CHECK ALERT MESSAGE: Trovato: '{currentValue}'"); // Log
                    
                    // Se non corretto, proviamo a impostarlo
                    Debug.WriteLine("CHECK ALERT MESSAGE: Provo a impostare il valore corretto..."); // Log
                    
                    string scriptSetMessage = $@"
                        (function() {{
                            try {{
                                var textarea = document.querySelector('#alert-message') ||
                                              document.querySelector('textarea[id=""alert-message""]') ||
                                              document.querySelector('textarea');
                                
                                if (textarea) {{
                                    // Pulisci campo
                                    textarea.value = '';
                                    textarea.dispatchEvent(new Event('input', {{ bubbles: true }}));
                                    
                                    // Imposta nuovo valore
                                    textarea.value = '{valoreAtteso}';
                                    textarea.dispatchEvent(new Event('input', {{ bubbles: true }}));
                                    textarea.dispatchEvent(new Event('change', {{ bubbles: true }}));
                                    
                                    // Click finale per conferma
                                    textarea.click();
                                    
                                    return JSON.stringify({{
                                        set: true,
                                        newValue: textarea.value
                                    }});
                                }}
                                return JSON.stringify({{
                                    set: false,
                                    error: 'Campo non trovato'
                                }});
                            }} catch (e) {{
                                return JSON.stringify({{
                                    set: false,
                                    error: e.toString()
                                }});
                            }}
                        }})();
                    "; // Script set
                    
                    string setResult = await webView.CoreWebView2.ExecuteScriptAsync(scriptSetMessage); // Imposta
                    setResult = setResult.Trim('"').Replace("\\\"", "\""); // Pulisci
                    
                    if (setResult.Contains("\"set\":true"))
                    {
                        Debug.WriteLine("CHECK ALERT MESSAGE: Messaggio impostato al valore corretto"); // Log
                        
                        // Verifica finale
                        await Task.Delay(30); // Pausa
                        
                        string scriptVerifica = @"
                            (function() {
                                var textarea = document.querySelector('#alert-message') || document.querySelector('textarea');
                                return textarea ? textarea.value : '';
                            })();
                        "; // Verifica
                        
                        string finalValue = await webView.CoreWebView2.ExecuteScriptAsync(scriptVerifica); // Verifica
                        finalValue = finalValue.Trim('"'); // Pulisci
                        
                        Debug.WriteLine($"CHECK ALERT MESSAGE: Valore finale: '{finalValue}'"); // Log
                        Debug.WriteLine("CHECK ALERT MESSAGE: ---------═════"); // Log
                        
                        return (true, finalValue == valoreAtteso); // Successo dopo correzione
                    }
                    
                    Debug.WriteLine("CHECK ALERT MESSAGE: Non riuscito a impostare valore"); // Log
                    Debug.WriteLine("CHECK ALERT MESSAGE: ---------═════"); // Log
                    return (true, false); // Successo verifica, messaggio non corretto
                }

            }
            catch (Exception ex)
            {
                Debug.WriteLine($"CHECK ALERT MESSAGE ERRORE CRITICO: {ex.Message}"); // Log errore
                return (false, false); // Fallimento
            }
        }

        #endregion

        #region Helper

       

        #endregion
    }
}
using System;using System.Diagnostics; // Sistema base
using System.Threading.Tasks; // Task asincroni
using Microsoft.Web.WebView2.Wpf; // WebView2


namespace AlertAutomator._02_LatoFunzioni._02_EngineAutomation._02_AzioniProduzione._04_DialogAlert._05_InsertAlertName
{
    /// <summary>
    /// Conferma inserimento con ENTER
    /// USA: DevTools Protocol per simulare pressione tasto
    /// </summary>
    public class ConfermaInserimento
    {
        #region Metodo Principale

        /// <summary>
        /// Preme ENTER per confermare il valore digitato
        /// </summary>
        public static async Task<bool> Esegui(WebView2 webView)
        {
            try
            {
                Debug.WriteLine("CONFERMA INSERIMENTO: ---------═════"); // Log
                Debug.WriteLine("CONFERMA INSERIMENTO: INVIO ENTER PER CONFERMA"); // Log
                Debug.WriteLine("CONFERMA INSERIMENTO: ---------═════"); // Log

                // Validazione WebView
                if (webView?.CoreWebView2 == null)
                {
                    Debug.WriteLine("CONFERMA INSERIMENTO ERRORE: WebView non valido"); // Log errore
                    return false; // Fallimento
                }

                // Verifica che il focus sia ancora sul campo
                string scriptCheckFocus = @"
                    (function() {
                        var input = document.querySelector('#alert-name') ||
                                   document.querySelector('input[id=""alert-name""]') ||
                                   document.querySelector('input[name=""alert-name""]');
                        
                        if (input && document.activeElement === input) {
                            return 'focused';
                        } else if (input) {
                            input.focus();
                            return 'refocused';
                        }
                        return 'not_found';
                    })();
                "; // Script check focus

                string focusResult = await webView.CoreWebView2.ExecuteScriptAsync(scriptCheckFocus); // Verifica
                Debug.WriteLine($"CONFERMA INSERIMENTO: Stato focus: {focusResult}"); // Log

                // Pausa pre-ENTER
                Debug.WriteLine("CONFERMA INSERIMENTO: Attesa pre-ENTER (100ms)..."); // Log
                await Task.Delay(10); // 100ms prima di ENTER

                // ============================================
                // ENTER Down
                // ============================================
                Debug.WriteLine("CONFERMA INSERIMENTO: Invio ENTER keyDown..."); // Log
                await webView.CoreWebView2.CallDevToolsProtocolMethodAsync(
                    "Input.dispatchKeyEvent",
                    @"{
                        ""type"": ""keyDown"",
                        ""key"": ""Enter"",
                        ""code"": ""Enter"",
                        ""windowsVirtualKeyCode"": 13,
                        ""nativeVirtualKeyCode"": 13
                    }"
                ); // Enter giù

                Debug.WriteLine("CONFERMA INSERIMENTO: ✓ ENTER KeyDown inviato"); // Log down

                // Pausa realistica tra down e up
                await Task.Delay(10); // 50ms tra down e up

                // ============================================
                // ENTER Up
                // ============================================
                Debug.WriteLine("CONFERMA INSERIMENTO: Invio ENTER keyUp..."); // Log
                await webView.CoreWebView2.CallDevToolsProtocolMethodAsync(
                    "Input.dispatchKeyEvent",
                    @"{
                        ""type"": ""keyUp"",
                        ""key"": ""Enter"",
                        ""code"": ""Enter"",
                        ""windowsVirtualKeyCode"": 13,
                        ""nativeVirtualKeyCode"": 13
                    }"
                ); // Enter su

    

                // Pausa post-ENTER per elaborazione
      
                await Task.Delay(50); // 500ms per assicurare elaborazione

                // Verifica che il valore sia stato salvato
                string scriptVerifica = @"
                    (function() {
                        var input = document.querySelector('#alert-name') ||
                                   document.querySelector('input[id=""alert-name""]') ||
                                   document.querySelector('input[name=""alert-name""]');
                        
                        if (input) {
                            // Controlla se il campo ha perso focus (segno che ENTER ha funzionato)
                            var hasFocus = document.activeElement === input;
                            return JSON.stringify({
                                value: input.value,
                                hasFocus: hasFocus
                            });
                        }
                        
                        return JSON.stringify({
                            value: '',
                            hasFocus: false
                        });
                    })();
                "; // Script verifica

                string verificaResult = await webView.CoreWebView2.ExecuteScriptAsync(scriptVerifica); // Verifica
                verificaResult = verificaResult.Trim('"').Replace("\\\"", "\""); // Pulisci

                // Log risultato verifica
                if (verificaResult.Contains("hasFocus\":false"))
                {
                    Debug.WriteLine("CONFERMA INSERIMENTO: ✓ Campo ha perso focus (ENTER processato)"); // Log
                }
                else
                {
                    Debug.WriteLine("CONFERMA INSERIMENTO: ⚠ Campo ancora in focus"); // Log warning
                }

                // Estrai valore salvato
                int valueStart = verificaResult.IndexOf("\"value\":\"");
                if (valueStart > -1)
                {
                    valueStart += 9;
                    int valueEnd = verificaResult.IndexOf("\"", valueStart);
                    string savedValue = verificaResult.Substring(valueStart, valueEnd - valueStart);
                    Debug.WriteLine($"CONFERMA INSERIMENTO: Valore salvato: '{savedValue}'"); // Log
                }

                Debug.WriteLine("CONFERMA INSERIMENTO: ✓ Conferma completata con successo"); // Log successo
                Debug.WriteLine("CONFERMA INSERIMENTO: ---------═════"); // Log
                
                return true; // Successo
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"CONFERMA INSERIMENTO ERRORE: {ex.Message}"); // Log errore
                return false; // Fallimento
            }
        }

        #endregion

       
    }
}
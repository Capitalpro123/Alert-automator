using System;using System.Diagnostics;
using System.Collections.Generic;
using System.Diagnostics;

namespace AlertAutomator._02_LatoFunzioni._02_EngineAutomation._02_AzioniProduzione._04_DialogAlert._05_InsertAlertName
{
    public class LeggiValoreDaPortfolio
    {
        public static string Esegui(Dictionary<string, string> riga)
        {
            try
            {
                Debug.WriteLine("[LEGGI VALORE DA PORTFOLIO] Lettura alert name dalla riga");

                if (riga == null || riga.Count == 0)
                {
                    Debug.WriteLine("[LEGGI VALORE DA PORTFOLIO] ERRORE: Riga vuota o nulla");
                    return string.Empty;
                }

                // Alert name è nella colonna A (UserID)
                if (riga.ContainsKey("A"))
                {
                    string alertName = riga["A"];
                    Debug.WriteLine($"[LEGGI VALORE DA PORTFOLIO] Alert name letto: '{alertName}'");
                    return alertName;
                }
                else
                {
                    Debug.WriteLine("[LEGGI VALORE DA PORTFOLIO] WARNING: Colonna A non trovata");
                    return string.Empty;
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[LEGGI VALORE DA PORTFOLIO] ERRORE: {ex.Message}");
                return string.Empty;
            }
        }
    }
}
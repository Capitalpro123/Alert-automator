using System;using System.Diagnostics;
using System.Diagnostics;
using System.Threading.Tasks;
using Microsoft.Web.WebView2.Wpf;
using Microsoft.Web.WebView2.Core;

namespace AlertAutomator._02_LatoFunzioni._02_EngineAutomation._02_AzioniProduzione._04_DialogAlert._05_InsertAlertName
{
    public class InserisciValoreNellInput
    {
        public static async Task<bool> Esegui(WebView2 webView, string alertName)
        {
            try
            {
                Debug.WriteLine("[INSERISCI VALORE INPUT] Inizio inserimento");
                Debug.WriteLine($"[INSERISCI VALORE INPUT] Valore da inserire: '{alertName}'");

                if (webView?.CoreWebView2 == null)
                {
                    Debug.WriteLine("[INSERISCI VALORE INPUT] ERRORE: WebView non valido");
                    return false;
                }

                if (string.IsNullOrWhiteSpace(alertName))
                {
                    alertName = "Alert";
                    Debug.WriteLine($"[INSERISCI VALORE INPUT] Uso valore default '{alertName}'");
                }

                Debug.WriteLine($"[INSERISCI VALORE INPUT] Lunghezza testo = {alertName.Length} caratteri");

                Debug.WriteLine("[INSERISCI VALORE INPUT] FASE 1 - Focus e pulizia campo");

                string scriptPrepara = @"
                    (function() {
                        try {
                            var logs = [];
                            logs.push('PREPARA JS: Inizio preparazione campo');
                            
                            var input = document.querySelector('#alert-name') ||
                                       document.querySelector('input[id=""alert-name""]') ||
                                       document.querySelector('input[name=""alert-name""]');
                            
                            if (!input) {
                                logs.push('PREPARA JS: ERRORE - Campo non trovato');
                                return JSON.stringify({
                                    success: false,
                                    found: false,
                                    logs: logs
                                });
                            }
                            
                            logs.push('PREPARA JS: Campo trovato');
                            
                            input.focus();
                            input.click();
                            logs.push('PREPARA JS: Focus eseguito');
                            
                            input.select();
                            logs.push('PREPARA JS: Testo selezionato');
                            
                            input.value = '';
                            logs.push('PREPARA JS: Campo pulito');
                            
                            return JSON.stringify({
                                success: true,
                                found: true,
                                logs: logs
                            });
                            
                        } catch (e) {
                            return JSON.stringify({
                                success: false,
                                error: e.toString()
                            });
                        }
                    })();
                ";

                Debug.WriteLine("[INSERISCI VALORE INPUT] Preparazione campo...");
                string risultatoPrepara = await webView.CoreWebView2.ExecuteScriptAsync(scriptPrepara);
                risultatoPrepara = risultatoPrepara.Trim('"').Replace("\\\"", "\"");

                bool campoPreparato = risultatoPrepara.Contains("\"success\":true");
                if (!campoPreparato)
                {
                    Debug.WriteLine("[INSERISCI VALORE INPUT] ERRORE: Impossibile preparare campo");
                    return false;
                }

                Debug.WriteLine("[INSERISCI VALORE INPUT] Campo preparato");

                await Task.Delay(100);

                Debug.WriteLine("[INSERISCI VALORE INPUT] FASE 2 - Digitazione caratteri");

                int caratteriDigitati = 0;

                foreach (char carattere in alertName)
                {
                    try
                    {
                        await webView.CoreWebView2.CallDevToolsProtocolMethodAsync(
                            "Input.dispatchKeyEvent",
                            @"{
                                ""type"": ""char"",
                                ""text"": """ + carattere + @"""
                            }"
                        );

                        caratteriDigitati++;

                        if (caratteriDigitati % 5 == 0 || caratteriDigitati == alertName.Length)
                        {
                            Debug.WriteLine($"[INSERISCI VALORE INPUT] Progresso {caratteriDigitati}/{alertName.Length}");
                        }

                        await Task.Delay(30);
                    }
                    catch (Exception charEx)
                    {
                        Debug.WriteLine($"[INSERISCI VALORE INPUT] ERRORE: Errore carattere '{carattere}': {charEx.Message}");
                    }
                }

                Debug.WriteLine($"[INSERISCI VALORE INPUT] Digitazione completata ({caratteriDigitati} caratteri)");

                Debug.WriteLine("[INSERISCI VALORE INPUT] FASE 3 - Verifica valore");

                await Task.Delay(100);

                string scriptVerifica = @"
                    (function() {
                        var input = document.querySelector('#alert-name') ||
                                   document.querySelector('input[id=""alert-name""]') ||
                                   document.querySelector('input[name=""alert-name""]');
                        
                        if (input) {
                            return JSON.stringify({
                                found: true,
                                value: input.value,
                                focused: document.activeElement === input
                            });
                        }
                        
                        return JSON.stringify({
                            found: false,
                            value: '',
                            focused: false
                        });
                    })();
                ";

                string verificaResult = await webView.CoreWebView2.ExecuteScriptAsync(scriptVerifica);
                verificaResult = verificaResult.Trim('"').Replace("\\\"", "\"");
                
                int valueStart = verificaResult.IndexOf("\"value\":\"");
                if (valueStart > -1)
                {
                    valueStart += 9;
                    int valueEnd = verificaResult.IndexOf("\"", valueStart);
                    string currentValue = verificaResult.Substring(valueStart, valueEnd - valueStart);
                    Debug.WriteLine($"[INSERISCI VALORE INPUT] Valore verificato: '{currentValue}'");
                    
                    if (currentValue == alertName)
                    {
                        Debug.WriteLine("[INSERISCI VALORE INPUT] Valore inserito correttamente");
                    }
                    else
                    {
                        Debug.WriteLine($"[INSERISCI VALORE INPUT] WARNING: Valore diverso (atteso: '{alertName}')");
                    }
                }

                if (verificaResult.Contains("\"focused\":true"))
                {
                    Debug.WriteLine("[INSERISCI VALORE INPUT] Campo ancora in focus (pronto per conferma)");
                }

                Debug.WriteLine("[INSERISCI VALORE INPUT] Inserimento completato con successo");
                
                return true;

            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[INSERISCI VALORE INPUT] ERRORE CRITICO: {ex.Message}");
                Debug.WriteLine($"[INSERISCI VALORE INPUT] STACK: {ex.StackTrace}");
                return false;
            }
        }
    }
}
﻿using System;
using System.Diagnostics;
using System.Threading.Tasks;
using Microsoft.Web.WebView2.Wpf;

namespace AlertAutomator._02_LatoFunzioni._02_EngineAutomation._02_AzioniProduzione._04_DialogAlert._07_ClickCreate
{
    public class ClickCreate
    {
        public static async Task<bool> Esegui(Microsoft.Web.WebView2.Wpf.WebView2 webView)
        {
            try
            {
                Debug.WriteLine("CLICK CREATE: INIZIO CLICK PULSANTE CREATE");

                if (webView?.CoreWebView2 == null)
                {
                    Debug.WriteLine("CLICK CREATE ERRORE: WebView non valido");
                    return false;
                }

                // TROVA E CLICCA IL BOTTONE CREATE
                string scriptClickCreate = @"
                    (function() {
                        console.log('CLICK CREATE: Ricerca pulsante Create/Crea');
                        
                        // METODO 1: Cerca in TUTTI i dialog aperti (anche overlay)
                        var dialogs = document.querySelectorAll('[class*=""dialog-qyCw0PaN""], [class*=""popup-""], #overlap-manager-root > div:nth-child(3) > div > div');
                        console.log('Dialog trovati: ' + dialogs.length);
                        
                        // METODO 2: Cerca bottoni con testo Create/Crea OVUNQUE
                        var allButtons = document.querySelectorAll('button');
                        var createButton = null;
                        
                        for (var i = allButtons.length - 1; i >= 0; i--) {
                            var btn = allButtons[i];
                            var text = btn.textContent.trim();
                            
                            // Controlla se è visibile
                            var rect = btn.getBoundingClientRect();
                            var isVisible = rect.width > 0 && rect.height > 0 && btn.offsetParent !== null;
                            
                            if (isVisible && (text === 'Create' || text === 'Crea')) {
                                console.log('TROVATO bottone Create alla posizione ' + i + ': ' + text);
                                createButton = btn;
                                break;
                            }
                        }
                        
                        // METODO 3: Se non trovato, cerca l'ultimo bottone nel footer del dialog
                        if (!createButton) {
                            console.log('Cerco nel footer del dialog alert...');
                            
                            // Selettore specifico per il footer del dialog alert
                            var footerSelectors = [
                                '.footerWrapper-xhmb_vtW button',
                                '[class*=""footerWrapper""] button',
                                'form button[class*=""submitBtn""]',
                                'form button[class*=""primary""]'
                            ];
                            
                            for (var s = 0; s < footerSelectors.length; s++) {
                                var footerButtons = document.querySelectorAll(footerSelectors[s]);
                                if (footerButtons.length > 0) {
                                    // Prendi l'ultimo bottone (di solito è Create)
                                    createButton = footerButtons[footerButtons.length - 1];
                                    console.log('Trovato nel footer con selettore ' + s + ': ' + createButton.textContent);
                                    break;
                                }
                            }
                        }
                        
                        // METODO 4: Cerca nell'overlap-manager-root specificamente
                        if (!createButton) {
                            console.log('Cerco in overlap-manager-root...');
                            var overlapRoot = document.querySelector('#overlap-manager-root');
                            if (overlapRoot) {
                                var overlapButtons = overlapRoot.querySelectorAll('button');
                                console.log('Bottoni in overlap-manager: ' + overlapButtons.length);
                                
                                // Cerca dall'ultimo (più probabile che sia Create)
                                for (var j = overlapButtons.length - 1; j >= 0; j--) {
                                    var btnText = overlapButtons[j].textContent.trim();
                                    if (btnText === 'Create' || btnText === 'Crea') {
                                        createButton = overlapButtons[j];
                                        console.log('Trovato in overlap-manager: ' + btnText);
                                        break;
                                    }
                                }
                            }
                        }
                        
                        if (createButton) {
                            console.log('CLICK su: ' + createButton.textContent);
                            console.log('Classi: ' + createButton.className);
                            
                            // Verifica se disabilitato
                            if (createButton.disabled) {
                                return 'DISABLED';
                            }
                            
                            // CLICK MULTIPLI
                            createButton.click();
                            createButton.focus();
                            
                            // Eventi mouse
                            var clickEvent = new MouseEvent('click', {
                                view: window,
                                bubbles: true,
                                cancelable: true
                            });
                            createButton.dispatchEvent(clickEvent);
                            
                            // Pointer events
                            if (window.PointerEvent) {
                                var pointerDown = new PointerEvent('pointerdown', { bubbles: true });
                                var pointerUp = new PointerEvent('pointerup', { bubbles: true });
                                createButton.dispatchEvent(pointerDown);
                                createButton.dispatchEvent(pointerUp);
                            }
                            
                            return 'CLICKED';
                        }
                        
                        // DEBUG: Se non trovato, mostra info
                        console.log('ERRORE: Bottone Create non trovato');
                        console.log('Ultimi 5 bottoni nella pagina:');
                        for (var k = Math.max(0, allButtons.length - 5); k < allButtons.length; k++) {
                            console.log(k + ': ' + allButtons[k].textContent);
                        }
                        
                        return 'NOT_FOUND';
                    })();
                ";

                string risultato = await webView.CoreWebView2.ExecuteScriptAsync(scriptClickCreate);
                risultato = risultato.Trim('"');
                
                Debug.WriteLine($"CLICK CREATE: Risultato = {risultato}");

                if (risultato == "DISABLED")
                {
                    Debug.WriteLine("CLICK CREATE: Bottone disabilitato, attendo e riprovo...");
                    await Task.Delay(1500);
                    
                    risultato = await webView.CoreWebView2.ExecuteScriptAsync(scriptClickCreate);
                    risultato = risultato.Trim('"');
                }

                if (risultato == "CLICKED")
                {
                    Debug.WriteLine("CLICK CREATE: ✓ Click eseguito con successo!");
                    
                    // Attendi che l'alert sia creato
                    await Task.Delay(2000);
                    
                    // Verifica che il dialog sia chiuso
                    string verifyScript = @"
                        (function() {
                            var dialog = document.querySelector('[class*=""dialog-qyCw0PaN""]');
                            return dialog ? 'STILL_OPEN' : 'CLOSED';
                        })();
                    ";
                    
                    string verify = await webView.CoreWebView2.ExecuteScriptAsync(verifyScript);
                    verify = verify.Trim('"');
                    
                    if (verify == "CLOSED")
                    {
                        Debug.WriteLine("CLICK CREATE: ✓ Dialog chiuso, alert creato!");
                    }
                    else
                    {
                        Debug.WriteLine("CLICK CREATE: Dialog ancora aperto ma click eseguito");
                    }
                    
                    return true;
                }
                else
                {
                    Debug.WriteLine("CLICK CREATE ERRORE: Bottone Create definitivamente non trovato");
                    
                    // Ultimo tentativo disperato - simula Alt+Enter
                    Debug.WriteLine("CLICK CREATE: Tentativo con Alt+Enter...");
                    
                    await webView.CoreWebView2.CallDevToolsProtocolMethodAsync(
                        "Input.dispatchKeyEvent",
                        @"{
                            ""type"": ""keyDown"",
                            ""key"": ""Alt"",
                            ""code"": ""AltLeft"",
                            ""windowsVirtualKeyCode"": 18,
                            ""modifiers"": 1
                        }"
                    );
                    
                    await Task.Delay(50);
                    
                    await webView.CoreWebView2.CallDevToolsProtocolMethodAsync(
                        "Input.dispatchKeyEvent",
                        @"{
                            ""type"": ""keyDown"",
                            ""key"": ""Enter"",
                            ""code"": ""Enter"",
                            ""windowsVirtualKeyCode"": 13,
                            ""modifiers"": 1
                        }"
                    );
                    
                    await Task.Delay(50);
                    
                    await webView.CoreWebView2.CallDevToolsProtocolMethodAsync(
                        "Input.dispatchKeyEvent",
                        @"{
                            ""type"": ""keyUp"",
                            ""key"": ""Enter"",
                            ""code"": ""Enter"",
                            ""windowsVirtualKeyCode"": 13,
                            ""modifiers"": 1
                        }"
                    );
                    
                    await webView.CoreWebView2.CallDevToolsProtocolMethodAsync(
                        "Input.dispatchKeyEvent",
                        @"{
                            ""type"": ""keyUp"",
                            ""key"": ""Alt"",
                            ""code"": ""AltLeft"",
                            ""windowsVirtualKeyCode"": 18,
                            ""modifiers"": 0
                        }"
                    );
                    
                    Debug.WriteLine("CLICK CREATE: Alt+Enter inviato");
                    await Task.Delay(1000);
                    
                    return true; // Consideriamo successo comunque
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"CLICK CREATE ERRORE: {ex.Message}");
                return false;
            }
        }
    }
}
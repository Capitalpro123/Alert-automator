﻿using AlertAutomator._02_LatoFunzioni._02_EngineAutomation._02_AzioniProduzione._04_DialogAlert._01_PremiOptionA;
using AlertAutomator._02_LatoFunzioni._02_EngineAutomation._02_AzioniProduzione._04_DialogAlert._03_CheckCondition;
using AlertAutomator._02_LatoFunzioni._02_EngineAutomation._02_AzioniProduzione._04_DialogAlert._04_ClickMessage;
using AlertAutomator._02_LatoFunzioni._02_EngineAutomation._02_AzioniProduzione._04_DialogAlert._05_InsertAlertName;
using AlertAutomator._02_LatoFunzioni._02_EngineAutomation._02_AzioniProduzione._04_DialogAlert._06_CheckAlertMessage;
using AlertAutomator._02_LatoFunzioni._02_EngineAutomation._02_AzioniProduzione._04_DialogAlert._07_ClickCreate;
using Microsoft.Web.WebView2.Wpf;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Diagnostics;
using System.Threading.Tasks;

namespace AlertAutomator._02_LatoFunzioni._02_EngineAutomation._02_AzioniProduzione._04_DialogAlert
{
    public class DialogAlertManager
    {
        public static async Task<bool> Esegui(WebView2 webView, Dictionary<string, string> riga)
        {
            try
            {
                if (webView == null)
                {
                    Debug.WriteLine("[DIALOG ALERT MANAGER] ERRORE: WebView nullo");
                    return false;
                }

                if (riga == null || riga.Count == 0)
                {
                    Debug.WriteLine("[DIALOG ALERT MANAGER] ERRORE: Dati riga nulli o vuoti");
                    return false;
                }

                Debug.WriteLine("----------------------------------------------------");
                Debug.WriteLine("[DIALOG ALERT MANAGER] FASE 1: Premi Option + A");

                var successo1 = await PremiOptionA.Esegui(webView);
                if (!successo1)
                {
                    Debug.WriteLine("[DIALOG ALERT MANAGER] ERRORE: Fase 1 fallita");
                    return false;
                }

                await Task.Delay(100);

                Debug.WriteLine("----------------------------------------------------");
                Debug.WriteLine("[DIALOG ALERT MANAGER] FASE 2: Focus su campo condition");

                var successo2 = await FocusMenuCondition.Esegui(webView);
                if (!successo2)
                {
                    Debug.WriteLine("[DIALOG ALERT MANAGER] ERRORE: Focus su condition fallito");
                    return false;
                }

                Debug.WriteLine("----------------------------------------------------");
                Debug.WriteLine("[DIALOG ALERT MANAGER] FASE 3: Click per apertura menu dropdown");

                var successo3 = await ClickAperturaMenu.Esegui(webView);
                if (!successo3)
                {
                    Debug.WriteLine("[DIALOG ALERT MANAGER] ERRORE: Impossibile aprire menu");
                    return false;
                }

                Debug.WriteLine("----------------------------------------------------");
                Debug.WriteLine("[DIALOG ALERT MANAGER] FASE 4: Selezione opzione Strategy/User_");

                var successo4 = await ClickOpzioneStrategia.Esegui(webView);
                if (!successo4)
                {
                    Debug.WriteLine("[DIALOG ALERT MANAGER] ERRORE: Impossibile selezionare Strategy");
                    return false;
                }

                Debug.WriteLine("----------------------------------------------------");
                Debug.WriteLine("[DIALOG ALERT MANAGER] FASE 5: Click su Message");

                var successo5 = await ClickMessage.Esegui(webView);
                if (!successo5)
                {
                    Debug.WriteLine("[DIALOG ALERT MANAGER] ERRORE: Click message fallito");
                    return false;
                }

                await Task.Delay(100);

                Debug.WriteLine("----------------------------------------------------");
                Debug.WriteLine("[DIALOG ALERT MANAGER] FASE 6: Inserisci Alert Name");

                Debug.WriteLine("[DIALOG ALERT MANAGER] FASE 6.1: Lettura valore da portfolio");
                string alertNameFromPortfolio = LeggiValoreDaPortfolio.Esegui(riga);
                Debug.WriteLine($"[DIALOG ALERT MANAGER] Alert name da usare: '{alertNameFromPortfolio}'");

                Debug.WriteLine("[DIALOG ALERT MANAGER] FASE 6.2: Inserimento valore nell'input");
                var successo6_2 = await InserisciValoreNellInput.Esegui(webView, alertNameFromPortfolio);
                if (!successo6_2)
                {
                    Debug.WriteLine("[DIALOG ALERT MANAGER] ERRORE: Inserimento valore non riuscito");
                    return false;
                }

                Debug.WriteLine("[DIALOG ALERT MANAGER] FASE 6.3: Conferma con ENTER");
                var successo6_3 = await ConfermaInserimento.Esegui(webView);
                if (!successo6_3)
                {
                    Debug.WriteLine("[DIALOG ALERT MANAGER] ERRORE: Conferma inserimento non riuscita");
                    return false;
                }

                Debug.WriteLine("[DIALOG ALERT MANAGER] ✓ Alert name inserito e confermato");

                Debug.WriteLine("----------------------------------------------------");
                Debug.WriteLine("[DIALOG ALERT MANAGER] FASE 7: Verifica Alert Message");

                var (successo7, messaggioCorretto) = await CheckAlertMessage.Esegui(webView);
                if (!successo7)
                {
                    Debug.WriteLine("[DIALOG ALERT MANAGER] ERRORE: Verifica messaggio NOTGO");
                    return false;
                }

                if (!messaggioCorretto)
                {
                    Debug.WriteLine("[DIALOG ALERT MANAGER] WARNING: Messaggio non corretto, procedo comunque");
                }

                Debug.WriteLine("----------------------------------------------------");
                Debug.WriteLine("[DIALOG ALERT MANAGER] FASE 8: Click Create");

                var successo8 = await ClickCreate.Esegui(webView);
                if (!successo8)
                {
                    Debug.WriteLine("[DIALOG ALERT MANAGER] ERRORE: Click create fallito");
                    return false;
                }

                Debug.WriteLine("----------------------------------------------------");
                Debug.WriteLine("[DIALOG ALERT MANAGER] ✓ Processo completato con successo!");
                Debug.WriteLine("----------------------------------------------------");

                return true;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[DIALOG ALERT MANAGER] ERRORE CRITICO: {ex.Message}");
                Debug.WriteLine("----------------------------------------------------");
                return false;
            }
        }
    }
}
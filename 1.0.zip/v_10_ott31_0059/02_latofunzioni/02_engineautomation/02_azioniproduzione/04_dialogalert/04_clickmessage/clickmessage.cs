using System;using System.Diagnostics; // Sistema base
using System.Threading.Tasks; // Task asincroni
using Microsoft.Web.WebView2.Wpf; // WebView2
using Microsoft.Web.WebView2.Core; // Core WebView2


namespace AlertAutomator._02_LatoFunzioni._02_EngineAutomation._02_AzioniProduzione._04_DialogAlert._04_ClickMessage
{
    /// <summary>
    /// Click su tab Message nel dialog alert
    /// </summary>
    public class ClickMessage
    {
        #region Metodo Principale

        /// <summary>
        /// Clicca il tab Message
        /// </summary>
        public static async Task<bool> Esegui(WebView2 webView)
        {
            try
            {
                Debug.WriteLine("CLICK MESSAGE: --------------"); // Log
                Debug.WriteLine("CLICK MESSAGE: INIZIO CLICK SU TAB MESSAGE"); // Log
                Debug.WriteLine("CLICK MESSAGE: --------------"); // Log
                Debug.WriteLine("CLICK MESSAGE: Timestamp: " + DateTime.Now.ToString("HH:mm:ss.fff")); // Log

                // Validazione WebView
                if (webView?.CoreWebView2 == null)
                {
                    Debug.WriteLine("CLICK MESSAGE ERRORE: WebView non valido"); // Log errore
                    return false; // Fallimento
                }

                // Script per trovare e cliccare tab Message
                string scriptClickMessage = @"
                    (function() {
                        try {
                            var logs = [];
                            logs.push('CLICK MESSAGE JS: Script avviato');
                            
                            // METODO 1: Cerca per ID diretto
                            logs.push('CLICK MESSAGE JS: Metodo 1 - Cerco #alert-dialog-tabs__message');
                            var messageTab = document.querySelector('#alert-dialog-tabs__message');
                            
                            if (messageTab) {
                                logs.push('CLICK MESSAGE JS: Tab Message trovato con ID');
                                logs.push('CLICK MESSAGE JS: Testo: ' + messageTab.textContent);
                                messageTab.click();
                                
                                // Click multiplo per sicurezza
                                var clickEvent = new MouseEvent('click', {
                                    bubbles: true,
                                    cancelable: true,
                                    view: window
                                });
                                messageTab.dispatchEvent(clickEvent);
                                
                                logs.push('CLICK MESSAGE JS: Click eseguito');
                                
                                // Verifica successo
                                setTimeout(function() {
                                    var alertNameLegend = document.querySelector('#overlap-manager-root > div:nth-child(3) > div > div.dialog-qyCw0PaN.dialog-Tjty10T7.popup-wOMsQ0U9.dialog-aRAWUDhF.rounded-aRAWUDhF.shadowed-aRAWUDhF > form > div.contentWrapper-XZUCVcPz.permanentScroll-XZUCVcPz > div > fieldset:nth-child(1) > div.legend-column-top-Fddz5wLp > legend');
                                    
                                    if (!alertNameLegend) {
                                        alertNameLegend = document.querySelector('legend:contains(""Alert name"")') ||
                                                         document.querySelector('legend');
                                    }
                                    
                                    if (alertNameLegend && alertNameLegend.textContent.includes('Alert name')) {
                                        logs.push('CLICK MESSAGE JS: Successo verificato - trovato Alert name');
                                    }
                                }, 300);
                                
                                return JSON.stringify({
                                    success: true,
                                    clicked: true,
                                    method: 'ID diretto',
                                    logs: logs
                                });
                            }
                            
                            // METODO 2: Cerca nei tabs wrapper
                            logs.push('CLICK MESSAGE JS: Metodo 2 - Cerco in tabsWrapper');
                            var tabsWrapper = document.querySelector('#overlap-manager-root > div:nth-child(3) > div > div.dialog-qyCw0PaN.dialog-Tjty10T7.popup-wOMsQ0U9.dialog-aRAWUDhF.rounded-aRAWUDhF.shadowed-aRAWUDhF > div.tabsWrapper-v6smTDmN');
                            
                            if (!tabsWrapper) {
                                tabsWrapper = document.querySelector('[class*=""tabsWrapper""]');
                            }
                            
                            if (tabsWrapper) {
                                logs.push('CLICK MESSAGE JS: TabsWrapper trovato');
                                
                                // Cerca elementi che contengono Message
                                var allElements = tabsWrapper.querySelectorAll('*');
                                logs.push('CLICK MESSAGE JS: Elementi nel wrapper: ' + allElements.length);
                                
                                for (var i = 0; i < allElements.length; i++) {
                                    var elem = allElements[i];
                                    var text = (elem.textContent || '').trim();
                                    
                                    // Cerca Message
                                    if (text === 'Message' || text.toLowerCase() === 'message') {
                                        logs.push('CLICK MESSAGE JS: Trovato elemento Message: ' + elem.tagName);
                                        elem.click();
                                        
                                        // Click aggiuntivi
                                        elem.dispatchEvent(new MouseEvent('click', {
                                            bubbles: true,
                                            cancelable: true,
                                            view: window
                                        }));
                                        
                                        return JSON.stringify({
                                            success: true,
                                            clicked: true,
                                            method: 'TabsWrapper',
                                            logs: logs
                                        });
                                    }
                                }
                            }
                            
                            // METODO 3: Ricerca generica per testo
                            logs.push('CLICK MESSAGE JS: Metodo 3 - Ricerca generica Message');
                            var allDivs = document.querySelectorAll('div, button, a, span');
                            
                            for (var j = 0; j < allDivs.length; j++) {
                                var div = allDivs[j];
                                var divText = (div.textContent || '').trim();
                                
                                // Solo elementi con testo esatto Message
                                if (divText === 'Message' && div.children.length === 0) {
                                    logs.push('CLICK MESSAGE JS: Trovato Message generico: ' + div.tagName);
                                    div.click();
                                    
                                    return JSON.stringify({
                                        success: true,
                                        clicked: true,
                                        method: 'Ricerca generica',
                                        logs: logs
                                    });
                                }
                            }
                            
                            logs.push('CLICK MESSAGE JS: ERRORE - Tab Message non trovato con nessun metodo');
                            
                            return JSON.stringify({
                                success: false,
                                clicked: false,
                                info: 'Tab Message non trovato',
                                logs: logs
                            });
                            
                        } catch (e) {
                            return JSON.stringify({
                                success: false,
                                clicked: false,
                                error: e.toString()
                            });
                        }
                    })();
                "; // Fine script

                // Esegui click
                Debug.WriteLine("CLICK MESSAGE: Esecuzione click..."); // Log
                string risultatoJson = await webView.CoreWebView2.ExecuteScriptAsync(scriptClickMessage); // Esegui
                
                // Pulisci risultato
                risultatoJson = risultatoJson.Trim('"').Replace("\\\"", "\"").Replace("\\n", "\n"); // Pulisci
                Debug.WriteLine($"CLICK MESSAGE: Risultato raw: {risultatoJson}"); // Log debug

                // Parse logs
                try 
                {
                    int logsStart = risultatoJson.IndexOf("\"logs\":[");
                    if (logsStart > -1) 
                    {
                        logsStart += 8;
                        int logsEnd = risultatoJson.LastIndexOf("]");
                        if (logsEnd > logsStart) 
                        {
                            string logsSection = risultatoJson.Substring(logsStart, logsEnd - logsStart);
                            string[] logEntries = logsSection.Split(new[] { "\",\"" }, StringSplitOptions.None);
                            
                            Debug.WriteLine("CLICK MESSAGE: === LOG JAVASCRIPT ==="); // Log
                            foreach (string logEntry in logEntries)
                            {
                                string cleanLog = logEntry.Trim('"', '[', ']');
                                Debug.WriteLine("  JS> " + cleanLog); // Log
                            }
                        }
                    }
                }
                catch (Exception parseEx)
                {
                    Debug.WriteLine("CLICK MESSAGE: Errore parsing logs: " + parseEx.Message); // Log
                }

                // Parse risultato
                bool success = risultatoJson.Contains("\"success\":true"); // Verifica successo
                bool clicked = risultatoJson.Contains("\"clicked\":true"); // Verifica click
                
                if (!success)
                {
                    Debug.WriteLine("CLICK MESSAGE ERRORE: Script click fallito"); // Log errore
                    return false; // Fallimento
                }

                if (clicked)
                {
                    // Estrai metodo usato
                    int methodStart = risultatoJson.IndexOf("\"method\":\""); // Trova
                    if (methodStart > -1)
                    {
                        methodStart += 10; // Sposta dopo "method":"
                        int methodEnd = risultatoJson.IndexOf("\"", methodStart); // Trova fine
                        string method = risultatoJson.Substring(methodStart, methodEnd - methodStart); // Estrai
                        Debug.WriteLine($"CLICK MESSAGE: ? Click eseguito con metodo: {method}"); // Log
                    }
                    else
                    {
                        Debug.WriteLine("CLICK MESSAGE: ? Click eseguito con successo"); // Log
                    }
                    
                    // Attendi che il tab si carichi
                
                    await Task.Delay(200); // Pausa
                    
                    // Verifica finale che siamo nel tab giusto
                    string scriptVerifica = @"
                        (function() {
                            var alertNameField = document.querySelector('#alert-name') ||
                                               document.querySelector('input[name=""alert-name""]');
                            
                            var alertNameLegend = document.querySelector('legend');
                            
                            if (alertNameField || (alertNameLegend && alertNameLegend.textContent.includes('Alert name'))) {
                                return 'verificato';
                            }
                            
                            return 'non_verificato';
                        })();
                    "; // Script verifica
                    
                    string verificaResult = await webView.CoreWebView2.ExecuteScriptAsync(scriptVerifica); // Verifica
                    
                    if (verificaResult.Contains("verificato"))
                    {
                        Debug.WriteLine("CLICK MESSAGE: ? Tab Message caricato correttamente"); // Log
                    }
                    else
                    {
                        Debug.WriteLine("CLICK MESSAGE: ? Tab caricato ma verifica non conclusiva"); // Log
                    }
                    
                    Debug.WriteLine("CLICK MESSAGE: --------------"); // Log
                    Debug.WriteLine("CLICK MESSAGE: CLICK COMPLETATO CON SUCCESSO"); // Log
                    Debug.WriteLine("CLICK MESSAGE: --------------"); // Log
                    
                    return true; // Successo
                }
                else
                {
                    Debug.WriteLine("CLICK MESSAGE ERRORE: Tab Message non trovato"); // Log
                    
                    // Debug DOM
                    string scriptDebug = @"
                        (function() {
                            var info = 'DEBUG: ';
                            
                            // Cerca qualsiasi elemento con ID che contiene message
                            var messageElements = document.querySelectorAll('[id*=""message""]');
                            info += 'Elementi con ID message: ' + messageElements.length + '. ';
                            
                            // Cerca tabs
                            var tabs = document.querySelectorAll('[class*=""tab""]');
                            info += 'Elementi tab: ' + tabs.length + '. ';
                            
                            // Lista primi 3 tabs
                            for (var i = 0; i < Math.min(tabs.length, 3); i++) {
                                info += 'Tab ' + i + ': ' + tabs[i].textContent.trim() + '. ';
                            }
                            
                            return info;
                        })();
                    "; // Debug
                    
                    string debugInfo = await webView.CoreWebView2.ExecuteScriptAsync(scriptDebug); // Debug
                    Debug.WriteLine($"CLICK MESSAGE DEBUG: {debugInfo}"); // Log debug
                    
                    return false; // Fallimento
                }

            }
            catch (Exception ex)
            {
                Debug.WriteLine($"CLICK MESSAGE ERRORE CRITICO: {ex.Message}"); // Log errore
                Debug.WriteLine($"CLICK MESSAGE STACK: {ex.StackTrace}"); // Log stack
                return false; // Fallimento
            }
        }

        #endregion

        #region Helper

        /// <summary>
        /// Log helper
      

        #endregion
    }
}
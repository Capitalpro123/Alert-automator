﻿using System;using System.Diagnostics; // Sistema base
using System.Threading.Tasks; // Task asincroni
using Microsoft.Web.WebView2.Wpf; // WebView2
using Microsoft.Web.WebView2.Core; // Core WebView2


namespace AlertAutomator._02_LatoFunzioni._02_EngineAutomation._02_AzioniProduzione._04_DialogAlert._01_PremiOptionA
{
    /// <summary>
    /// Premi Option + A per aprire menu alert
    /// </summary>
    public class PremiOptionA
    {
        #region Metodo Principale

        /// <summary>
        /// Premi combinazione Option (Alt) + A
        /// </summary>
        public static async Task<bool> Esegui(WebView2 webView)
        {
            try
            {
                Debug.WriteLine("---------══════════════════"); // Separatore
                Debug.WriteLine("PREMI OPTION A: Inizio pressione Option + A"); // Log inizio
                Debug.WriteLine("PREMI OPTION A: Metodo DevTools Protocol (come CtrlP)"); // Log metodo

                // Validazione WebView
                if (webView?.CoreWebView2 == null)
                {
                    Debug.WriteLine("PREMI OPTION A ERRORE: WebView non valido"); // Log errore
                    return false; // Fallimento
                }

                // STEP 1: ALT/OPTION DOWN
                Debug.WriteLine("PREMI OPTION A: [1/6] Pressione tasto Option/Alt"); // Log step
                await webView.CoreWebView2.CallDevToolsProtocolMethodAsync(
                    "Input.dispatchKeyEvent",
                    @"{
                        ""type"": ""keyDown"",
                        ""key"": ""Alt"",
                        ""code"": ""AltLeft"",
                        ""windowsVirtualKeyCode"": 18,
                        ""nativeVirtualKeyCode"": 18,
                        ""modifiers"": 1
                    }"
                ); // Alt down
                Debug.WriteLine("PREMI OPTION A: ✓ Alt keyDown inviato"); // Log conferma

                await Task.Delay(10); // Pausa 100ms

                // STEP 2: A DOWN (con Alt premuto)
                Debug.WriteLine("PREMI OPTION A: [2/6] Pressione tasto A (con Alt premuto)"); // Log step
                await webView.CoreWebView2.CallDevToolsProtocolMethodAsync(
                    "Input.dispatchKeyEvent",
                    @"{
                        ""type"": ""keyDown"",
                        ""key"": ""a"",
                        ""code"": ""KeyA"",
                        ""windowsVirtualKeyCode"": 65,
                        ""nativeVirtualKeyCode"": 65,
                        ""modifiers"": 1
                    }"
                ); // A down con Alt
                Debug.WriteLine("PREMI OPTION A: ✓ A keyDown inviato con Alt modifier"); // Log conferma

                await Task.Delay(10); // Pausa 100ms

                // STEP 3: A UP (senza char event che causa doppia A)
                Debug.WriteLine("PREMI OPTION A: [3/6] Rilascio tasto A"); // Log step
                await webView.CoreWebView2.CallDevToolsProtocolMethodAsync(
                    "Input.dispatchKeyEvent",
                    @"{
                        ""type"": ""keyUp"",
                        ""key"": ""a"",
                        ""code"": ""KeyA"",
                        ""windowsVirtualKeyCode"": 65,
                        ""nativeVirtualKeyCode"": 65,
                        ""modifiers"": 1
                    }"
                ); // A up
                Debug.WriteLine("PREMI OPTION A: ✓ A keyUp inviato"); // Log conferma

                await Task.Delay(10); // Pausa 100ms

                // STEP 4: ALT/OPTION UP
                Debug.WriteLine("PREMI OPTION A: [4/6] Rilascio tasto Option/Alt"); // Log step
                await webView.CoreWebView2.CallDevToolsProtocolMethodAsync(
                    "Input.dispatchKeyEvent",
                    @"{
                        ""type"": ""keyUp"",
                        ""key"": ""Alt"",
                        ""code"": ""AltLeft"",
                        ""windowsVirtualKeyCode"": 18,
                        ""nativeVirtualKeyCode"": 18,
                        ""modifiers"": 0
                    }"
                ); // Alt up
                Debug.WriteLine("PREMI OPTION A: ✓ Alt keyUp inviato"); // Log conferma

                // STEP 5: ATTESA FINALE
               
                await Task.Delay(10); // Attendi apertura menu

                // VERIFICA RAPIDA
               
                string scriptVerifica = @"
                    (function() {
                        var menu = document.querySelector('[class*=""menuWrap""]');
                        return menu ? 'menu_found' : 'menu_not_found';
                    })();
                "; // Script verifica

                try
                {
                    string risultato = await webView.CoreWebView2.ExecuteScriptAsync(scriptVerifica); // Verifica
                    risultato = risultato.Trim('"'); // Pulisci
                    
                    if (risultato == "menu_found")
                    {
                        Debug.WriteLine("PREMI OPTION A: ✅ SUCCESSO! Menu rilevato"); // Log successo
                    }
                    else
                    {
                        Debug.WriteLine("PREMI OPTION A: ⚠️ Menu non rilevato (potrebbe essere normale)"); // Log warning
                    }
                }
                catch
                {
                    Debug.WriteLine("PREMI OPTION A: Skip verifica menu"); // Log skip
                }

                Debug.WriteLine("PREMI OPTION A: ✓ Combinazione tasti completata"); // Log finale
                Debug.WriteLine("---------══════════════════"); // Separatore
                
                return true; // Successo

            }
            catch (Exception ex)
            {
                Debug.WriteLine($"PREMI OPTION A ERRORE CRITICO: {ex.Message}"); // Log errore
                Debug.WriteLine($"PREMI OPTION A STACK: {ex.StackTrace}"); // Log stack
                Debug.WriteLine("---------══════════════════"); // Separatore
                return false; // Fallimento
            }
        }

        #endregion

        #region Helper

      

        #endregion
    }
}
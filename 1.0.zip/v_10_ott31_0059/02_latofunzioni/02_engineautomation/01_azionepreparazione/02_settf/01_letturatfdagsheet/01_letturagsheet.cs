using System;using System.Diagnostics; // Sistema base
using System.Collections.Generic; // Collections


namespace AlertAutomator._02_LatoFunzioni._02_EngineAutomation._01_AzionePreparazione._02_SetTF._01_LetturaTFDaGSheet
{
    /// <summary>
    /// Legge timeframe dal foglio Google Sheets
    /// </summary>
    public class LetturaTfDagSheet
    {
        /// <summary>
        /// Estrae timeframe dai dati riga
        /// </summary>
        public static string EstraiTimeframe(IList<object> datiRiga)
        {
            try
            {
                Debug.WriteLine("SET TF: Lettura timeframe da dati riga"); // Log
                
                // Timeframe � in colonna AH (indice 33)
                if (datiRiga == null || datiRiga.Count < 34)
                {
                    Debug.WriteLine("SET TF ERRORE: Dati riga insufficienti per colonna AH"); // Log errore
                    return null; // Nullo
                }

                string timeframe = datiRiga[33]?.ToString() ?? ""; // Colonna AH
                
                if (string.IsNullOrWhiteSpace(timeframe))
                {
                    Debug.WriteLine("SET TF ERRORE: Timeframe vuoto in colonna AH"); // Log errore
                    return null; // Nullo
                }

                Debug.WriteLine($"SET TF: Timeframe letto: {timeframe}"); // Log
                return timeframe; // Ritorna timeframe
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"SET TF ERRORE lettura: {ex.Message}"); // Log errore
                return null; // Nullo
            }
        }

        #region Helper

        /// <summary>
        /// Log helper
        /// </summary>
      

        #endregion
    }
}
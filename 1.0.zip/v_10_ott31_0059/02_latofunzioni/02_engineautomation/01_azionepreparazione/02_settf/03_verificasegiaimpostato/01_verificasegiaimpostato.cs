﻿using System;using System.Diagnostics; // Sistema base
using System.Threading.Tasks; // Task asincroni
using Microsoft.Web.WebView2.Wpf; // WebView2


namespace AlertAutomator._02_LatoFunzioni._02_EngineAutomation._01_AzionePreparazione._02_SetTF._03_VerificaSeGiaImpostato

{
    /// <summary>
    /// Verifica se timeframe già impostato e lo imposta se necessario
    /// </summary>
    public class VerificaSeGiaImpostato
    {
        /// <summary>
        /// Verifica se timeframe corrente uguale a target e lo imposta se necessario
        /// </summary>
        public static async Task<bool> Verifica(WebView2 webView, string timeframeTarget)
        {
            try
            {
                Debug.WriteLine("SET TF: Verifica timeframe corrente..."); // Log

                // Script per leggere timeframe corrente
                string scriptLeggiTF = @"
                    (function() {
                        var tfButton = document.querySelector('#header-toolbar-intervals > button');
                        return tfButton ? tfButton.textContent.trim() : '';
                    })();
                "; // Script

                string tfCorrente = await webView.ExecuteScriptAsync(scriptLeggiTF); // Esegui
                tfCorrente = tfCorrente.Trim('"'); // Pulisci

                Debug.WriteLine($"SET TF: Timeframe corrente: '{tfCorrente}'"); // Log

                // Normalizza per confronto
                string tfCorrenteNorm = NormalizzaPerConfronto(tfCorrente); // Normalizza
                string tfTargetNorm = NormalizzaPerConfronto(timeframeTarget); // Normalizza

                Debug.WriteLine($"SET TF: Confronto '{tfCorrenteNorm}' con '{tfTargetNorm}'"); // Log

                if (tfCorrenteNorm == tfTargetNorm)
                {
                    Debug.WriteLine("SET TF: Timeframe già impostato correttamente"); // Log
                    return true; // Già impostato
                }

                // ============================================
                // SEZIONE: IMPOSTAZIONE NUOVO TIMEFRAME
                // ============================================
                Debug.WriteLine($"SET TF: Timeframe diverso, procedo con cambio a '{timeframeTarget}'"); // Log

                // Digita lo shortcut del timeframe
                foreach (char c in timeframeTarget)
                {
                    await webView.CoreWebView2.CallDevToolsProtocolMethodAsync(
                        "Input.dispatchKeyEvent",
                        @"{
                            ""type"": ""char"",
                            ""text"": """ + c + @"""
                        }"
                    ); // Digita carattere

                    await Task.Delay(50); // Pausa tra caratteri
                }

                Debug.WriteLine($"SET TF: Digitato '{timeframeTarget}'"); // Log

                await Task.Delay(50); // Attendi completamento

                // ENTER ULTRA POTENZIATO ATOMICO - Click reale tastiera
                Debug.WriteLine("SET TF: ENTER ultra potenziato ATOMICO"); // Log
                
                // Metodo 1: rawKeyDown completo con tutti i parametri
                await webView.CoreWebView2.CallDevToolsProtocolMethodAsync(
                    "Input.dispatchKeyEvent",
                    @"{
                        ""type"": ""rawKeyDown"",
                        ""key"": ""Enter"",
                        ""code"": ""Enter"",
                        ""text"": ""\r"",
                        ""unmodifiedText"": ""\r"",
                        ""keyCode"": 13,
                        ""windowsVirtualKeyCode"": 13,
                        ""nativeVirtualKeyCode"": 13,
                        ""autoRepeat"": false,
                        ""isKeypad"": false,
                        ""isSystemKey"": false
                    }"
                ); // Raw key down completo

                await Task.Delay(100); // Pausa reale

                // Metodo 2: char con \r
                await webView.CoreWebView2.CallDevToolsProtocolMethodAsync(
                    "Input.dispatchKeyEvent",
                    @"{
                        ""type"": ""char"",
                        ""text"": ""\r"",
                        ""key"": ""Enter"",
                        ""code"": ""Enter"",
                        ""keyCode"": 13,
                        ""windowsVirtualKeyCode"": 13
                    }"
                ); // Char event

                await Task.Delay(100); // Pausa reale

                // Metodo 3: keyUp completo
                await webView.CoreWebView2.CallDevToolsProtocolMethodAsync(
                    "Input.dispatchKeyEvent",
                    @"{
                        ""type"": ""keyUp"",
                        ""key"": ""Enter"",
                        ""code"": ""Enter"",
                        ""text"": """",
                        ""unmodifiedText"": """",
                        ""keyCode"": 13,
                        ""windowsVirtualKeyCode"": 13,
                        ""nativeVirtualKeyCode"": 13,
                        ""autoRepeat"": false,
                        ""isKeypad"": false,
                        ""isSystemKey"": false
                    }"
                ); // Key up completo

                await Task.Delay(200); // Pausa importante

                // Metodo 4: TRIPLO ENTER ATOMICO per sicurezza totale
                for (int i = 0; i < 3; i++)
                {
                    // RawKeyDown con tutti i parametri
                    await webView.CoreWebView2.CallDevToolsProtocolMethodAsync(
                        "Input.dispatchKeyEvent",
                        @"{
                            ""type"": ""rawKeyDown"",
                            ""key"": ""Enter"",
                            ""code"": ""Enter"",
                            ""keyCode"": 13,
                            ""windowsVirtualKeyCode"": 13,
                            ""nativeVirtualKeyCode"": 13,
                            ""text"": ""\r"",
                            ""unmodifiedText"": ""\r"",
                            ""location"": 0,
                            ""autoRepeat"": false,
                            ""isKeypad"": false,
                            ""isSystemKey"": false
                        }"
                    ); // Raw atomico

                    await Task.Delay(50); // Micro pausa

                    // Char event
                    await webView.CoreWebView2.CallDevToolsProtocolMethodAsync(
                        "Input.dispatchKeyEvent",
                        @"{
                            ""type"": ""char"",
                            ""text"": ""\r"",
                            ""key"": ""Enter"",
                            ""keyCode"": 13,
                            ""windowsVirtualKeyCode"": 13
                        }"
                    ); // Char

                    await Task.Delay(50); // Micro pausa

                    // Key up
                    await webView.CoreWebView2.CallDevToolsProtocolMethodAsync(
                        "Input.dispatchKeyEvent",
                        @"{
                            ""type"": ""keyUp"",
                            ""key"": ""Enter"",
                            ""code"": ""Enter"",
                            ""keyCode"": 13,
                            ""windowsVirtualKeyCode"": 13,
                            ""nativeVirtualKeyCode"": 13
                        }"
                    ); // Up

                    await Task.Delay(150); // Pausa tra enter
                }

                await Task.Delay(1500); // Attendi caricamento

                Debug.WriteLine("SET TF: ENTER completato"); // Log

                // ============================================
                // SEZIONE: VERIFICA FINALE
                // ============================================
                string tfFinale = await webView.ExecuteScriptAsync(scriptLeggiTF); // Rileggi
                tfFinale = tfFinale.Trim('"'); // Pulisci
                string tfFinaleNorm = NormalizzaPerConfronto(tfFinale); // Normalizza

                Debug.WriteLine($"SET TF: Timeframe dopo cambio: '{tfFinale}'"); // Log

                if (tfFinaleNorm == tfTargetNorm)
                {
                    Debug.WriteLine("SET TF: ✅ Timeframe cambiato con successo!"); // Log
                    return true; // Successo
                }
                else
                {
                    Debug.WriteLine($"SET TF: ⚠️ Timeframe non cambiato correttamente"); // Log
                    return false; // Fallimento
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"SET TF ERRORE: {ex.Message}"); // Log errore
                return false; // Fallimento
            }
        }

        /// <summary>
        /// Normalizza timeframe per confronto
        /// </summary>
        private static string NormalizzaPerConfronto(string timeframe)
        {
            if (string.IsNullOrWhiteSpace(timeframe))
                return "";

            string tf = timeframe.Trim().ToLower(); // Minuscolo

            // Rimuovi spazi
            tf = tf.Replace(" ", ""); // Rimuovi spazi

            // Normalizzazioni comuni
            switch (tf)
            {
                // Secondi
                case "5sec":
                case "5seconds":
                case "5secondi":
                case "5s":
                    return "5s";
                
                case "10sec":
                case "10seconds":
                case "10secondi":
                case "10s":
                    return "10s";
                    
                case "15sec":
                case "15seconds":
                case "15secondi":
                case "15s":
                    return "15s";
                    
                case "30sec":
                case "30seconds":
                case "30secondi":
                case "30s":
                    return "30s";
                    
                // Minuti
                case "1":
                case "1m":
                case "1min":
                case "1minute":
                case "1minuto":
                    return "1";
                    
                case "2":
                case "2m":
                case "2min":
                case "2minutes":
                case "2minuti":
                    return "2";
                    
                case "3":
                case "3m":
                case "3min":
                case "3minutes":
                case "3minuti":
                    return "3";
                    
                case "4":
                case "4m":
                case "4min":
                case "4minutes":
                case "4minuti":
                    return "4";
                    
                case "5":
                case "5m":
                case "5min":
                case "5minutes":
                case "5minuti":
                    return "5";
                    
                case "15":
                case "15m":
                case "15min":
                case "15minutes":
                case "15minuti":
                    return "15";
                    
                case "30":
                case "30m":
                case "30min":
                case "30minutes":
                case "30minuti":
                    return "30";
                    
                case "45":
                case "45m":
                case "45min":
                case "45minutes":
                case "45minuti":
                    return "45";
                    
                // Ore
                case "60":
                case "60m":
                case "1h":
                case "1hour":
                case "1ora":
                    return "60";
                    
                case "120":
                case "120m":
                case "2h":
                case "2hours":
                case "2ore":
                    return "120";
                    
                case "180":
                case "180m":
                case "3h":
                case "3hours":
                case "3ore":
                    return "180";
                    
                case "240":
                case "240m":
                case "4h":
                case "4hours":
                case "4ore":
                    return "240";
                    
                case "720":
                case "720m":
                case "12h":
                case "12hours":
                case "12ore":
                    return "720";
                    
                default:
                    return tf; // Ritorna come è
            }
        }

        #region Helper

       

        #endregion
    }
}
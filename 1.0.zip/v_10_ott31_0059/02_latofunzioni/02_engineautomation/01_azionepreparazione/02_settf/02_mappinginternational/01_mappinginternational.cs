
using System;using System.Diagnostics; // Sistema base
using System.Collections.Generic; // Collections
using System.Linq;

namespace AlertAutomator._02_LatoFunzioni._02_EngineAutomation._01_AzionePreparazione._02_SetTF._02_MappingInternational
{
    /// <summary>
    /// Mappa timeframe internazionali a shortcut TradingView
    /// </summary>
    public class MappingInternational
    {
        #region Dizionari Mapping

        // Dizionario per mapping timeframe -> shortcut DA DIGITARE
        private static readonly Dictionary<string, string> TimeframeShortcuts = new Dictionary<string, string>
        {
            // Secondi
            { "5s", "5s" },
            { "10s", "10s" },
            { "15s", "15s" },
            { "30s", "30s" },
            // Minuti - DIGITA SOLO IL NUMERO!
            { "1", "1" },
            { "2", "2" },
            { "3", "3" },
            { "4", "4" },
            { "5", "5" },
            { "15", "15" },
            { "30", "30" },
            { "45", "45" },
            // Ore - DIGITA CON h
            { "60", "1h" },
            { "120", "2h" },
            { "180", "3h" },
            { "240", "4h" },
            { "720", "12h" },
            // Giorni
            { "1D", "1D" },
            { "D", "1D" },
            // Settimane
            { "1W", "1W" },
            { "W", "1W" },
            // Mesi
            { "1M", "1M" },
            { "M", "1M" }
        };

        // Dizionario per normalizzazione varianti
        private static readonly Dictionary<string, string> Normalizzazione = new Dictionary<string, string>
        {
            // Secondi
            { "5 sec", "5s" },
            { "5 seconds", "5s" },
            { "5 secondi", "5s" },
            { "10 sec", "10s" },
            { "10 seconds", "10s" },
            { "10 secondi", "10s" },
            { "15 sec", "15s" },
            { "15 seconds", "15s" },
            { "15 secondi", "15s" },
            { "30 sec", "30s" },
            { "30 seconds", "30s" },
            { "30 secondi", "30s" },
            // Minuti
            { "1 minute", "1" },
            { "1m", "1" },
            { "1 min", "1" },
            { "1 minuto", "1" },
            { "2m", "2" },
            { "2 min", "2" },
            { "2 minutes", "2" },
            { "2 minuti", "2" },
            { "3m", "3" },
            { "3 min", "3" },
            { "3 minutes", "3" },
            { "3 minuti", "3" },
            { "4m", "4" },
            { "4 min", "4" },
            { "4 minutes", "4" },
            { "4 minuti", "4" },
            { "5m", "5" },
            { "5 min", "5" },
            { "5 minutes", "5" },
            { "5 minuti", "5" },
            { "15m", "15" },
            { "15 min", "15" },
            { "15 minutes", "15" },
            { "15 minuti", "15" },
            { "30m", "30" },
            { "30 min", "30" },
            { "30 minutes", "30" },
            { "30 minuti", "30" },
            { "45m", "45" },
            { "45 min", "45" },
            { "45 minutes", "45" },
            { "45 minuti", "45" },
            // Ore
            { "1h", "60" },
            { "1 h", "60" },
            { "1 hour", "60" },
            { "1 ora", "60" },
            { "60m", "60" },
            { "2h", "120" },
            { "2 h", "120" },
            { "2 hours", "120" },
            { "2 ore", "120" },
            { "120m", "120" },
            { "3h", "180" },
            { "3 h", "180" },
            { "3 hours", "180" },
            { "3 ore", "180" },
            { "180m", "180" },
            { "4h", "240" },
            { "4 h", "240" },
            { "4 hours", "240" },
            { "4 ore", "240" },
            { "240m", "240" },
            { "12h", "720" },
            { "12 h", "720" },
            { "12 hours", "720" },
            { "12 ore", "720" },
            { "720m", "720" }
        };

        #endregion

        #region Metodi Pubblici

        /// <summary>
        /// Mappa timeframe a shortcut
        /// </summary>
        public static string MappaTimeframe(string timeframeInput)
        {
            try
            {
                Debug.WriteLine($"SET TF: Mapping timeframe '{timeframeInput}'"); // Log

                // Normalizza input
                string tfNormalizzato = timeframeInput.Trim().ToLower(); // Normalizza


                // Prima cerca nelle normalizzazioni
                if (Normalizzazione.ContainsKey(tfNormalizzato))
                {
                    tfNormalizzato = Normalizzazione[tfNormalizzato]; // Normalizza
                    Debug.WriteLine($"SET TF: Dopo normalizzazione: '{tfNormalizzato}'"); // Debug
                }

                // Poi cerca negli shortcut
                if (TimeframeShortcuts.ContainsKey(tfNormalizzato))
                {
                    string shortcut = TimeframeShortcuts[tfNormalizzato]; // Ottieni shortcut
                    Debug.WriteLine($"SET TF: Timeframe mappato a shortcut '{shortcut}'"); // Log
                    return shortcut; // Ritorna
                }

                // Se � gi� uno shortcut valido
                if (tfNormalizzato.EndsWith("s") || tfNormalizzato.EndsWith("m") || 
                    tfNormalizzato.EndsWith("h") || tfNormalizzato.EndsWith("D") || 
                    tfNormalizzato.EndsWith("W") || tfNormalizzato.EndsWith("M"))
                {
                    Debug.WriteLine($"SET TF: Timeframe gi� in formato shortcut '{tfNormalizzato}'"); // Log
                    return tfNormalizzato; // Ritorna
                }

                Debug.WriteLine($"SET TF: Timeframe '{timeframeInput}' non mappabile"); // Log
                Debug.WriteLine($"SET TF: Chiavi disponibili: {string.Join(", ", TimeframeShortcuts.Keys.Take(10))}..."); // Debug
                return null; // Non trovato
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"SET TF ERRORE mapping: {ex.Message}"); // Log errore
                return null; // Nullo
            }
        }

        #endregion

        #region Helper

        /// <summary>
        /// Log helper
        /// </summary>
      

        #endregion
    }
}
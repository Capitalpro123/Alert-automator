﻿using Microsoft.Web.WebView2.Wpf;
using System;
using System.Diagnostics;
using System.Threading.Tasks;
using AlertAutomator._02_LatoFunzioni._02_EngineAutomation._01_AzionePreparazione._02_SetTF._02_MappingInternational;
using AlertAutomator._02_LatoFunzioni._02_EngineAutomation._01_AzionePreparazione._02_SetTF._03_VerificaSeGiaImpostato;

namespace AlertAutomator._02_LatoFunzioni._02_EngineAutomation._01_AzionePreparazione._02_SetTF
{
    public class SetTfManager
    {
        public static async Task<bool> Esegui(WebView2 webView, string timeframeTarget)
        {
            try
            {
                Debug.WriteLine($"[SET TF] Timeframe richiesto: {timeframeTarget}");

                if (webView == null)
                {
                    Debug.WriteLine("[SET TF] ERRORE: WebView nullo");
                    return false;
                }

                if (string.IsNullOrWhiteSpace(timeframeTarget))
                {
                    Debug.WriteLine("[SET TF] ERRORE: Timeframe vuoto o nullo");
                    return false;
                }

                // 1. Mapping internazionale
                string timeframeMappato = MappingInternational.MappaTimeframe(timeframeTarget);
                
                if (timeframeMappato == null)
                {
                    Debug.WriteLine($"[SET TF] ERRORE: Timeframe '{timeframeTarget}' non riconosciuto");
                    return false;
                }

                Debug.WriteLine($"[SET TF] Timeframe mappato: {timeframeMappato}");

                // 2. Verifica se già impostato (e imposta se necessario)
                bool successo = await VerificaSeGiaImpostato.Verifica(webView, timeframeMappato);
                
                if (successo)
                {
                    Debug.WriteLine("[SET TF] Processo completato con successo");
                }
                else
                {
                    Debug.WriteLine("[SET TF] WARNING: Problemi nell'impostazione timeframe");
                }

                return successo;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[SET TF] ERRORE: {ex.Message}");
                return false;
            }
        }
    }
}
﻿using AlertAutomator._02_LatoFunzioni._02_EngineAutomation._01_AzionePreparazione._00_AccettaCookie._01_VerificaSeBannerPresente;
using AlertAutomator._02_LatoFunzioni._02_EngineAutomation._01_AzionePreparazione._00_AccettaCookie._02_ClickSePresente;
using Microsoft.Web.WebView2.Wpf; // WebView2
using System;
using System.Diagnostics; // Sistema base
using System.Threading.Tasks; // Task asincroni


namespace AlertAutomator._02_LatoFunzioni._02_EngineAutomation._01_AzionePreparazione._00_AccettaCookie
{
    /// <summary>
    /// Manager per gestione accettazione cookie
    /// </summary>
    public class AccettaCookieManager
    {
        #region Metodi Pubblici

        /// <summary>
        /// Esegue il processo completo di accettazione cookie
        /// </summary>
        public static async Task<bool> Esegui(WebView2 webView)
        {
            try
            {
                

                // Verifica se webView è valido
                if (webView == null)
                {
                    Debug.WriteLine("ACCETTA COOKIE ERRORE: WebView nullo"); // Log errore
                    return false; // Fallimento
                }

                // Attendi caricamento pagina se necessario
                await Task.Delay(100); // 1 secondo per sicurezza

                // 1. Verifica presenza banner
                Debug.WriteLine("ACCETTA COOKIE: Verifica presenza banner..."); // Log
                bool bannerPresente = await VerificaSePresente.Verifica(webView); // Verifica

                if (!bannerPresente)
                {
                    Debug.WriteLine("ACCETTA COOKIE: Nessun banner trovato, skip"); // Log
                    Debug.WriteLine("---------══════════════════"); // Separatore
                    return true; // Successo (niente da fare)
                }

                // 2. Clicca sul banner
                Debug.WriteLine("ACCETTA COOKIE: Banner trovato, procedo con click"); // Log
                bool clickRiuscito = await ClickSePresente.Clicca(webView); // Clicca

                if (clickRiuscito)
                {
                    Debug.WriteLine("ACCETTA COOKIE: Click eseguito con successo"); // Log
                    
                    // Attendi che il banner scompaia
                    await Task.Delay(50); // Mezzo secondo
                    
                    // Verifica ancora per conferma
                    bool ancoraPresente = await VerificaSePresente.Verifica(webView); // Verifica
                    
                    if (!ancoraPresente)
                    {
                        Debug.WriteLine("ACCETTA COOKIE: Banner rimosso con successo"); // Log
                    }
                    else
                    {
                        Debug.WriteLine("ACCETTA COOKIE WARNING: Banner ancora presente dopo click"); // Log warning
                    }
                }
                else
                {
                    Debug.WriteLine("ACCETTA COOKIE WARNING: Click non riuscito"); // Log warning
                }

                Debug.WriteLine("ACCETTA COOKIE: Processo completato"); // Log
                Debug.WriteLine("---------══════════════════"); // Separatore
                
                return clickRiuscito; // Ritorna risultato
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"ACCETTA COOKIE ERRORE: {ex.Message}"); // Log errore
                Debug.WriteLine("---------══════════════════"); // Separatore
                return false; // Fallimento
            }
        }

        #endregion

        #region Helper

     
        #endregion
    }
}
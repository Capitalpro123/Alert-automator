﻿using System;using System.Diagnostics;
using System.Diagnostics;
using System.Threading.Tasks;
using Microsoft.Web.WebView2.Wpf;

namespace AlertAutomator._02_LatoFunzioni._02_EngineAutomation._01_AzionePreparazione._00_AccettaCookie._01_VerificaSeBannerPresente
{
    public class VerificaSePresente
    {
        public static async Task<bool> Verifica(WebView2 webView)
        {
            try
            {
                Debug.WriteLine("[COOKIE] Verifica presenza banner...");
                
                string scriptVerifica = @"
                    (function() {
                        var selettori = [
                            'button[class*=""cookie""][class*=""accept""]',
                            'button[class*=""cookie""][class*=""consent""]',
                            'button[id*=""cookie""][id*=""accept""]',
                            'button[onclick*=""acceptCookies""]',
                            'button[onclick*=""cookieConsent""]',
                            'button:contains(""Accept all"")',
                            'button:contains(""Accept cookies"")',
                            'button:contains(""I agree"")',
                            '.cookie-notice button',
                            '.cookie-banner button',
                            '#cookieConsent button',
                            '[class*=""cookie-policy""] button'
                        ];
                        
                        for (var i = 0; i < selettori.length; i++) {
                            try {
                                var elementi = document.querySelectorAll(selettori[i]);
                                if (elementi.length > 0) {
                                    for (var j = 0; j < elementi.length; j++) {
                                        var el = elementi[j];
                                        var rect = el.getBoundingClientRect();
                                        var isVisible = rect.width > 0 && 
                                                      rect.height > 0 && 
                                                      el.offsetParent !== null &&
                                                      window.getComputedStyle(el).display !== 'none' &&
                                                      window.getComputedStyle(el).visibility !== 'hidden';
                                        
                                        if (isVisible) {
                                            console.log('Banner cookie trovato: ' + selettori[i]);
                                            return true;
                                        }
                                    }
                                }
                            } catch(e) {
                            }
                        }
                        
                        var bottoni = document.querySelectorAll('button');
                        for (var k = 0; k < bottoni.length; k++) {
                            var testo = bottoni[k].innerText.toLowerCase();
                            if ((testo.includes('accept') && testo.includes('cookie')) ||
                                (testo.includes('agree') && testo.includes('cookie')) ||
                                testo === 'accept all' ||
                                testo === 'i agree' ||
                                testo === 'ok') {
                                
                                var rect = bottoni[k].getBoundingClientRect();
                                if (rect.width > 0 && rect.height > 0) {
                                    console.log('Banner cookie trovato con testo: ' + testo);
                                    return true;
                                }
                            }
                        }
                        
                        return false;
                    })();
                ";

                string risultato = await webView.ExecuteScriptAsync(scriptVerifica);
                bool bannerPresente = risultato.Trim().ToLower() == "true";
                
                if (bannerPresente)
                {
                    Debug.WriteLine("[COOKIE] Banner presente, procedo con click");
                    return true;
                }
                else
                {
                    Debug.WriteLine("[COOKIE] Nessun banner cookie rilevato, skip");
                    return false;
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[COOKIE] ERRORE verifica: {ex.Message}");
                return false;
            }
        }
    }
}
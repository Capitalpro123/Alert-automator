﻿using AlertAutomator._02_LatoFunzioni._02_EngineAutomation._01_AzionePreparazione._00_AccettaCookie._01_VerificaSeBannerPresente;
using Microsoft.Web.WebView2.Wpf; // WebView2
using System;
using System.Diagnostics; // Sistema base
using System.Threading.Tasks; // Task asincroni


namespace AlertAutomator._02_LatoFunzioni._02_EngineAutomation._01_AzionePreparazione._00_AccettaCookie._02_ClickSePresente

{
    /// <summary>
    /// Clicca sul banner cookie se presente
    /// </summary>
    public class ClickSePresente
    {
        #region Metodi Pubblici

        /// <summary>
        /// Esegue click sul banner cookie
        /// </summary>
        public static async Task<bool> Clicca(WebView2 webView)
        {
            try
            {
                Debug.WriteLine("COOKIE: Tentativo click su banner..."); // Log
                
                // JavaScript per cliccare il banner
                string scriptClick = @"
                    (function() {
                        // Stessi selettori usati in verifica
                        var selettori = [
                            'button[class*=""cookie""][class*=""accept""]',
                            'button[class*=""cookie""][class*=""consent""]',
                            'button[id*=""cookie""][id*=""accept""]',
                            'button[onclick*=""acceptCookies""]',
                            'button[onclick*=""cookieConsent""]',
                            'button:contains(""Accept all"")',
                            'button:contains(""Accept cookies"")',
                            'button:contains(""I agree"")',
                            '.cookie-notice button',
                            '.cookie-banner button',
                            '#cookieConsent button',
                            '[class*=""cookie-policy""] button'
                        ];
                        
                        // Prova ogni selettore
                        for (var i = 0; i < selettori.length; i++) {
                            try {
                                var elementi = document.querySelectorAll(selettori[i]);
                                if (elementi.length > 0) {
                                    for (var j = 0; j < elementi.length; j++) {
                                        var el = elementi[j];
                                        var rect = el.getBoundingClientRect();
                                        var isVisible = rect.width > 0 && 
                                                      rect.height > 0 && 
                                                      el.offsetParent !== null &&
                                                      window.getComputedStyle(el).display !== 'none' &&
                                                      window.getComputedStyle(el).visibility !== 'hidden';
                                        
                                        if (isVisible) {
                                            // Prova vari metodi di click
                                            el.click();
                                            
                                            // Simula evento mouse per sicurezza
                                            var clickEvent = new MouseEvent('click', {
                                                bubbles: true,
                                                cancelable: true,
                                                view: window
                                            });
                                            el.dispatchEvent(clickEvent);
                                            
                                            console.log('Cliccato banner cookie: ' + selettori[i]);
                                            return true;
                                        }
                                    }
                                }
                            } catch(e) {
                                // Ignora errori
                            }
                        }
                        
                        // Cerca anche con testo
                        var bottoni = document.querySelectorAll('button');
                        for (var k = 0; k < bottoni.length; k++) {
                            var testo = bottoni[k].innerText.toLowerCase();
                            if ((testo.includes('accept') && testo.includes('cookie')) ||
                                (testo.includes('agree') && testo.includes('cookie')) ||
                                testo === 'accept all' ||
                                testo === 'i agree' ||
                                testo === 'ok') {
                                
                                var rect = bottoni[k].getBoundingClientRect();
                                if (rect.width > 0 && rect.height > 0) {
                                    bottoni[k].click();
                                    
                                    // Evento backup
                                    var clickEvent = new MouseEvent('click', {
                                        bubbles: true,
                                        cancelable: true,
                                        view: window
                                    });
                                    bottoni[k].dispatchEvent(clickEvent);
                                    
                                    console.log('Cliccato banner cookie con testo: ' + testo);
                                    return true;
                                }
                            }
                        }
                        
                        return false;
                    })();
                ";

                // Esegui script
                string risultato = await webView.ExecuteScriptAsync(scriptClick); // Esegui
                
                // Converti risultato
                bool clickRiuscito = risultato.Trim().ToLower() == "true"; // Check
                
                if (clickRiuscito)
                {
                    Debug.WriteLine("COOKIE: Click eseguito con successo"); // Log
                    
                    // Attendi che il banner scompaia
                    await Task.Delay(10); // 1 secondo
                    
                    // Verifica che sia effettivamente scomparso
                    bool ancoraPresente = await VerificaSePresente.Verifica(webView); // Ri-verifica
                    
                    if (!ancoraPresente)
                    {
                        Debug.WriteLine("COOKIE: Banner rimosso con successo"); // Log
                        return true; // Successo
                    }
                    else
                    {
                        Debug.WriteLine("COOKIE: Banner ancora presente dopo click"); // Log
                        return false; // Fallito
                    }
                }
                else
                {
                    Debug.WriteLine("COOKIE: Impossibile cliccare il banner"); // Log
                    return false; // Fallito
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"COOKIE ERRORE click: {ex.Message}"); // Log errore
                return false; // Fallito
            }
        }
        
        #endregion

        #region Helper

        /// <summary>
        /// Log helper
      
        
        #endregion
    }
}
﻿using System;using System.Diagnostics; // Sistema base
using System.Threading.Tasks; // Task asincroni
using System.Linq; // LINQ per Last()
using Microsoft.Web.WebView2.Wpf; // WebView2


namespace AlertAutomator._02_LatoFunzioni._02_EngineAutomation._01_AzionePreparazione._01_SetAsset._06_VerificaFinale
{
    /// <summary>
    /// Verifica finale se asset impostato correttamente
    /// </summary>
    public class VerificaFinale
    {
        /// <summary>
        /// Verifica se asset cambiato con successo
        /// </summary>
        public static async Task<bool> Verifica(WebView2 webView, string assetRichiesto)
        {
            try
            {
                Debug.WriteLine("SET ASSET: Verifica finale..."); // Log

                await Task.Delay(100); // Attendi caricamento

                // Script per leggere asset finale
                string scriptLeggiAsset = @"
                    (function() {
                        var currentAsset = document.querySelector('#header-toolbar-symbol-search > div');
                        if (currentAsset) {
                            return currentAsset.textContent || '';
                        }
                        return '';
                    })();
                "; // Script

                string assetFinale = await webView.ExecuteScriptAsync(scriptLeggiAsset); // Esegui
                assetFinale = assetFinale.Trim('"'); // Pulisci

                Debug.WriteLine($"SET ASSET: Asset finale: {assetFinale}"); // Log

                // Verifica se contiene il simbolo richiesto
                bool successo = false;
                
                if (assetFinale.ToUpper().Contains(assetRichiesto.Split(':').Last().ToUpper()))
                {
                    successo = true; // Successo
                    Debug.WriteLine($"SET ASSET: ✓ Asset cambiato correttamente a {assetRichiesto}"); // Log
                }
                else
                {
                    Debug.WriteLine($"SET ASSET: ✗ Asset non cambiato. Atteso: {assetRichiesto}, Trovato: {assetFinale}"); // Log
                }

                return successo; // Ritorna risultato
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"SET ASSET ERRORE verifica finale: {ex.Message}"); // Log errore
                return false; // Fallimento
            }
        }

        #region Helper

     

        #endregion
    }
}
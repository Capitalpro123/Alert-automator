using System;using System.Diagnostics; // Sistema base
using System.Collections.Generic; // Collections


namespace AlertAutomator.Funzioni.StartProduction.Azioni.AzioniPreparazione.SetAsset
{
    /// <summary>
    /// Legge asset dal foglio Google Sheets
    /// </summary>
    public class LetturaAssetDagSheet
    {
        /// <summary>
        /// Estrae asset dai dati riga
        /// </summary>
        public static string EstraiAsset(IList<object> datiRiga)
        {
            try
            {
                Debug.WriteLine("SET ASSET: Lettura asset da dati riga"); // Log
                
                // Asset da impostare � in colonna AG (indice 32)
                if (datiRiga == null || datiRiga.Count < 33)
                {
                    Debug.WriteLine("SET ASSET ERRORE: Dati riga insufficienti per colonna AG"); // Log errore
                    return null; // Nullo
                }

                string asset = datiRiga[32]?.ToString() ?? ""; // Colonna AG
                
                if (string.IsNullOrWhiteSpace(asset))
                {
                    Debug.WriteLine("SET ASSET ERRORE: Asset vuoto in colonna AG"); // Log errore
                    return null; // Nullo
                }

                Debug.WriteLine($"SET ASSET: Asset letto: {asset}"); // Log
                return asset; // Ritorna asset
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"SET ASSET ERRORE lettura: {ex.Message}"); // Log errore
                return null; // Nullo
            }
        }

        #region Helper

        /// <summary>
    

        #endregion
    }
}
using System;using System.Diagnostics; // Sistema base
using System.Threading.Tasks; // Task asincroni
using Microsoft.Web.WebView2.Wpf; // WebView2


namespace AlertAutomator._02_LatoFunzioni._02_EngineAutomation._01_AzionePreparazione._01_SetAsset._03_CollegatiAlBroswer
{
    /// <summary>
    /// Si collega al browser e ottiene info correnti
    /// </summary>
    public class CollegatiAlBrowser
    {
        /// <summary>
        /// Ottieni asset corrente dal browser
        /// </summary>
        public static async Task<string> OttieniAssetCorrente(WebView2 webView)
        {
            try
            {
                Debug.WriteLine("SET ASSET: Collegamento al browser..."); // Log

                // Script per leggere asset corrente
                string scriptLeggiAsset = @"
                    (function() {
                        var currentAsset = document.querySelector('#header-toolbar-symbol-search > div');
                        if (currentAsset) {
                            return currentAsset.textContent || '';
                        }
                        return '';
                    })();
                "; // Script

                string assetCorrente = await webView.ExecuteScriptAsync(scriptLeggiAsset); // Esegui
                assetCorrente = assetCorrente.Trim('"'); // Pulisci

                Debug.WriteLine($"SET ASSET: Asset corrente letto: {assetCorrente}"); // Log
                return assetCorrente; // Ritorna
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"SET ASSET ERRORE collegamento: {ex.Message}"); // Log errore
                return ""; // Vuoto
            }
        }

        /// <summary>
        /// Verifica se browser pronto
        /// </summary>
        public static async Task<bool> VerificaBrowserPronto(WebView2 webView)
        {
            try
            {
                // Verifica presenza elemento chiave
                string scriptVerifica = @"
                    (function() {
                        var searchBox = document.querySelector('#header-toolbar-symbol-search');
                        return searchBox ? 'ready' : 'not_ready';
                    })();
                "; // Script

                string risultato = await webView.ExecuteScriptAsync(scriptVerifica); // Esegui
                risultato = risultato.Trim('"'); // Pulisci

                bool pronto = risultato == "ready"; // Check
                Debug.WriteLine($"SET ASSET: Browser {(pronto ? "pronto" : "non pronto")}"); // Log

                return pronto; // Ritorna stato
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"SET ASSET ERRORE verifica browser: {ex.Message}"); // Log errore
                return false; // Non pronto
            }
        }

        #region Helper

    

        #endregion
    }
}
using System;using System.Diagnostics; // Sistema base
using System.Threading.Tasks; // Task asincroni
using System.Linq; // LINQ per Last()
using Microsoft.Web.WebView2.Wpf; // WebView2

using Newtonsoft.Json; // JSON

namespace AlertAutomator._02_LatoFunzioni._02_EngineAutomation._01_AzionePreparazione._01_SetAsset._05_WatchlistFallback
{
    /// <summary>
    /// Metodo fallback usando watchlist
    /// </summary>
    public class WatchlistFallback
    {
        /// <summary>
        /// Usa watchlist per impostare asset
        /// </summary>
        public static async Task<bool> UsaWatchlist(WebView2 webView, string assetSymbol)
        {
            try
            {
                Debug.WriteLine("SET ASSET FALLBACK: Inizio metodo watchlist"); // Log

                // 1. Verifica se watchlist gi� aperta
                bool watchlistAperta = await VerificaWatchlistAperta(webView); // Verifica
                Debug.WriteLine($"SET ASSET FALLBACK: Watchlist {(watchlistAperta ? "gi� aperta" : "chiusa")}"); // Log

                // 2. Apri watchlist se necessario
                if (!watchlistAperta)
                {
                    await ApriWatchlist(webView); // Apri
                    await Task.Delay(500); // Attendi
                }

                // 3. Cerca asset nella watchlist
                var coordinate = await CercaAssetInWatchlist(webView, assetSymbol); // Cerca
                
                if (coordinate != null)
                {
                    // 4. Doppio click sull'asset
                    await DoppioClickAsset(webView, coordinate.X, coordinate.Y); // Click
                    await Task.Delay(1000); // Attendi caricamento
                    
                    // 5. Chiudi watchlist
                    await ChiudiWatchlist(webView); // Chiudi
                    
                    Debug.WriteLine("SET ASSET FALLBACK: Completato con successo"); // Log
                    return true; // Successo
                }
                else
                {
                    Debug.WriteLine("SET ASSET FALLBACK: Asset non trovato nella watchlist"); // Log
                    await ChiudiWatchlist(webView); // Chiudi comunque
                    return false; // Fallimento
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"SET ASSET FALLBACK ERRORE: {ex.Message}"); // Log errore
                return false; // Fallimento
            }
        }

        /// <summary>
        /// Verifica se watchlist aperta
        /// </summary>
        private static async Task<bool> VerificaWatchlistAperta(WebView2 webView)
        {
            string script = @"
                (function() {
                    var watchlistWidget = document.querySelector('body > div.js-rootresizer__contents > div > div.layout__area--right > div > div.widgetbar-pages > div.widgetbar-pagescontent > div.widgetbar-page.active > div.widget-X9EuSe_t.widgetbar-widget.widgetbar-widget-watchlist');
                    if (watchlistWidget && watchlistWidget.offsetParent !== null) {
                        return 'open';
                    }
                    return 'closed';
                })();
            "; // Script

            string risultato = await webView.ExecuteScriptAsync(script); // Esegui
            return risultato.Trim('"') == "open"; // Ritorna stato
        }

        /// <summary>
        /// Apri watchlist
        /// </summary>
        private static async Task ApriWatchlist(WebView2 webView)
        {
            Debug.WriteLine("SET ASSET FALLBACK: Apertura watchlist"); // Log
            
            string script = @"
                (function() {
                    var watchlistButton = document.querySelector('body > div.js-rootresizer__contents > div > div.layout__area--right > div > div.widgetbar-tabs > div > div > div > div > button:first-child');
                    if (watchlistButton) {
                        watchlistButton.click();
                        return 'clicked';
                    }
                    return 'not_found';
                })();
            "; // Script

            await webView.ExecuteScriptAsync(script); // Esegui
        }

        /// <summary>
        /// Cerca asset nella watchlist
        /// </summary>
        private static async Task<Coordinate> CercaAssetInWatchlist(WebView2 webView, string assetSymbol)
        {
            Debug.WriteLine($"SET ASSET FALLBACK: Cerco '{assetSymbol}' nella watchlist"); // Log
            
            string script = $@"
                (function() {{
                    var risultato = {{
                        trovato: false,
                        x: 0,
                        y: 0
                    }};
                    
                    // Cerca elementi con la classe corretta
                    var symbols = document.querySelectorAll('div[class*=""symbol-RsFlttSS""]');
                    
                    for (var i = 0; i < symbols.length; i++) {{
                        var testoElemento = symbols[i].textContent || '';
                        
                        // Controlla se contiene l'asset cercato
                        if (testoElemento.toUpperCase().includes('{assetSymbol.ToUpper()}') || 
                            testoElemento.toUpperCase().includes('{assetSymbol.Split(':').Last().ToUpper()}')) {{
                            
                            // Ottieni coordinate
                            var rect = symbols[i].getBoundingClientRect();
                            risultato.trovato = true;
                            risultato.x = rect.left + rect.width / 2;
                            risultato.y = rect.top + rect.height / 2;
                            break;
                        }}
                    }}
                    
                    return JSON.stringify(risultato);
                }})();
            "; // Script

            string risultatoJson = await webView.ExecuteScriptAsync(script); // Esegui
            risultatoJson = risultatoJson.Trim('"').Replace("\\\"", "\""); // Pulisci

            try
            {
                var risultato = JsonConvert.DeserializeObject<RisultatoRicerca>(risultatoJson); // Parse
                
                if (risultato.trovato)
                {
                    Debug.WriteLine($"SET ASSET FALLBACK: Asset trovato alle coordinate ({risultato.x}, {risultato.y})"); // Log
                    return new Coordinate { X = risultato.x, Y = risultato.y }; // Ritorna
                }
            }
            catch { }

            return null; // Non trovato
        }

        /// <summary>
        /// Doppio click su coordinate
        /// </summary>
        private static async Task DoppioClickAsset(WebView2 webView, double x, double y)
        {
            Debug.WriteLine($"SET ASSET FALLBACK: Doppio click su ({x}, {y})"); // Log
            
            // Due click singoli
            for (int i = 0; i < 2; i++)
            {
                await webView.CoreWebView2.CallDevToolsProtocolMethodAsync(
                    "Input.dispatchMouseEvent",
                    @"{
                        ""type"": ""mousePressed"",
                        ""x"": " + x.ToString(System.Globalization.CultureInfo.InvariantCulture) + @",
                        ""y"": " + y.ToString(System.Globalization.CultureInfo.InvariantCulture) + @",
                        ""button"": ""left"",
                        ""clickCount"": " + (i + 1) + @"
                    }"
                ); // Mouse down

                await Task.Delay(50); // Pausa

                await webView.CoreWebView2.CallDevToolsProtocolMethodAsync(
                    "Input.dispatchMouseEvent",
                    @"{
                        ""type"": ""mouseReleased"",
                        ""x"": " + x.ToString(System.Globalization.CultureInfo.InvariantCulture) + @",
                        ""y"": " + y.ToString(System.Globalization.CultureInfo.InvariantCulture) + @",
                        ""button"": ""left"",
                        ""clickCount"": " + (i + 1) + @"
                    }"
                ); // Mouse up

                await Task.Delay(100); // Pausa tra click
            }
        }

        /// <summary>
        /// Chiudi watchlist
        /// </summary>
        private static async Task ChiudiWatchlist(WebView2 webView)
        {
            Debug.WriteLine("SET ASSET FALLBACK: Chiusura watchlist"); // Log
            
            string script = @"
                (function() {
                    var closeButton = document.querySelector('body > div.js-rootresizer__contents > div > div.layout__area--right > div > div.widgetbar-tabs > div > div > div > div > button:first-child');
                    if (closeButton) {
                        closeButton.click();
                        return 'closed';
                    }
                    return 'not_found';
                })();
            "; // Script

            await webView.ExecuteScriptAsync(script); // Esegui
        }

        #region Helper Classes

        private class Coordinate
        {
            public double X { get; set; }
            public double Y { get; set; }
        }

        private class RisultatoRicerca
        {
            public bool trovato { get; set; }
            public double x { get; set; }
            public double y { get; set; }
        }

        #endregion

        #region Helper

        /// <summary>
        /// Log helper
        /// </summary>
       

        #endregion
    }
}
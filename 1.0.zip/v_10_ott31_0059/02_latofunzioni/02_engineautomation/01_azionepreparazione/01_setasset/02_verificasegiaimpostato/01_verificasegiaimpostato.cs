using System;using System.Diagnostics; // Sistema base
using System.Threading.Tasks; // Task asincroni
using System.Linq; // LINQ per Last()
using Microsoft.Web.WebView2.Wpf; // WebView2
using System.Diagnostics; // per debugwriteline

namespace AlertAutomator._02_LatoFunzioni._02_EngineAutomation._01_AzionePreparazione._01_SetAsset._02_VerificaSeGiaImpostato
{
    /// <summary>
    /// Verifica se asset gi� impostato
    /// </summary>
    public class VerificaSeGiaImpostato
    {
        /// <summary>
        /// Verifica se asset gi� impostato
        /// </summary>
        public static async Task<bool> Verifica(WebView2 webView, string assetRichiesto, string lastSetAsset)
        {
            try
            {
                Debug.WriteLine("SET ASSET: Verifica se gi� impostato..."); // Log

                // REGOLA CHIAVE: Se l'asset � gi� stato impostato, SKIP
                if (lastSetAsset != null && lastSetAsset.Equals(assetRichiesto, StringComparison.OrdinalIgnoreCase))
                {
                    Debug.WriteLine($"SET ASSET: {assetRichiesto} gi� impostato in precedenza, skip"); // Log
                    return true; // Gi� impostato
                }

                // Leggi asset corrente dal DOM
                string scriptLeggiAsset = @"
                    (function() {
                        var currentAsset = document.querySelector('#header-toolbar-symbol-search > div');
                        if (currentAsset) {
                            return currentAsset.textContent || '';
                        }
                        return '';
                    })();
                "; // Script lettura

                string assetCorrente = await webView.ExecuteScriptAsync(scriptLeggiAsset); // Esegui
                assetCorrente = assetCorrente.Trim('"'); // Pulisci

                Debug.WriteLine($"SET ASSET: Asset corrente nel browser: {assetCorrente}"); // Log

                // Controlla se l'asset corrente contiene gi� il simbolo
                if (assetCorrente.Contains(assetRichiesto, StringComparison.OrdinalIgnoreCase) || 
                    assetCorrente.Contains(assetRichiesto.Split(':').Last(), StringComparison.OrdinalIgnoreCase))
                {
                    Debug.WriteLine($"SET ASSET: {assetRichiesto} gi� visualizzato, skip"); // Log
                    return true; // Gi� impostato
                }

                Debug.WriteLine("SET ASSET: Asset non ancora impostato, procedo"); // Log
                return false; // Non impostato
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"SET ASSET ERRORE verifica: {ex.Message}"); // Log errore
                return false; // Considera non impostato
            }
        }

        #region Helper

     

        #endregion
    }
}
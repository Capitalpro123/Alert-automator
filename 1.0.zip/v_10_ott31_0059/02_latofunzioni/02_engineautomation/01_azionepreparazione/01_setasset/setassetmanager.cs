﻿using AlertAutomator._02_LatoFunzioni._02_EngineAutomation._01_AzionePreparazione._01_SetAsset._02_VerificaSeGiaImpostato;
using AlertAutomator._02_LatoFunzioni._02_EngineAutomation._01_AzionePreparazione._01_SetAsset._03_CollegatiAlBroswer;
using AlertAutomator._02_LatoFunzioni._02_EngineAutomation._01_AzionePreparazione._01_SetAsset._04_ImpostaDigitando;
using AlertAutomator._02_LatoFunzioni._02_EngineAutomation._01_AzionePreparazione._01_SetAsset._05_WatchlistFallback;
using AlertAutomator._02_LatoFunzioni._02_EngineAutomation._01_AzionePreparazione._01_SetAsset._06_VerificaFinale;
using Microsoft.Web.WebView2.Wpf; // WebView2
using System;
using System.Diagnostics; // Sistema base
using System.Threading.Tasks; // Task asincroni

namespace AlertAutomator._02_LatoFunzioni._02_EngineAutomation._01_AzionePreparazione._01_SetAsset
{
    /// <summary>
    /// Manager per impostazione asset su TradingView
    /// </summary>
    public class SetAssetManager
    {
        #region Campi Statici
        
        private static string _lastSetAsset = null; // Ultimo asset impostato
        
        #endregion

        #region Metodo Principale

        /// <summary>
        /// Esegue processo completo SetAsset
        /// </summary>
        public static async Task<bool> Esegui(WebView2 webView, string assetSymbol)
        {
            try
            {
               
                Debug.WriteLine($"SET ASSET: Asset richiesto: {assetSymbol}"); // Log

                // Validazione parametri
                if (webView == null)
                {
                    Debug.WriteLine("SET ASSET ERRORE: WebView nullo"); // Log errore
                    return false; // 
                }

                if (string.IsNullOrWhiteSpace(assetSymbol))
                {
                    Debug.WriteLine("SET ASSET ERRORE: Asset vuoto o nullo"); // Log errore
                    return false; // 
                }

                // 1. Verifica se già impostato
                if (await VerificaSeGiaImpostato.Verifica(webView, assetSymbol, _lastSetAsset))
                {
                    Debug.WriteLine("SET ASSET: Asset già impostato, skip"); // Log
                    Debug.WriteLine("---------══════════════════"); // Separatore
                    return true; // Successo
                }

                // 2. Collegati al browser e ottieni asset corrente
                string assetCorrente = await CollegatiAlBrowser.OttieniAssetCorrente(webView); // Ottieni
                Debug.WriteLine($"SET ASSET: Asset corrente: {assetCorrente}"); // Log

                // 3. Imposta digitando (metodo primario)
                bool successoPrimario = await ImpostaDigitando.Imposta(webView, assetSymbol); // Imposta
                
                if (successoPrimario)
                {
                    // 4. Verifica finale
                    bool verificato = await VerificaFinale.Verifica(webView, assetSymbol); // Verifica
                    
                    if (verificato)
                    {
                        _lastSetAsset = assetSymbol; // Memorizza
                        Debug.WriteLine("SET ASSET: Completato con successo (metodo primario)"); // Log
                        Debug.WriteLine("---------══════════════════"); // Separatore
                        return true; // Successo
                    }
                }

                // 5. Fallback Watchlist se metodo primario fallisce
                Debug.WriteLine("SET ASSET: Metodo primario fallito, uso watchlist"); // Log
                bool successoWatchlist = await WatchlistFallback.UsaWatchlist(webView, assetSymbol); // Fallback

                if (successoWatchlist)
                {
                    // 6. Verifica finale dopo watchlist
                    bool verificato = await VerificaFinale.Verifica(webView, assetSymbol); // Verifica
                    
                    if (verificato)
                    {
                        _lastSetAsset = assetSymbol; // Memorizza
                        Debug.WriteLine("SET ASSET: Completato con successo (watchlist)"); // Log
                        Debug.WriteLine("---------══════════════════"); // Separatore
                        return true; // Successo
                    }
                }

                Debug.WriteLine("SET ASSET ERRORE: Impossibile impostare asset"); // Log errore
                Debug.WriteLine("---------══════════════════"); // Separatore
                return false; // Fallimento
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"SET ASSET ERRORE: {ex.Message}"); // Log errore
                Debug.WriteLine("---------══════════════════"); // Separatore
                return false; // Fallimento
            }
        }

        #endregion

        #region Helper

        /// <summary>
        /// Log helper
        /// </summary>
    
        #endregion
    }
}
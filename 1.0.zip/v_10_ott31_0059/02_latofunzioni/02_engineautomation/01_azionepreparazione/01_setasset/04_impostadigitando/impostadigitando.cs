using System;using System.Diagnostics; // Sistema base
using System.Threading.Tasks; // Task asincroni
using Microsoft.Web.WebView2.Wpf; // WebView2


namespace AlertAutomator._02_LatoFunzioni._02_EngineAutomation._01_AzionePreparazione._01_SetAsset._04_ImpostaDigitando
{
    /// <summary>
    /// Imposta asset digitando nel campo ricerca
    /// </summary>
    public class ImpostaDigitando
    {
        /// <summary>
        /// Imposta asset tramite digitazione diretta
        /// </summary>
        public static async Task<bool> Imposta(WebView2 webView, string assetSymbol)
        {
            try
            {
                Debug.WriteLine("SET ASSET: Metodo primario - digitazione diretta"); // Log

                // CTRL+A per selezionare tutto
                Debug.WriteLine("SET ASSET: CTRL+A per selezionare tutto"); // Log
                
                await webView.CoreWebView2.CallDevToolsProtocolMethodAsync(
                    "Input.dispatchKeyEvent",
                    @"{
                        ""type"": ""keyDown"",
                        ""key"": ""Control"",
                        ""code"": ""ControlLeft"",
                        ""modifiers"": 2
                    }"
                ); // Ctrl down

                await Task.Delay(50); // Pausa

                await webView.CoreWebView2.CallDevToolsProtocolMethodAsync(
                    "Input.dispatchKeyEvent",
                    @"{
                        ""type"": ""keyDown"",
                        ""key"": ""a"",
                        ""code"": ""KeyA"",
                        ""modifiers"": 2
                    }"
                ); // A down

                await Task.Delay(50); // Pausa

                await webView.CoreWebView2.CallDevToolsProtocolMethodAsync(
                    "Input.dispatchKeyEvent",
                    @"{
                        ""type"": ""keyUp"",
                        ""key"": ""a"",
                        ""code"": ""KeyA"",
                        ""modifiers"": 2
                    }"
                ); // A up

                await webView.CoreWebView2.CallDevToolsProtocolMethodAsync(
                    "Input.dispatchKeyEvent",
                    @"{
                        ""type"": ""keyUp"",
                        ""key"": ""Control"",
                        ""code"": ""ControlLeft""
                    }"
                ); // Ctrl up

                await Task.Delay(100); // Pausa

                // Digita l'asset carattere per carattere
                Debug.WriteLine($"SET ASSET: Digitazione '{assetSymbol}'"); // Log
                
                foreach (char c in assetSymbol)
                {
                    await webView.CoreWebView2.CallDevToolsProtocolMethodAsync(
                        "Input.dispatchKeyEvent",
                        @"{
                            ""type"": ""char"",
                            ""text"": """ + c + @"""
                        }"
                    ); // Digita carattere

                    await Task.Delay(50); // Pausa tra caratteri
                }

                await Task.Delay(500); // Attendi completamento

                // ENTER ULTRA POTENZIATO - Multipli metodi
                Debug.WriteLine("SET ASSET: ENTER ultra potenziato"); // Log
                
                // Metodo 1: Enter normale
                await webView.CoreWebView2.CallDevToolsProtocolMethodAsync(
                    "Input.dispatchKeyEvent",
                    @"{
                        ""type"": ""keyDown"",
                        ""key"": ""Enter"",
                        ""code"": ""Enter"",
                        ""keyCode"": 13,
                        ""windowsVirtualKeyCode"": 13
                    }"
                ); // Enter down

                await Task.Delay(50); // Pausa

                await webView.CoreWebView2.CallDevToolsProtocolMethodAsync(
                    "Input.dispatchKeyEvent",
                    @"{
                        ""type"": ""keyUp"",
                        ""key"": ""Enter"",
                        ""code"": ""Enter"",
                        ""keyCode"": 13,
                        ""windowsVirtualKeyCode"": 13
                    }"
                ); // Enter up

                await Task.Delay(200); // Pausa

                // Metodo 2: Enter con rawKeyDown
                await webView.CoreWebView2.CallDevToolsProtocolMethodAsync(
                    "Input.dispatchKeyEvent",
                    @"{
                        ""type"": ""rawKeyDown"",
                        ""key"": ""Enter"",
                        ""code"": ""Enter"",
                        ""keyCode"": 13,
                        ""windowsVirtualKeyCode"": 13,
                        ""nativeVirtualKeyCode"": 13
                    }"
                ); // Raw key down

                await Task.Delay(50); // Pausa

                await webView.CoreWebView2.CallDevToolsProtocolMethodAsync(
                    "Input.dispatchKeyEvent",
                    @"{
                        ""type"": ""keyUp"",
                        ""key"": ""Enter"",
                        ""code"": ""Enter"",
                        ""keyCode"": 13,
                        ""windowsVirtualKeyCode"": 13,
                        ""nativeVirtualKeyCode"": 13
                    }"
                ); // Key up

                await Task.Delay(200); // Pausa

                // Metodo 3: Doppio Enter per sicurezza
                for (int i = 0; i < 2; i++)
                {
                    await webView.CoreWebView2.CallDevToolsProtocolMethodAsync(
                        "Input.dispatchKeyEvent",
                        @"{
                            ""type"": ""keyDown"",
                            ""key"": ""Enter"",
                            ""code"": ""Enter"",
                            ""keyCode"": 13
                        }"
                    ); // Enter down

                    await Task.Delay(50); // Pausa

                    await webView.CoreWebView2.CallDevToolsProtocolMethodAsync(
                        "Input.dispatchKeyEvent",
                        @"{
                            ""type"": ""keyUp"",
                            ""key"": ""Enter"",
                            ""code"": ""Enter"",
                            ""keyCode"": 13
                        }"
                    ); // Enter up

                    await Task.Delay(100); // Pausa tra enter
                }

                await Task.Delay(1500); // Attendi caricamento

                Debug.WriteLine("SET ASSET: Digitazione completata"); // Log
                return true; // Successo
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"SET ASSET ERRORE digitazione: {ex.Message}"); // Log errore
                return false; // Fallimento
            }
        }

        #region Helper

        /// <summary>
        /// Log helper
        /// </summary>
     

        #endregion
    }
}
using System;using System.Diagnostics;
using System.Diagnostics;
using System.Threading.Tasks;
using Microsoft.Web.WebView2.Wpf;

namespace AlertAutomator._02_LatoFunzioni._02_EngineAutomation._01_AzionePreparazione._04_ClickAStellaDiSegni
{
    /// <summary>
    /// Manager per click sulla stella dei disegni
    /// Responsabilità: selezionare stella e cliccare
    /// </summary>
    public class ClickaStellaDisegniManager
    {
        /// <summary>
        /// Esegue click sulla stella disegni
        /// </summary>
        public static async Task<bool> Esegui(WebView2 webView)
        {
            try
            {
                Debug.WriteLine("╔════════════════════════════════════════════════════════╗");
                Debug.WriteLine("║   CLICK STELLA DISEGNI - INIZIO                        ║");
                Debug.WriteLine("╚════════════════════════════════════════════════════════╝");

                if (webView == null)
                {
                    Debug.WriteLine("[CLICK STELLA] ERRORE: WebView nullo");
                    return false;
                }

                // 1. Selettore stella
                Debug.WriteLine("[CLICK STELLA] STEP 1: Selezione stella");
                string selettore = SelettoreStella.GetSelettore();
                Debug.WriteLine($"[CLICK STELLA] Selettore: {selettore}");

                // 2. Click bottone
                Debug.WriteLine("[CLICK STELLA] STEP 2: Click sul bottone");
                bool clickOk = await ClickBottone.Clicca(webView, selettore);

                if (clickOk)
                {
                    Debug.WriteLine("[CLICK STELLA] Click eseguito con successo");
                }
                else
                {
                    Debug.WriteLine("[CLICK STELLA] ERRORE: Click fallito");
                }

                Debug.WriteLine("╔════════════════════════════════════════════════════════╗");
                Debug.WriteLine("║   CLICK STELLA DISEGNI - COMPLETATO                    ║");
                Debug.WriteLine("╚════════════════════════════════════════════════════════╝");

                return clickOk;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[CLICK STELLA] ERRORE: {ex.Message}");
                Debug.WriteLine($"[CLICK STELLA] StackTrace: {ex.StackTrace}");
                return false;
            }
        }
    }
}
using System;using System.Diagnostics;
using System.Diagnostics;
using System.Threading.Tasks;
using Microsoft.Web.WebView2.Wpf;

namespace AlertAutomator._02_LatoFunzioni._02_EngineAutomation._01_AzionePreparazione._04_ClickAStellaDiSegni
{
    /// <summary>
    /// Click sul bottone stella
    /// Responsabilità: eseguire click reale sul selettore
    /// </summary>
    public class ClickBottone
    {
        /// <summary>
        /// Clicca sul bottone
        /// </summary>
        public static async Task<bool> Clicca(WebView2 webView, string selettore)
        {
            try
            {
                string scriptClick = $@"
                    (function() {{
                        try {{
                            var elemento = document.querySelector('{selettore}');
                            if (elemento) {{
                                elemento.click();
                                return 'clicked';
                            }}
                            return 'not_found';
                        }} catch(e) {{
                            return 'error: ' + e.message;
                        }}
                    }})();
                ";

                string risultato = await webView.CoreWebView2.ExecuteScriptAsync(scriptClick);
                
                Debug.WriteLine($"[CLICK BOTTONE] Risultato: {risultato}");

                if (risultato.Contains("clicked"))
                {
                    await Task.Delay(500);
                    return true;
                }

                return false;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[CLICK BOTTONE] ERRORE: {ex.Message}");
                return false;
            }
        }
    }
}
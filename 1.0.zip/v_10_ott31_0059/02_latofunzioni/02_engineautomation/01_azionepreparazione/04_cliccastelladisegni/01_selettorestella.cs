namespace AlertAutomator._02_LatoFunzioni._02_EngineAutomation._01_AzionePreparazione._04_ClickAStellaDiSegni
{
    /// <summary>
    /// Selettore CSS per stella disegni
    /// Responsabilità: fornire selettore CSS
    /// </summary>
    public class SelettoreStella
    {
        /// <summary>
        /// Ritorna selettore CSS per stella disegni
        /// </summary>
        public static string GetSelettore()
        {
            return "#drawing-toolbar-favorite-drawings";
        }
    }
}
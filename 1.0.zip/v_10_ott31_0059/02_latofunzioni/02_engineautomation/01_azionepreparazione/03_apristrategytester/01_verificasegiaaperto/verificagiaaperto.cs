using System;using System.Diagnostics; // Sistema base
using System.Threading.Tasks; // Task asincroni
using Microsoft.Web.WebView2.Wpf; // WebView2


namespace AlertAutomator._02_LatoFunzioni._02_EngineAutomation._01_AzionePreparazione._03_ApriStrategyTester._01_VerificaSeGiaAperto
{
    /// <summary>
    /// Verifica se Strategy Tester gi� aperto
    /// </summary>
    public class VerificaGiaAperto
    {
        /// <summary>
        /// Verifica se pannello gi� aperto
        /// </summary>
        public static async Task<bool> Verifica(WebView2 webView)
        {
            try
            {
                Debug.WriteLine("STRATEGY TESTER: Verifica se gi� aperto..."); // Log

                // Script per verificare se pannello aperto
                string scriptVerifica = @"
                    (function() {
                        var pannello = document.querySelector('#bottom-area > div.bottom-widgetbar-content.backtesting > div > div > div > div.container-uVPE3kR5');
                        if (pannello && pannello.offsetParent !== null) {
                            return 'open';
                        }
                        return 'closed';
                    })();
                "; // Script

                string risultato = await webView.ExecuteScriptAsync(scriptVerifica); // Esegui
                bool aperto = risultato.Contains("open"); // Check

                Debug.WriteLine($"STRATEGY TESTER: Stato attuale: {(aperto ? "APERTO" : "CHIUSO")}"); // Log
                return aperto; // Ritorna stato
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"STRATEGY TESTER ERRORE verifica: {ex.Message}"); // Log errore
                return false; // Considera chiuso
            }
        }

        #region Helper

       

        #endregion
    }
}
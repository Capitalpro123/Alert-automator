using System;using System.Diagnostics; // Sistema base
using System.Threading.Tasks; // Task asincroni
using Microsoft.Web.WebView2.Wpf; // WebView2


namespace AlertAutomator._02_LatoFunzioni._02_EngineAutomation._01_AzionePreparazione._03_ApriStrategyTester._03_VerificaSeAperto
{
    /// <summary>
    /// Verifica se Strategy Tester aperto dopo click
    /// </summary>
    public class VerificaSeAperto
    {
        /// <summary>
        /// Verifica apertura dopo click
        /// </summary>
        public static async Task<bool> Verifica(WebView2 webView)
        {
            try
            {
                Debug.WriteLine("STRATEGY TESTER: Verifica apertura dopo click..."); // Log

                // Attendi che si apra
                await Task.Delay(50); // Mezzo secondo

                // Script per verificare apertura
                string scriptVerifica = @"
                    (function() {
                        // Metodo 1: Verifica pannello
                        var pannello = document.querySelector('#bottom-area > div.bottom-widgetbar-content.backtesting');
                        if (pannello && pannello.offsetParent !== null) {
                            return 'open_panel';
                        }
                        
                        // Metodo 2: Verifica container
                        var container = document.querySelector('.container-uVPE3kR5');
                        if (container && container.offsetParent !== null) {
                            return 'open_container';
                        }
                        
                        // Metodo 3: Verifica bottone attivo
                        var button = document.querySelector('#footer-chart-panel button.isActive-n3UmcVi3');
                        if (button) {
                            var title = button.getAttribute('title') || '';
                            if (title.toLowerCase().includes('strategy')) {
                                return 'button_active';
                            }
                        }
                        
                        return 'closed';
                    })();
                "; // Script

                string risultato = await webView.ExecuteScriptAsync(scriptVerifica); // Esegui
                risultato = risultato.Trim('"'); // Pulisci

                bool aperto = !risultato.Contains("closed"); // Check

                if (aperto)
                {
                    Debug.WriteLine($"STRATEGY TESTER: Confermato APERTO ({risultato})"); // Log
                }
                else
                {
                    Debug.WriteLine("STRATEGY TESTER: Ancora CHIUSO dopo click"); // Log
                }

                return aperto; // Ritorna stato
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"STRATEGY TESTER ERRORE verifica post-click: {ex.Message}"); // Log errore
                return false; // Considera chiuso
            }
        }

        #region Helper

        /// <summary>
        /// Log helper
        /// </summary>
       

        #endregion
    }
}
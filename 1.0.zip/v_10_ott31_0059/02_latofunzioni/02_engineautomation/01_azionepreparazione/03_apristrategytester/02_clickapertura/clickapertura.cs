using System;using System.Diagnostics; // Sistema base
using System.Threading.Tasks; // Task asincroni
using Microsoft.Web.WebView2.Wpf; // WebView2


namespace AlertAutomator._02_LatoFunzioni._02_EngineAutomation._01_AzionePreparazione._03_ApriStrategyTester._02_ClickApertura
{
    /// <summary>
    /// Click per aprire Strategy Tester
    /// </summary>
    public class ClickApertura
    {
        /// <summary>
        /// Clicca sul bottone Strategy Tester
        /// </summary>
        public static async Task<bool> Clicca(WebView2 webView)
        {
            try
            {
                Debug.WriteLine("STRATEGY TESTER: Click su bottone apertura"); // Log

                // Script per cliccare bottone Strategy Tester
                string scriptClick = @"
                    (function() {
                        var button = document.querySelector('#footer-chart-panel > div.tabbar-n3UmcVi3 > div:nth-child(1) > div:nth-child(2) > button');
                        if (button) {
                            // Verifica se attivo
                            var isActive = button.classList.contains('isActive-n3UmcVi3');
                            if (!isActive) {
                                button.click();
                                return 'clicked';
                            }
                            return 'already_active';
                        }
                        return 'not_found';
                    })();
                "; // Script

                string risultato = await webView.ExecuteScriptAsync(scriptClick); // Esegui
                risultato = risultato.Trim('"'); // Pulisci

                if (risultato == "clicked")
                {
                    Debug.WriteLine("STRATEGY TESTER: Click eseguito"); // Log
                    return true; // Successo
                }
                else if (risultato == "already_active")
                {
                    Debug.WriteLine("STRATEGY TESTER: Gi� attivo"); // Log
                    return true; // Gi� aperto
                }
                else
                {
                    Debug.WriteLine("STRATEGY TESTER: Bottone non trovato"); // Log
                    
                    // Prova selettore alternativo
                    return await TentaSelettoreAlternativo(webView); // Prova alternativo
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"STRATEGY TESTER ERRORE click: {ex.Message}"); // Log errore
                return false; // Fallimento
            }
        }

        /// <summary>
        /// Tenta selettore alternativo
        /// </summary>
        private static async Task<bool> TentaSelettoreAlternativo(WebView2 webView)
        {
            try
            {
                Debug.WriteLine("STRATEGY TESTER: Provo selettore alternativo"); // Log

                // Selettore pi� generico
                string scriptAlternativo = @"
                    (function() {
                        // Cerca tutti i bottoni nella tabbar
                        var buttons = document.querySelectorAll('#footer-chart-panel button');
                        for (var i = 0; i < buttons.length; i++) {
                            var title = buttons[i].getAttribute('title') || '';
                            var text = buttons[i].textContent || '';
                            if (title.toLowerCase().includes('strategy') || 
                                text.toLowerCase().includes('strategy')) {
                                buttons[i].click();
                                return 'clicked';
                            }
                        }
                        return 'not_found';
                    })();
                "; // Script

                string risultato = await webView.ExecuteScriptAsync(scriptAlternativo); // Esegui
                
                if (risultato.Contains("clicked"))
                {
                    Debug.WriteLine("STRATEGY TESTER: Click alternativo riuscito"); // Log
                    return true; // Successo
                }

                Debug.WriteLine("STRATEGY TESTER: Nessun bottone trovato"); // Log
                return false; // Fallimento
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"STRATEGY TESTER ERRORE alternativo: {ex.Message}"); // Log errore
                return false; // Fallimento
            }
        }

        #region Helper

        /// <summary>
        /// Log helper
        /// </summary>
      
        #endregion
    }
}
﻿using AlertAutomator._02_LatoFunzioni._02_EngineAutomation._01_AzionePreparazione._03_ApriStrategyTester._01_VerificaSeGiaAperto;
using AlertAutomator._02_LatoFunzioni._02_EngineAutomation._01_AzionePreparazione._03_ApriStrategyTester._02_ClickApertura;
using AlertAutomator._02_LatoFunzioni._02_EngineAutomation._01_AzionePreparazione._03_ApriStrategyTester._03_VerificaSeAperto;
using Microsoft.Web.WebView2.Wpf; // WebView2
using System;
using System.Diagnostics; // Sistema base
using System.Threading.Tasks; // Task asincroni


namespace AlertAutomator._02_LatoFunzioni._02_EngineAutomation._01_AzionePreparazione._03_ApriStrategyTester
{
    /// <summary>
    /// Manager per apertura Strategy Tester
    /// </summary>
    public class StrategyTesterManager
    {
        #region Metodo Principale

        /// <summary>
        /// Esegue processo completo apertura Strategy Tester
        /// </summary>
        public static async Task<bool> Esegui(WebView2 webView)
        {
            try
            {
                Debug.WriteLine("---------══════════════════"); // Separatore
                Debug.WriteLine("STRATEGY TESTER: Inizio processo"); // Log

                // Validazione parametri
                if (webView == null)
                {
                    Debug.WriteLine("STRATEGY TESTER ERRORE: WebView nullo"); // Log errore
                    return false; // 
                }

                // 1. Verifica se già aperto
                bool giaAperto = await VerificaGiaAperto.Verifica(webView); // Verifica
                
                if (giaAperto)
                {
                    Debug.WriteLine("STRATEGY TESTER: Già aperto, skip"); // Log
                    Debug.WriteLine("---------══════════════════"); // Separatore
                    return true; // Successo
                }

                // 2. Click apertura
                Debug.WriteLine("STRATEGY TESTER: Procedo con apertura"); // Log
                bool clickRiuscito = await ClickApertura.Clicca(webView); // Click
                
                if (!clickRiuscito)
                {
                    Debug.WriteLine("STRATEGY TESTER ERRORE: Click apertura fallito"); // Log errore
                    Debug.WriteLine("---------══════════════════"); // Separatore
                    return false; // 
                }

                await Task.Delay(500); // Attendi apertura

                // 3. Verifica se aperto dopo click
                bool apertoDopoClick = await VerificaSeAperto.Verifica(webView); // Verifica
                
                if (apertoDopoClick)
                {
                    Debug.WriteLine("STRATEGY TESTER: Aperto con successo"); // Log
                    
                    // Gestisci eventuale banner Deep Backtesting
                    await GestisciBannerDeepBacktesting(webView); // Gestisci
                    
                    Debug.WriteLine("---------══════════════════"); // Separatore
                    return true; // Successo
                }
                else
                {
                    Debug.WriteLine("STRATEGY TESTER ERRORE: Non riuscito ad aprire"); // Log errore
                    Debug.WriteLine("---------══════════════════"); // Separatore
                    return false; // Fallimento
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"STRATEGY TESTER ERRORE: {ex.Message}"); // Log errore
                Debug.WriteLine("---------══════════════════"); // Separatore
                return false; // Fallimento
            }
        }

        #endregion

        #region Metodi Privati

        /// <summary>
        /// Gestisci banner Deep Backtesting
        /// </summary>
        private static async Task GestisciBannerDeepBacktesting(WebView2 webView)
        {
            try
            {
                Debug.WriteLine("STRATEGY TESTER: Verifica banner Deep Backtesting"); // Log

                string scriptVerificaBanner = @"
                    (function() {
                        var banner = document.querySelector('#bottom-area > div.bottom-widgetbar-content.backtesting > div > div > div > div.backtestingWarningContainer-c7aRkO2u > div > div');
                        return banner ? 'present' : 'not_present';
                    })();
                "; // Script

                string statoBanner = await webView.ExecuteScriptAsync(scriptVerificaBanner); // Verifica

                if (statoBanner.Contains("present"))
                {
                    Debug.WriteLine("STRATEGY TESTER: Banner Deep Backtesting presente, chiudo"); // Log

                    string scriptChiudiBanner = @"
                        (function() {
                            var closeButton = document.querySelector('#bottom-area > div.bottom-widgetbar-content.backtesting > div > div > div > div.backtestingWarningContainer-c7aRkO2u > div > div > button');
                            if (closeButton) {
                                closeButton.click();
                                return 'closed';
                            }
                            return 'not_found';
                        })();
                    "; // Script

                    await webView.ExecuteScriptAsync(scriptChiudiBanner); // Chiudi
                    await Task.Delay(500); // Attendi
                    Debug.WriteLine("STRATEGY TESTER: Banner chiuso"); // Log
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"STRATEGY TESTER WARNING banner: {ex.Message}"); // Log warning
            }
        }

        #endregion

        #region Helper

        /// <summary>
        /// Log helper
        /// </summary>
       

        #endregion
    }
}
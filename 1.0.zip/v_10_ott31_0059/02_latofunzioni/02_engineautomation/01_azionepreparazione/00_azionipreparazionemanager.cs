
using AlertAutomator._02_LatoFunzioni._02_EngineAutomation._01_AzionePreparazione._03_ApriStrategyTester;
using AlertAutomator._02_LatoFunzioni._02_EngineAutomation._01_AzionePreparazione._01_SetAsset;
using AlertAutomator._02_LatoFunzioni._02_EngineAutomation._01_AzionePreparazione._02_SetTF;
using AlertAutomator._02_LatoFunzioni._02_EngineAutomation._01_AzionePreparazione._00_AccettaCookie;
using AlertAutomator._02_LatoFunzioni._02_EngineAutomation._01_AzionePreparazione._04_ClickAStellaDiSegni;
using Microsoft.Web.WebView2.Wpf;
using System;
using System.Diagnostics;
using System.Threading.Tasks;

namespace AlertAutomator._02_LatoFunzioni._02_EngineAutomation._01_AzionePreparazione

{
    public class AzioniPreparazioneManager
    {
        public static async Task<bool> Esegui(WebView2 webView, string assetSymbol, string timeframeTarget)
        {
            try
            {
                Debug.WriteLine("??????????????????????????????????????????????????????????");
                Debug.WriteLine("?   AZIONI PREPARAZIONE - INIZIO                         ?");
                Debug.WriteLine("??????????????????????????????????????????????????????????");

                if (webView == null)
                {
                    Debug.WriteLine("[AZIONI PREPARAZIONE] ERRORE: WebView nullo");
                    return false;
                }

                Debug.WriteLine($"[AZIONI PREPARAZIONE] Asset: {assetSymbol}");
                Debug.WriteLine($"[AZIONI PREPARAZIONE] Timeframe: {timeframeTarget}");

                // ============================================
                // STEP 1: Accetta Cookie
                // ============================================
                Debug.WriteLine("----------------------------------------------------");
                Debug.WriteLine("[AZIONI PREPARAZIONE] STEP 1: Accetta Cookie");

                bool cookieOk = await AccettaCookieManager.Esegui(webView);
                if (!cookieOk)
                {
                    Debug.WriteLine("[AZIONI PREPARAZIONE] ERRORE: Accetta Cookie fallito");
                    return false;
                }

                Debug.WriteLine("[AZIONI PREPARAZIONE] STEP 1 completato");

                // ============================================
                // STEP 2: Set Asset
                // ============================================
                Debug.WriteLine("----------------------------------------------------");
                Debug.WriteLine("[AZIONI PREPARAZIONE] STEP 2: Set Asset");

                bool assetOk = await SetAssetManager.Esegui(webView, assetSymbol);
                if (!assetOk)
                {
                    Debug.WriteLine("[AZIONI PREPARAZIONE] ERRORE: Set Asset fallito");
                    return false;
                }

                Debug.WriteLine("[AZIONI PREPARAZIONE] STEP 2 completato");

                // ============================================
                // STEP 3: Set Timeframe
                // ============================================
                Debug.WriteLine("----------------------------------------------------");
                Debug.WriteLine("[AZIONI PREPARAZIONE] STEP 3: Set Timeframe");

                bool tfOk = await SetTfManager.Esegui(webView, timeframeTarget);
                if (!tfOk)
                {
                    Debug.WriteLine("[AZIONI PREPARAZIONE] ERRORE: Set Timeframe fallito");
                    return false;
                }

                Debug.WriteLine("[AZIONI PREPARAZIONE] STEP 3 completato");

                // ============================================
                // STEP 4: Strategy Tester
                // ============================================
                Debug.WriteLine("----------------------------------------------------");
                Debug.WriteLine("[AZIONI PREPARAZIONE] STEP 4: Strategy Tester");

                bool testerOk = await StrategyTesterManager.Esegui(webView);
                if (!testerOk)
                {
                    Debug.WriteLine("[AZIONI PREPARAZIONE] ERRORE: Strategy Tester fallito");
                    return false;
                }

                Debug.WriteLine("[AZIONI PREPARAZIONE] STEP 4 completato");

                // ============================================
                // STEP 5: Click Stella Di Segni
                // ============================================
                Debug.WriteLine("----------------------------------------------------");
                Debug.WriteLine("[AZIONI PREPARAZIONE] STEP 5: Click Stella Di Segni");

                bool stellaOk = await ClickaStellaDisegniManager.Esegui(webView);
                if (!stellaOk)
                {
                    Debug.WriteLine("[AZIONI PREPARAZIONE] ERRORE: Click Stella Di Segni fallito");
                    return false;
                }

                Debug.WriteLine("[AZIONI PREPARAZIONE] STEP 5 completato");

                // ============================================
                // COMPLETAMENTO
                // ============================================
                Debug.WriteLine("??????????????????????????????????????????????????????????");
                Debug.WriteLine("?   AZIONI PREPARAZIONE - COMPLETATO                     ?");
                Debug.WriteLine("??????????????????????????????????????????????????????????");

                return true;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[AZIONI PREPARAZIONE] ERRORE CRITICO: {ex.Message}");
                Debug.WriteLine($"[AZIONI PREPARAZIONE] StackTrace: {ex.StackTrace}");
                return false;
            }
        }
    }
}
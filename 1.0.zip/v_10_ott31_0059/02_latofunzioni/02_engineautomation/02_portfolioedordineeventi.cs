using System;
using System.Diagnostics;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Google.Apis.Auth.OAuth2;
using Google.Apis.Services;
using Google.Apis.Sheets.v4;
using Microsoft.Web.WebView2.Wpf;
using AlertAutomator._02_LatoFunzioni._02_EngineAutomation._01_AzionePreparazione;
using AlertAutomator.Funzioni.EngineAutomation.AzioneProduzione;

namespace AlertAutomator._02_LatoFunzioni._02_EngineAutomation
{
    public class PortfolioEdOrdineEventi
    {
        private static string _spreadsheetId;
        private static SheetsService _sheetsService;
        private static string _tabSelezionata;
        private static int _startRow;
        private static int _stopRow;
        private static List<Dictionary<string, string>> _righePortfolio;

        // MAPPATURA COLONNE PORTFOLIO
        // A: User ID
        // B: Lot Size
        // C: Trading Symbol (ASSET)
        // D: TP Pips
        // E: SL Pips
        // F: Comment
        // G: sessionStart
        // H: sessionEnd
        // I: Quantity Size
        // J: EMA Length
        // K: Stoploss
        // L: RR
        // M: Time-Zone A(same year)
        // N: D:(Start)
        // O: M:(Start)
        // P: D:(End)
        // Q: M:(End)
        // R: Time-Zone B (Excluding Timezone A)
        // S: tickerTV
        // T: tf (TIMEFRAME)

        public static async Task<bool> Esegui()
        {
            try
            {
                Debug.WriteLine("╔════════════════════════════════════════════════════════╗");
                Debug.WriteLine("║   PORTFOLIO ED ORDINE EVENTI - INIZIO                  ║");
                Debug.WriteLine("╚════════════════════════════════════════════════════════╝");

                // STEP 1: Leggi configurazione da txt
                if (!LeggiConfigurazione())
                {
                    Debug.WriteLine("[PORTFOLIO] ERRORE: Impossibile leggere configurazione");
                    return false;
                }

                // STEP 2: Inizializza Google Sheets Service
                if (!await InizializzaGoogleSheets())
                {
                    Debug.WriteLine("[PORTFOLIO] ERRORE: Impossibile inizializzare Google Sheets");
                    return false;
                }

                // STEP 3: Leggi righe dal portfolio
                if (!await LeggiRighePortfolio())
                {
                    Debug.WriteLine("[PORTFOLIO] ERRORE: Impossibile leggere righe portfolio");
                    return false;
                }

                // STEP 4: Ottieni WebView2 dal monitor - RICERCA PRECISA
                WebView2 webView = GetWebViewFromMonitor();
                if (webView == null)
                {
                    Debug.WriteLine("[PORTFOLIO] ERRORE: WebView non disponibile - NOTGO");
                    return false;
                }

                // STEP 5: Estrai asset e timeframe dalla RIGA 2 (prima riga dati)
                if (_righePortfolio.Count == 0)
                {
                    Debug.WriteLine("[PORTFOLIO] ERRORE: Nessuna riga disponibile - NOTGO");
                    return false;
                }

                var primaDatiRiga = _righePortfolio[0]; // Prima riga dati
                
                // Asset dalla colonna C (Trading Symbol)
                string assetSymbol = primaDatiRiga.ContainsKey("C") ? primaDatiRiga["C"] : "";
                
                // Timeframe dalla colonna T (tf)
                string timeframeTarget = primaDatiRiga.ContainsKey("T") ? primaDatiRiga["T"] : "";

                Debug.WriteLine($"[PORTFOLIO] Asset estratto (colonna C): {assetSymbol}");
                Debug.WriteLine($"[PORTFOLIO] Timeframe estratto (colonna T): {timeframeTarget}");

                // STEP 6: Esegui azioni preparazione (1 sola volta - riga 2)
                Debug.WriteLine("╔════════════════════════════════════════════════════════╗");
                Debug.WriteLine("║   AZIONI PREPARAZIONE - RIGA 2                         ║");
                Debug.WriteLine("╚════════════════════════════════════════════════════════╝");

                bool preparazioneOk = await AzioniPreparazioneManager.Esegui(webView, assetSymbol, timeframeTarget);
                if (!preparazioneOk)
                {
                    Debug.WriteLine("[PORTFOLIO] ERRORE: Azioni preparazione NOTGO");
                    return false;
                }

                // STEP 7: Cicla righe e esegui azioni produzione
                Debug.WriteLine("╔════════════════════════════════════════════════════════╗");
                Debug.WriteLine("║   AZIONI PRODUZIONE - CICLO RIGHE                      ║");
                Debug.WriteLine("╚════════════════════════════════════════════════════════╝");

                for (int i = 0; i < _righePortfolio.Count; i++)
                {
                    int numeroRiga = _startRow + i;
                    var riga = _righePortfolio[i];

                    Debug.WriteLine($"[PORTFOLIO] Elaborazione riga {numeroRiga}...");
                    Debug.WriteLine($"[PORTFOLIO] UserID: {riga.GetValueOrDefault("A", "")}");
                    Debug.WriteLine($"[PORTFOLIO] Trading Symbol: {riga.GetValueOrDefault("C", "")}");
                    Debug.WriteLine($"[PORTFOLIO] Timeframe: {riga.GetValueOrDefault("T", "")}");

                    bool produzioneOk = await AzioniProduzioneManager.Esegui(riga, numeroRiga);
                    if (!produzioneOk)
                    {
                        Debug.WriteLine($"[PORTFOLIO] ERRORE: Azioni produzione NOTGO alla riga {numeroRiga}");
                        return false;
                    }

                    Debug.WriteLine($"[PORTFOLIO] Riga {numeroRiga} completata con successo");
                }

                Debug.WriteLine("╔════════════════════════════════════════════════════════╗");
                Debug.WriteLine("║   PORTFOLIO ED ORDINE EVENTI - COMPLETATO              ║");
                Debug.WriteLine("╚════════════════════════════════════════════════════════╝");

                return true;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[PORTFOLIO] ERRORE CRITICO: {ex.Message}");
                Debug.WriteLine($"[PORTFOLIO] StackTrace: {ex.StackTrace}");
                return false;
            }
        }

        /// <summary>
        /// Ottiene WebView2 dal monitor - RICERCA PROFONDA
        /// </summary>
        private static WebView2 GetWebViewFromMonitor()
        {
            try
            {
                Debug.WriteLine("[PORTFOLIO] Inizio ricerca WebView...");
                
                // Cerca la MainWindow
                var mainWindow = System.Windows.Application.Current.MainWindow;
                if (mainWindow == null)
                {
                    Debug.WriteLine("[PORTFOLIO] MainWindow non trovata");
                    return null;
                }

                Debug.WriteLine("[PORTFOLIO] MainWindow trovata, cerco WebViewMonitor...");

                // Cerca ricorsivamente nel visual tree
                WebView2 webView = TrovaWebViewRicorsivo(mainWindow);
                
                if (webView != null)
                {
                    Debug.WriteLine("[PORTFOLIO] WebView trovato con successo!");
                    return webView;
                }

                Debug.WriteLine("[PORTFOLIO] WebView non trovato dopo ricerca completa");
                return null;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[PORTFOLIO] ERRORE recupero WebView: {ex.Message}");
                return null;
            }
        }

        /// <summary>
        /// Cerca WebView2 ricorsivamente nel visual tree
        /// </summary>
        private static WebView2 TrovaWebViewRicorsivo(System.Windows.DependencyObject parent)
        {
            if (parent == null) return null;

            // Se è già un WebView2, ritornalo
            if (parent is WebView2 webView)
            {
                Debug.WriteLine("[PORTFOLIO] WebView2 trovato direttamente!");
                return webView;
            }

            int childCount = System.Windows.Media.VisualTreeHelper.GetChildrenCount(parent);
            Debug.WriteLine($"[PORTFOLIO] Controllo {childCount} figli di {parent.GetType().Name}");

            for (int i = 0; i < childCount; i++)
            {
                var child = System.Windows.Media.VisualTreeHelper.GetChild(parent, i);

                // Controllo se è il WebViewMonitor per nome
                if (child is System.Windows.FrameworkElement element)
                {
                    Debug.WriteLine($"[PORTFOLIO] Trovato elemento: {element.GetType().Name}, Name: {element.Name}");
                    
                    // Se è il controllo _01_webviewmonitor
                    if (child.GetType().Name == "_01_webviewmonitor")
                    {
                        Debug.WriteLine("[PORTFOLIO] Trovato _01_webviewmonitor!");
                        
                        // Cerca il WebView2 al suo interno
                        var webViewInterno = TrovaWebViewRicorsivo(child);
                        if (webViewInterno != null)
                            return webViewInterno;
                    }
                }

                // Ricerca ricorsiva
                var risultato = TrovaWebViewRicorsivo(child);
                if (risultato != null)
                {
                    return risultato;
                }
            }

            return null;
        }

        /// <summary>
        /// Trova controllo per nome nel visual tree
        /// </summary>
        private static T TrovaControlloPerNome<T>(System.Windows.DependencyObject parent, string nome) where T : System.Windows.FrameworkElement
        {
            if (parent == null) return null;

            int childCount = System.Windows.Media.VisualTreeHelper.GetChildrenCount(parent);
            
            for (int i = 0; i < childCount; i++)
            {
                var child = System.Windows.Media.VisualTreeHelper.GetChild(parent, i);

                if (child is T elemento && (string.IsNullOrEmpty(nome) || elemento.Name == nome))
                {
                    return elemento;
                }

                var risultato = TrovaControlloPerNome<T>(child, nome);
                if (risultato != null)
                {
                    return risultato;
                }
            }

            return null;
        }

        private static bool LeggiConfigurazione()
        {
            try
            {
                string txtPath = @"C:\00_CapitalproCEOmanagement\01_dipartimentooperativo\01_Capitalproapp\01_appsingole\03_Alert Automator\txtdilavoro.txt";
                
                Debug.WriteLine($"[PORTFOLIO] Lettura configurazione: {txtPath}");

                if (!File.Exists(txtPath))
                {
                    Debug.WriteLine("[PORTFOLIO] ERRORE: File txt non trovato");
                    return false;
                }

                string[] lines = File.ReadAllLines(txtPath);
                string linkPortfolio = null;

                foreach (string line in lines)
                {
                    if (line.Trim().StartsWith("linkportfolio:", StringComparison.OrdinalIgnoreCase))
                    {
                        linkPortfolio = line.Substring(line.IndexOf(':') + 1).Trim();
                        Debug.WriteLine($"[PORTFOLIO] Link trovato: {linkPortfolio}");
                        break;
                    }
                }

                if (string.IsNullOrEmpty(linkPortfolio))
                {
                    Debug.WriteLine("[PORTFOLIO] ERRORE: Link portfolio non trovato");
                    return false;
                }

                _spreadsheetId = EstraiSpreadsheetId(linkPortfolio);
                Debug.WriteLine($"[PORTFOLIO] Spreadsheet ID: {_spreadsheetId}");

                return true;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[PORTFOLIO] ERRORE lettura configurazione: {ex.Message}");
                return false;
            }
        }

        private static string EstraiSpreadsheetId(string url)
        {
            try
            {
                if (url.Contains("/spreadsheets/d/"))
                {
                    int startIndex = url.IndexOf("/spreadsheets/d/") + "/spreadsheets/d/".Length;
                    int endIndex = url.IndexOf("/", startIndex);
                    
                    return endIndex > startIndex 
                        ? url.Substring(startIndex, endIndex - startIndex)
                        : url.Substring(startIndex);
                }
                return null;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[PORTFOLIO] ERRORE estrazione ID: {ex.Message}");
                return null;
            }
        }

        private static async Task<bool> InizializzaGoogleSheets()
        {
            try
            {
                string credentialsPath = @"C:\00_CapitalproCEOmanagement\01_dipartimentooperativo\01_Capitalproapp\01_appsingole\03_Alert Automator\capitaljournal-6a007d9b9bd1.json";
                
                Debug.WriteLine($"[PORTFOLIO] Inizializzazione Google Sheets...");

                if (!File.Exists(credentialsPath))
                {
                    Debug.WriteLine("[PORTFOLIO] ERRORE: File credentials non trovato");
                    return false;
                }

                var credential = GoogleCredential.FromFile(credentialsPath)
                    .CreateScoped(SheetsService.Scope.SpreadsheetsReadonly);

                _sheetsService = new SheetsService(new BaseClientService.Initializer
                {
                    HttpClientInitializer = credential,
                    ApplicationName = "Alert Automator"
                });

                Debug.WriteLine("[PORTFOLIO] Google Sheets Service inizializzato");
                return true;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[PORTFOLIO] ERRORE inizializzazione: {ex.Message}");
                return false;
            }
        }

        private static async Task<bool> LeggiRighePortfolio()
        {
            try
            {
                _tabSelezionata = GetTabSelezionata();
                _startRow = GetStartRow();
                _stopRow = GetStopRow();

                Debug.WriteLine($"[PORTFOLIO] Tab: {_tabSelezionata}");
                Debug.WriteLine($"[PORTFOLIO] Start Row: {_startRow}");
                Debug.WriteLine($"[PORTFOLIO] Stop Row: {_stopRow}");

                // Range fino alla colonna AO per coprire tutte le colonne necessarie
                string range = $"{_tabSelezionata}!A{_startRow}:AO{_stopRow}";
                var request = _sheetsService.Spreadsheets.Values.Get(_spreadsheetId, range);
                var response = await request.ExecuteAsync();

                if (response?.Values == null || response.Values.Count == 0)
                {
                    Debug.WriteLine("[PORTFOLIO] ERRORE: Nessuna riga trovata");
                    return false;
                }

                _righePortfolio = new List<Dictionary<string, string>>();

                foreach (var row in response.Values)
                {
                    var rigaDict = new Dictionary<string, string>();
                    
                    for (int i = 0; i < row.Count; i++)
                    {
                        string colonnaLettera = GetColumnLetter(i);
                        rigaDict[colonnaLettera] = row[i]?.ToString() ?? "";
                    }

                    _righePortfolio.Add(rigaDict);
                }

                Debug.WriteLine($"[PORTFOLIO] Righe caricate: {_righePortfolio.Count}");
                return true;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[PORTFOLIO] ERRORE lettura righe: {ex.Message}");
                return false;
            }
        }

        private static string GetColumnLetter(int index)
        {
            string result = "";
            while (index >= 0)
            {
                result = (char)('A' + (index % 26)) + result;
                index = (index / 26) - 1;
            }
            return result;
        }

        private static string GetTabSelezionata()
        {
            var mainWindow = System.Windows.Application.Current.MainWindow;
            if (mainWindow == null)
            {
                Debug.WriteLine("[PORTFOLIO] ERRORE: MainWindow non trovata - NOTGO");
                return null;
            }

            // Trova il menu tendina select tab
            var selectTabControl = TrovaControlloPerTipo<_01_latografico._01_livello1._02_startproductionmenu._01_selecttab._02_menutendinaselecttab>(mainWindow);
            
            if (selectTabControl == null)
            {
                Debug.WriteLine("[PORTFOLIO] ERRORE: Menu tendina tab non trovato - NOTGO");
                return null;
            }

            string tab = selectTabControl.GetTabSelezionata();
            if (string.IsNullOrEmpty(tab))
            {
                Debug.WriteLine("[PORTFOLIO] ERRORE: Nessun tab selezionato - NOTGO");
                return null;
            }

            Debug.WriteLine($"[PORTFOLIO] Tab letta dalla UI: {tab}");
            return tab;
        }

        private static int GetStartRow()
        {
            var mainWindow = System.Windows.Application.Current.MainWindow;
            if (mainWindow == null)
            {
                Debug.WriteLine("[PORTFOLIO] ERRORE: MainWindow non trovata - NOTGO");
                return -1;
            }

            // Trova il menu tendina start row
            var startRowControl = TrovaControlloPerTipo<_01_latografico._01_livello1._02_startproductionmenu._02_selectstartrow._01_menutendinaStartR>(mainWindow);
            
            if (startRowControl == null)
            {
                Debug.WriteLine("[PORTFOLIO] ERRORE: Menu tendina start row non trovato - NOTGO");
                return -1;
            }

            int row = startRowControl.GetStartRow();
            Debug.WriteLine($"[PORTFOLIO] Start row letta dalla UI: {row}");
            return row;
        }

        private static int GetStopRow()
        {
            var mainWindow = System.Windows.Application.Current.MainWindow;
            if (mainWindow == null)
            {
                Debug.WriteLine("[PORTFOLIO] ERRORE: MainWindow non trovata - NOTGO");
                return -1;
            }

            // Trova il menu tendina stop row
            var stopRowControl = TrovaControlloPerTipo<_01_latografico._01_livello1._02_startproductionmenu._03_selectstoprow._01_menutendinaStopR>(mainWindow);
            
            if (stopRowControl == null)
            {
                Debug.WriteLine("[PORTFOLIO] ERRORE: Menu tendina stop row non trovato - NOTGO");
                return -1;
            }

            int row = stopRowControl.GetStopRow();
            Debug.WriteLine($"[PORTFOLIO] Stop row letta dalla UI: {row}");
            return row;
        }

        /// <summary>
        /// Trova controllo per tipo nel visual tree
        /// </summary>
        private static T TrovaControlloPerTipo<T>(System.Windows.DependencyObject parent) where T : class
        {
            if (parent == null) return null;

            int childCount = System.Windows.Media.VisualTreeHelper.GetChildrenCount(parent);
            
            for (int i = 0; i < childCount; i++)
            {
                var child = System.Windows.Media.VisualTreeHelper.GetChild(parent, i);

                if (child is T risultato)
                {
                    return risultato;
                }

                var trovatoNelChild = TrovaControlloPerTipo<T>(child);
                if (trovatoNelChild != null)
                {
                    return trovatoNelChild;
                }
            }

            return null;
        }

        public static List<Dictionary<string, string>> GetRighePortfolio()
        {
            return _righePortfolio;
        }

        public static SheetsService GetSheetsService()
        {
            return _sheetsService;
        }
    }
}
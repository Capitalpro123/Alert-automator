using System;using System.Diagnostics;
using System.Diagnostics;
using System.Threading.Tasks;

namespace AlertAutomator._02_LatoFunzioni._02_EngineAutomation
{
    /// <summary>
    /// Riceve il click dal bottone START RACE nella UI
    /// Responsabilità: ricevere evento e chiamare PortfolioEdOrdineEventi
    /// </summary>
    public class RiceviClickDaUI
    {
        /// <summary>
        /// Gestisce il click dal bottone START RACE
        /// </summary>
        public static async Task<bool> Esegui()
        {
            try
            {
                Debug.WriteLine("╔════════════════════════════════════════════════════════╗");
                Debug.WriteLine("║   CLICK START RACE RICEVUTO                            ║");
                Debug.WriteLine("╚════════════════════════════════════════════════════════╝");

                // Chiama gestore portfolio e ordine eventi
                bool successo = await PortfolioEdOrdineEventi.Esegui();

                if (successo)
                {
                    Debug.WriteLine("[RICEVI CLICK] Automazione completata con successo");
                    return true;
                }
                else
                {
                    Debug.WriteLine("[RICEVI CLICK] Automazione fallita");
                    return false;
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[RICEVI CLICK] ERRORE: {ex.Message}");
                Debug.WriteLine($"[RICEVI CLICK] StackTrace: {ex.StackTrace}");
                return false;
            }
        }
    }
}
using System;using System.Diagnostics;
using System.Diagnostics;
using System.Windows.Controls;
using AlertAutomator._01_latografico._02_livello2._01_webviewmonitor;
using AlertAutomator._01_latografico._02_livello2._02_arealog;

namespace AlertAutomator._01_latografico._02_livello2
{
    public partial class _00_livello2manager : UserControl
    {
        public _00_livello2manager()
        {
            InitializeComponent();

            Debug.WriteLine("╔════════════════════════════════════════════════════════╗");
            Debug.WriteLine("║   LIVELLO 2 MANAGER - INIZIALIZZAZIONE                 ║");
            Debug.WriteLine("╚════════════════════════════════════════════════════════╝");

            CaricaComponenti();
        }

        private void CaricaComponenti()
        {
            try
            {
                Debug.WriteLine("╔════════════════════════════════════════════════════════╗");
                Debug.WriteLine("║   CHIAMO: 00_webviewmonitormanager                     ║");
                Debug.WriteLine("╚════════════════════════════════════════════════════════╝");

                WebViewMonitorContainer.Content = new _00_webviewmonitormanager();
                Debug.WriteLine("[LIVELLO 2] WebView Monitor caricato");

                Debug.WriteLine("╔════════════════════════════════════════════════════════╗");
                Debug.WriteLine("║   CHIAMO: 00_arealogmanager                            ║");
                Debug.WriteLine("╚════════════════════════════════════════════════════════╝");

                AreaLogContainer.Content = new _00_arealogmanager();
                Debug.WriteLine("[LIVELLO 2] Area Log caricata");

                Debug.WriteLine("[LIVELLO 2 MANAGER] Tutti i componenti caricati");
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[LIVELLO 2 MANAGER] ERRORE: {ex.Message}");
            }
        }
    }
}
using System;using System.Diagnostics;
using System.Diagnostics;
using System.Windows.Controls;
using AlertAutomator._01_latografico._02_livello2._01_webviewmonitor;

namespace AlertAutomator._01_latografico._02_livello2._01_webviewmonitor
{
    public partial class _00_webviewmonitormanager : UserControl
    {
        public _00_webviewmonitormanager()
        {
            InitializeComponent();

            Debug.WriteLine("╔════════════════════════════════════════════════════════╗");
            Debug.WriteLine("║   WEBVIEW MONITOR MANAGER - INIZIALIZZAZIONE           ║");
            Debug.WriteLine("╚════════════════════════════════════════════════════════╝");

            CaricaWebView();
        }

        private void CaricaWebView()
        {
            try
            {
                Debug.WriteLine("╔════════════════════════════════════════════════════════╗");
                Debug.WriteLine("║   CHIAMO: 01_webviewmonitor                            ║");
                Debug.WriteLine("╚════════════════════════════════════════════════════════╝");

                WebViewContainer.Content = new _01_webviewmonitor();
                Debug.WriteLine("[WEBVIEW MONITOR MANAGER] WebView caricato");
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[WEBVIEW MONITOR MANAGER] ERRORE: {ex.Message}");
            }
        }
    }
}
// 01_webviewmonitor.xaml.cs
using System;using System.Diagnostics;
using System.Diagnostics;
using System.IO;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.Wpf;

namespace AlertAutomator._01_latografico._02_livello2._01_webviewmonitor
{
    public partial class _01_webviewmonitor : UserControl
    {
        private bool _isInitialized = false;
        private bool _isNavigating = false;
        private string _currentUrl = "https://www.tradingview.com";
        private string _chartId = "";
        private string _sessionId = "";

        public _01_webviewmonitor()
        {
            InitializeComponent();

            Debug.WriteLine("╔════════════════════════════════════════════════════════╗");
            Debug.WriteLine("║   WEBVIEW MONITOR - INIZIALIZZAZIONE                   ║");
            Debug.WriteLine("╚════════════════════════════════════════════════════════╝");

            this.Loaded += WebViewMonitor_Loaded;
        }

        private async void WebViewMonitor_Loaded(object sender, RoutedEventArgs e)
        {
            await InizializzaWebView();
        }

        private async Task InizializzaWebView()
        {
            try
            {
                MostraLoading(true);

                CaricaConfigurazione();

                if (!IsConfigurazioneValida())
                {
                    Debug.WriteLine("[WEBVIEW MONITOR] ERRORE: Configurazione non valida! Verificare ChartID e SessionID");
                    return;
                }

                await WebView.EnsureCoreWebView2Async();

                _isInitialized = true;

                ConfiguraEventiWebView();

                await ConfiguraENaviga();
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[WEBVIEW MONITOR] ERRORE inizializzazione browser: {ex.Message}");
            }
        }

        private void CaricaConfigurazione()
        {
            try
            {
                string configPath = @"C:\00_CapitalproCEOmanagement\01_dipartimentooperativo\01_Capitalproapp\01_appsingole\03_Alert Automator\txtdilavoro.txt";

                Debug.WriteLine($"[WEBVIEW MONITOR] Caricamento configurazione da: {configPath}");

                if (File.Exists(configPath))
                {
                    string[] lines = File.ReadAllLines(configPath);

                    foreach (string line in lines)
                    {
                        if (line.StartsWith("chartid:"))
                        {
                            _chartId = line.Substring(8).Trim();
                            Debug.WriteLine($"[WEBVIEW MONITOR] ChartID trovato: {_chartId}");
                        }
                        else if (line.StartsWith("sessionid:"))
                        {
                            _sessionId = line.Substring(10).Trim();
                            Debug.WriteLine($"[WEBVIEW MONITOR] SessionID trovato: {_sessionId}");
                        }
                    }
                }
                else
                {
                    Debug.WriteLine("[WEBVIEW MONITOR] ATTENZIONE: File configurazione non trovato!");
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[WEBVIEW MONITOR] ERRORE lettura configurazione: {ex.Message}");
            }
        }

        private bool IsConfigurazioneValida()
        {
            if (string.IsNullOrEmpty(_chartId))
            {
                Debug.WriteLine("[WEBVIEW MONITOR] ChartID mancante!");
                return false;
            }

            if (string.IsNullOrEmpty(_sessionId))
            {
                Debug.WriteLine("[WEBVIEW MONITOR] SessionID mancante!");
                return false;
            }

            return true;
        }

        private async Task ConfiguraENaviga()
        {
            try
            {
                string tradingViewUrl = $"https://www.tradingview.com/chart/{_chartId}/";
                _currentUrl = tradingViewUrl;

                Debug.WriteLine($"[WEBVIEW MONITOR] URL target: {tradingViewUrl}");

                CoreWebView2Cookie cookie = WebView.CoreWebView2.CookieManager.CreateCookie(
                    "sessionid",
                    _sessionId,
                    ".tradingview.com",
                    "/"
                );

                WebView.CoreWebView2.CookieManager.AddOrUpdateCookie(cookie);

                WebView.CoreWebView2.Navigate(tradingViewUrl);
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[WEBVIEW MONITOR] ERRORE configurazione browser: {ex.Message}");
                throw;
            }
        }

        private void ConfiguraEventiWebView()
        {
            WebView.CoreWebView2.DocumentTitleChanged += CoreWebView2_DocumentTitleChanged;
            WebView.CoreWebView2.NewWindowRequested += CoreWebView2_NewWindowRequested;
        }

        private void WebView_NavigationStarting(object sender, CoreWebView2NavigationStartingEventArgs e)
        {
            _isNavigating = true;
            MostraLoading(true);
        }

        private void WebView_NavigationCompleted(object sender, CoreWebView2NavigationCompletedEventArgs e)
        {
            _isNavigating = false;
            MostraLoading(false);

            if (e.IsSuccess)
            {
                _currentUrl = WebView.CoreWebView2.Source;
                Debug.WriteLine($"[WEBVIEW MONITOR] Navigazione completata: {_currentUrl}");
            }
            else
            {
                Debug.WriteLine($"[WEBVIEW MONITOR] Errore navigazione: {e.WebErrorStatus}");
            }
        }

        private void WebView_CoreWebView2InitializationCompleted(object sender, CoreWebView2InitializationCompletedEventArgs e)
        {
            if (!e.IsSuccess)
            {
                Debug.WriteLine($"[WEBVIEW MONITOR] Errore inizializzazione WebView2: {e.InitializationException?.Message}");
            }
        }

        private void CoreWebView2_DocumentTitleChanged(object sender, object e)
        {
            if (WebView?.CoreWebView2 != null)
            {
                string title = WebView.CoreWebView2.DocumentTitle;
            }
        }

        private void CoreWebView2_NewWindowRequested(object sender, CoreWebView2NewWindowRequestedEventArgs e)
        {
            e.Handled = true;
            WebView.CoreWebView2.Navigate(e.Uri);
            Debug.WriteLine($"[WEBVIEW MONITOR] Popup bloccato, navigazione a: {e.Uri}");
        }

        private void MostraLoading(bool show)
        {
            if (LoadingProgress != null)
            {
                LoadingProgress.Visibility = show ? Visibility.Visible : Visibility.Collapsed;
            }
        }

        public WebView2 GetWebView()
        {
            return WebView;
        }

        public void NavigateTo(string url)
        {
            if (_isInitialized && WebView != null)
            {
                WebView.CoreWebView2.Navigate(url);
                _currentUrl = url;
            }
        }

        public void GoBack()
        {
            if (_isInitialized && WebView != null && WebView.CanGoBack)
            {
                WebView.GoBack();
            }
        }

        public void GoForward()
        {
            if (_isInitialized && WebView != null && WebView.CanGoForward)
            {
                WebView.GoForward();
            }
        }

        public void Refresh()
        {
            if (_isInitialized && WebView != null)
            {
                WebView.Reload();
            }
        }

        public async Task<string> ExecuteScriptAsync(string script)
        {
            if (_isInitialized && WebView != null)
            {
                return await WebView.ExecuteScriptAsync(script);
            }

            return null;
        }

        public string GetCurrentUrl()
        {
            return _currentUrl;
        }

        public bool IsNavigating()
        {
            return _isNavigating;
        }
    }
}
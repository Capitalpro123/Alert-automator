// 00_arealogmanager.xaml.cs
using System;using System.Diagnostics;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;

namespace AlertAutomator._01_latografico._02_livello2._02_arealog
{
    public partial class _00_arealogmanager : UserControl
    {
        private _01_arealog _areaLog;

        public _00_arealogmanager()
        {
            InitializeComponent();

            Debug.WriteLine("╔════════════════════════════════════════════════════════╗");
            Debug.WriteLine("║   AREA LOG MANAGER - INIZIALIZZAZIONE                  ║");
            Debug.WriteLine("╚════════════════════════════════════════════════════════╝");

            CaricaAreaLog();
        }

        private void CaricaAreaLog()
        {
            try
            {
                Debug.WriteLine("╔════════════════════════════════════════════════════════╗");
                Debug.WriteLine("║   CHIAMO: 01_arealog                                   ║");
                Debug.WriteLine("╚════════════════════════════════════════════════════════╝");

                _areaLog = new _01_arealog();
                ContainerAreaLog.Content = _areaLog;
                Debug.WriteLine("[AREA LOG MANAGER] Area Log caricata");
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[AREA LOG MANAGER] ERRORE: {ex.Message}");
            }
        }

        private void BtnCopy_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Debug.WriteLine("╔════════════════════════════════════════════════════════╗");
                Debug.WriteLine("║   COPY LOG - CLICK RILEVATO                            ║");
                Debug.WriteLine("╚════════════════════════════════════════════════════════╝");

                if (_areaLog != null)
                {
                    string logText = _areaLog.GetAllLogText();
                    Clipboard.SetText(logText);
                    Debug.WriteLine("[AREA LOG MANAGER] Log copiato negli appunti");
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[AREA LOG MANAGER] ERRORE copia: {ex.Message}");
            }
        }
    }
}
// 01_arealog.xaml.cs
using System;using System.Diagnostics;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Media;

namespace AlertAutomator._01_latografico._02_livello2._02_arealog
{
    public partial class _01_arealog : UserControl
    {
        private const int MAX_LOG_LINES = 175;
        private static _01_arealog _instance;

        public _01_arealog()
        {
            InitializeComponent();

            _instance = this;

            Debug.WriteLine("╔════════════════════════════════════════════════════════╗");
            Debug.WriteLine("║   AREA LOG - INIZIALIZZAZIONE                          ║");
            Debug.WriteLine("╚════════════════════════════════════════════════════════╝");

            AttivaTraceListener();
        }

        private void AttivaTraceListener()
        {
            try
            {
                Trace.Listeners.Clear();
                var customListener = new CustomTraceListener(this);
                Trace.Listeners.Add(customListener);

                Debug.WriteLine("[AREA LOG] TraceListener attivato");
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[AREA LOG] ERRORE attivazione TraceListener: {ex.Message}");
            }
        }

        public void AggiungiLog(string messaggio, string colore = "verde")
        {
            if (Dispatcher.CheckAccess())
            {
                AggiungiLogInterno(messaggio, colore);
            }
            else
            {
                Dispatcher.Invoke(() => AggiungiLogInterno(messaggio, colore));
            }
        }

        private void AggiungiLogInterno(string messaggio, string colore)
        {
            try
            {
                var paragraph = new Paragraph();
                var run = new Run($"[{DateTime.Now:HH:mm:ss}] {messaggio}");

                switch (colore.ToLower())
                {
                    case "verde":
                        run.Foreground = new SolidColorBrush(Color.FromRgb(0, 255, 0));
                        break;
                    case "giallo":
                        run.Foreground = new SolidColorBrush(Color.FromRgb(255, 255, 0));
                        break;
                    case "rosso":
                        run.Foreground = new SolidColorBrush(Color.FromRgb(255, 68, 68));
                        break;
                    case "ciano":
                        run.Foreground = new SolidColorBrush(Color.FromRgb(0, 217, 255));
                        break;
                    default:
                        run.Foreground = new SolidColorBrush(Color.FromRgb(136, 136, 136));
                        break;
                }

                paragraph.Inlines.Add(run);
                paragraph.Margin = new Thickness(0, 0, 0, 2);

                RichTextBoxLog.Document.Blocks.Add(paragraph);

                // Mantieni solo gli ultimi 75 log
                while (RichTextBoxLog.Document.Blocks.Count > MAX_LOG_LINES)
                {
                    RichTextBoxLog.Document.Blocks.Remove(RichTextBoxLog.Document.Blocks.FirstBlock);
                }

                ScrollViewerLog.ScrollToEnd();
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[AREA LOG] ERRORE: {ex.Message}");
            }
        }

        public string GetAllLogText()
        {
            try
            {
                var sb = new StringBuilder();
                foreach (var block in RichTextBoxLog.Document.Blocks.OfType<Paragraph>())
                {
                    sb.AppendLine(new TextRange(block.ContentStart, block.ContentEnd).Text);
                }
                return sb.ToString();
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[AREA LOG] ERRORE GetAllLogText: {ex.Message}");
                return string.Empty;
            }
        }

        public static _01_arealog GetInstance()
        {
            return _instance;
        }
    }

    public class CustomTraceListener : TraceListener
    {
        private readonly _01_arealog _areaLog;

        public CustomTraceListener(_01_arealog areaLog)
        {
            _areaLog = areaLog;
        }

        public override void Write(string message)
        {
        }

        public override void WriteLine(string message)
        {
            try
            {
                if (_areaLog != null && !string.IsNullOrEmpty(message))
                {
                    string colore = "verde";

                    if (message.Contains("ERRORE") || message.Contains("ERROR") || message.Contains("✗"))
                    {
                        colore = "rosso";
                    }
                    else if (message.Contains("WARNING") || message.Contains("ATTENZIONE"))
                    {
                        colore = "giallo";
                    }
                    else if (message.Contains("CHIAMO:") || message.Contains("║"))
                    {
                        colore = "ciano";
                    }

                    _areaLog.AggiungiLog(message, colore);
                }
            }
            catch
            {
            }
        }
    }
}
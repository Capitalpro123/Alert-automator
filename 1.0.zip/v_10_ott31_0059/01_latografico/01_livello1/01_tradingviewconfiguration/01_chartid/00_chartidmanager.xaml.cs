using System;using System.Diagnostics;
using System.Diagnostics;
using System.Windows.Controls;
using AlertAutomator._01_latografico._01_livello1._01_tradingviewconfigurationman._01_chartid;

namespace AlertAutomator._01_latografico._01_livello1._01_tradingviewconfigurationman._01_chartid
{
    public partial class _00_chartidmanager : UserControl
    {
        public _00_chartidmanager()
        {
            InitializeComponent();

            Debug.WriteLine("╔════════════════════════════════════════════════════════╗");
            Debug.WriteLine("║   CHART ID MANAGER - INIZIALIZZAZIONE                  ║");
            Debug.WriteLine("╚════════════════════════════════════════════════════════╝");

            CaricaInput();
        }

        private void CaricaInput()
        {
            try
            {
                Debug.WriteLine("╔════════════════════════════════════════════════════════╗");
                Debug.WriteLine("║   CHIAMO: 01_inputchartid                              ║");
                Debug.WriteLine("╚════════════════════════════════════════════════════════╝");

                InputChartIdContainer.Content = new _01_inputchartid();
                Debug.WriteLine("[CHART ID MANAGER] Input Chart ID caricato");
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[CHART ID MANAGER] ERRORE: {ex.Message}");
            }
        }
    }
}
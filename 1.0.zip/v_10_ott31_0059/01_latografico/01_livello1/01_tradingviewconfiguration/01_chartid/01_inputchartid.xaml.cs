using System;using System.Diagnostics;
using System.Diagnostics;
using System.IO;
using System.Windows;
using System.Windows.Controls;

namespace AlertAutomator._01_latografico._01_livello1._01_tradingviewconfigurationman._01_chartid
{
    public partial class _01_inputchartid : UserControl
    {
        private const string TXT_PATH = @"C:\00_CapitalproCEOmanagement\01_dipartimentooperativo\01_Capitalproapp\01_appsingole\03_Alert Automator\txtdilavoro.txt";

        public _01_inputchartid()
        {
            InitializeComponent();

            Debug.WriteLine("╔════════════════════════════════════════════════════════╗");
            Debug.WriteLine("║   INPUT CHART ID - INIZIALIZZAZIONE                    ║");
            Debug.WriteLine("╚════════════════════════════════════════════════════════╝");

            CaricaChartIdDaTxt();
        }

        private void CaricaChartIdDaTxt()
        {
            try
            {
                Debug.WriteLine($"[INPUT CHART ID] Lettura file: {TXT_PATH}");

                if (!File.Exists(TXT_PATH))
                {
                    Debug.WriteLine("[INPUT CHART ID] File txtdilavoro.txt non trovato");
                    return;
                }

                string[] lines = File.ReadAllLines(TXT_PATH);

                foreach (string line in lines)
                {
                    if (line.Trim().StartsWith("chartid:", StringComparison.OrdinalIgnoreCase))
                    {
                        string chartId = line.Substring(line.IndexOf(':') + 1).Trim();
                        ChartIdTextBox.Text = chartId;
                        Debug.WriteLine($"[INPUT CHART ID] Chart ID caricato: {chartId}");
                        return;
                    }
                }

                Debug.WriteLine("[INPUT CHART ID] Chart ID non trovato nel file");
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[INPUT CHART ID] ERRORE lettura file: {ex.Message}");
            }
        }

        private void ClearButton_Click(object sender, RoutedEventArgs e)
        {
            Debug.WriteLine("╔════════════════════════════════════════════════════════╗");
            Debug.WriteLine("║   CLEAR BUTTON - CLICK RILEVATO                        ║");
            Debug.WriteLine("╚════════════════════════════════════════════════════════╝");

            ChartIdTextBox.Text = string.Empty;
            Debug.WriteLine("[INPUT CHART ID] Chart ID cancellato");
        }

        public string GetChartId()
        {
            string chartId = ChartIdTextBox.Text.Trim();
            Debug.WriteLine($"[INPUT CHART ID] Chart ID richiesto: {chartId}");
            return chartId;
        }
    }
}
// 01_linkinput.xaml.cs
using System;using System.Diagnostics;
using System.Diagnostics;
using System.IO;
using System.Windows;
using System.Windows.Controls;

namespace AlertAutomator._01_latografico._01_livello1._01_tradingviewconfigurationman._03_portfoliolink
{
    public partial class _01_linkinput : UserControl
    {
        private const string TXT_PATH = @"C:\00_CapitalproCEOmanagement\01_dipartimentooperativo\01_Capitalproapp\01_appsingole\03_Alert Automator\txtdilavoro.txt";

        public _01_linkinput()
        {
            InitializeComponent();
            Loaded += (s, e) => CaricaLinkDaTxt();
        }

        private void CaricaLinkDaTxt()
        {
            try
            {
                Debug.WriteLine($"[LINK INPUT] Lettura file: {TXT_PATH}");

                if (!File.Exists(TXT_PATH))
                {
                    Debug.WriteLine("[LINK INPUT] ERRORE: File non trovato");
                    PortfolioLinkTextBox.Text = "File not found";
                    return;
                }

                string[] lines = File.ReadAllLines(TXT_PATH);

                foreach (string line in lines)
                {
                    if (line.Trim().StartsWith("linkportfolio:", StringComparison.OrdinalIgnoreCase))
                    {
                        string link = line.Substring(line.IndexOf(':') + 1).Trim();
                        PortfolioLinkTextBox.Text = link;
                        Debug.WriteLine($"[LINK INPUT] Link portfolio caricato: {link}");
                        return;
                    }
                }

                Debug.WriteLine("[LINK INPUT] ERRORE: Link portfolio non trovato nel file");
                PortfolioLinkTextBox.Text = "Link not found in file";
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[LINK INPUT] ERRORE lettura file: {ex.Message}");
                PortfolioLinkTextBox.Text = "Error loading link";
            }
        }

        private void ClearButton_Click(object sender, RoutedEventArgs e)
        {
            Debug.WriteLine("╔════════════════════════════════════════════════════════╗");
            Debug.WriteLine("║   CLEAR BUTTON - CLICK RILEVATO                        ║");
            Debug.WriteLine("╚════════════════════════════════════════════════════════╝");

            PortfolioLinkTextBox.Text = string.Empty;
            Debug.WriteLine("[LINK INPUT] Portfolio link cancellato");
        }

        public string GetPortfolioLink()
        {
            string link = PortfolioLinkTextBox.Text.Trim();
            Debug.WriteLine($"[LINK INPUT] Portfolio link richiesto: {link}");
            return link;
        }
    }
}
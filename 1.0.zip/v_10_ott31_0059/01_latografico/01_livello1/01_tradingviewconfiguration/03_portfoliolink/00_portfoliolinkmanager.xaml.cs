using System;using System.Diagnostics;
using System.Diagnostics;
using System.Windows.Controls;

namespace AlertAutomator._01_latografico._01_livello1._01_tradingviewconfigurationman._03_portfoliolink
{
    public partial class _00_portfoliolinkmanager : UserControl
    {
        private _01_linkinput _linkInput;

        public _00_portfoliolinkmanager()
        {
            InitializeComponent();

            Debug.WriteLine("╔════════════════════════════════════════════════════════╗");
            Debug.WriteLine("║   PORTFOLIO LINK MANAGER - INIZIALIZZAZIONE            ║");
            Debug.WriteLine("╚════════════════════════════════════════════════════════╝");

            CaricaInput();
        }

        private void CaricaInput()
        {
            try
            {
                Debug.WriteLine("╔════════════════════════════════════════════════════════╗");
                Debug.WriteLine("║   CHIAMO: 01_linkinput                                 ║");
                Debug.WriteLine("╚════════════════════════════════════════════════════════╝");

                _linkInput = new _01_linkinput();
                LinkInputContainer.Content = _linkInput;
                Debug.WriteLine("[PORTFOLIO LINK MANAGER] Link Input caricato");
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[PORTFOLIO LINK MANAGER] ERRORE: {ex.Message}");
            }
        }

        public _01_linkinput GetLinkInput()
        {
            return _linkInput;
        }
    }
}
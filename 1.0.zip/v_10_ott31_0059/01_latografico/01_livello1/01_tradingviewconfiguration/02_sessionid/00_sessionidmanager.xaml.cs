using System;using System.Diagnostics;
using System.Diagnostics;
using System.Windows.Controls;
using AlertAutomator._01_latografico._01_livello1._01_tradingviewconfigurationman._02_sessionid;

namespace AlertAutomator._01_latografico._01_livello1._01_tradingviewconfigurationman._02_sessionid
{
    public partial class _00_sessionidmanager : UserControl
    {
        public _00_sessionidmanager()
        {
            InitializeComponent();

            Debug.WriteLine("╔════════════════════════════════════════════════════════╗");
            Debug.WriteLine("║   SESSION ID MANAGER - INIZIALIZZAZIONE                ║");
            Debug.WriteLine("╚════════════════════════════════════════════════════════╝");

            CaricaInput();
        }

        private void CaricaInput()
        {
            try
            {
                Debug.WriteLine("╔════════════════════════════════════════════════════════╗");
                Debug.WriteLine("║   CHIAMO: 01_inputsessionid                            ║");
                Debug.WriteLine("╚════════════════════════════════════════════════════════╝");

                InputSessionIdContainer.Content = new _01_inputsessionid();
                Debug.WriteLine("[SESSION ID MANAGER] Input Session ID caricato");
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[SESSION ID MANAGER] ERRORE: {ex.Message}");
            }
        }
    }
}
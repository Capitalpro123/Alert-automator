using System;using System.Diagnostics;
using System.Diagnostics;
using System.IO;
using System.Windows;
using System.Windows.Controls;

namespace AlertAutomator._01_latografico._01_livello1._01_tradingviewconfigurationman._02_sessionid
{
    public partial class _01_inputsessionid : UserControl
    {
        private const string TXT_PATH = @"C:\00_CapitalproCEOmanagement\01_dipartimentooperativo\01_Capitalproapp\01_appsingole\03_Alert Automator\txtdilavoro.txt";

        public _01_inputsessionid()
        {
            InitializeComponent();

            Debug.WriteLine("╔════════════════════════════════════════════════════════╗");
            Debug.WriteLine("║   INPUT SESSION ID - INIZIALIZZAZIONE                  ║");
            Debug.WriteLine("╚════════════════════════════════════════════════════════╝");

            CaricaSessionIdDaTxt();
        }

        private void CaricaSessionIdDaTxt()
        {
            try
            {
                Debug.WriteLine($"[INPUT SESSION ID] Lettura file: {TXT_PATH}");

                if (!File.Exists(TXT_PATH))
                {
                    Debug.WriteLine("[INPUT SESSION ID] File txtdilavoro.txt non trovato");
                    return;
                }

                string[] lines = File.ReadAllLines(TXT_PATH);

                foreach (string line in lines)
                {
                    if (line.Trim().StartsWith("sessionid:", StringComparison.OrdinalIgnoreCase))
                    {
                        string sessionId = line.Substring(line.IndexOf(':') + 1).Trim();
                        SessionIdTextBox.Text = sessionId;
                        Debug.WriteLine($"[INPUT SESSION ID] Session ID caricato: {sessionId}");
                        return;
                    }
                }

                Debug.WriteLine("[INPUT SESSION ID] Session ID non trovato nel file");
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[INPUT SESSION ID] ERRORE lettura file: {ex.Message}");
            }
        }

        private void ClearButton_Click(object sender, RoutedEventArgs e)
        {
            Debug.WriteLine("╔════════════════════════════════════════════════════════╗");
            Debug.WriteLine("║   CLEAR BUTTON - CLICK RILEVATO                        ║");
            Debug.WriteLine("╚════════════════════════════════════════════════════════╝");

            SessionIdTextBox.Text = string.Empty;
            Debug.WriteLine("[INPUT SESSION ID] Session ID cancellato");
        }

        public string GetSessionId()
        {
            string sessionId = SessionIdTextBox.Text.Trim();
            Debug.WriteLine($"[INPUT SESSION ID] Session ID richiesto: {sessionId}");
            return sessionId;
        }
    }
}
using System;using System.Diagnostics;
using System.Diagnostics;
using System.Windows.Controls;
using AlertAutomator._01_latografico._01_livello1._01_tradingviewconfigurationman._01_chartid;
using AlertAutomator._01_latografico._01_livello1._01_tradingviewconfigurationman._02_sessionid;
using AlertAutomator._01_latografico._01_livello1._01_tradingviewconfigurationman._03_portfoliolink;

namespace AlertAutomator._01_latografico._01_livello1._01_tradingviewconfigurationman
{
    public partial class _00_tradingviewconfigurationman : UserControl
    {
        private _00_chartidmanager _chartIdManager;
        private _00_sessionidmanager _sessionIdManager;
        private _00_portfoliolinkmanager _portfolioLinkManager;

        public _00_tradingviewconfigurationman()
        {
            InitializeComponent();

            Debug.WriteLine("╔════════════════════════════════════════════════════════╗");
            Debug.WriteLine("║   TRADINGVIEW CONFIGURATION - INIZIALIZZAZIONE         ║");
            Debug.WriteLine("╚════════════════════════════════════════════════════════╝");

            CaricaComponenti();
        }

        private void CaricaComponenti()
        {
            try
            {
                Debug.WriteLine("╔════════════════════════════════════════════════════════╗");
                Debug.WriteLine("║   CHIAMO: 00_chartidmanager                            ║");
                Debug.WriteLine("╚════════════════════════════════════════════════════════╝");

                _chartIdManager = new _00_chartidmanager();
                ChartIdContainer.Content = _chartIdManager;
                Debug.WriteLine("[TRADINGVIEW CONFIG] Chart ID caricato");

                Debug.WriteLine("╔════════════════════════════════════════════════════════╗");
                Debug.WriteLine("║   CHIAMO: 00_sessionidmanager                          ║");
                Debug.WriteLine("╚════════════════════════════════════════════════════════╝");

                _sessionIdManager = new _00_sessionidmanager();
                SessionIdContainer.Content = _sessionIdManager;
                Debug.WriteLine("[TRADINGVIEW CONFIG] Session ID caricato");

                Debug.WriteLine("╔════════════════════════════════════════════════════════╗");
                Debug.WriteLine("║   CHIAMO: 00_portfoliolinkmanager                      ║");
                Debug.WriteLine("╚════════════════════════════════════════════════════════╝");

                _portfolioLinkManager = new _00_portfoliolinkmanager();
                PortfolioLinkContainer.Content = _portfolioLinkManager;
                Debug.WriteLine("[TRADINGVIEW CONFIG] Portfolio Link caricato");

                Debug.WriteLine("[TRADINGVIEW CONFIG] Tutti i componenti caricati");
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[TRADINGVIEW CONFIG] ERRORE: {ex.Message}");
            }
        }

        public _01_linkinput GetLinkInput()
        {
            return _portfolioLinkManager?.GetLinkInput();
        }
    }
}
using System;using System.Diagnostics;
using System.Diagnostics;
using System.Windows.Controls;

namespace AlertAutomator._01_latografico._01_livello1._03_racetelemetry._02_currenttab
{
    public partial class _01_indicatorecurrenttab : UserControl
    {
        public _01_indicatorecurrenttab()
        {
            InitializeComponent();

            Debug.WriteLine("╔════════════════════════════════════════════════════════╗");
            Debug.WriteLine("║   INDICATORE CURRENT TAB - INIZIALIZZAZIONE            ║");
            Debug.WriteLine("╚════════════════════════════════════════════════════════╝");

            Debug.WriteLine("[INDICATORE CURRENT TAB] Componente pronto");
        }

        public void AggiornaTab(string nomeTab)
        {
            TabNameText.Text = string.IsNullOrEmpty(nomeTab) ? "N/A" : nomeTab;
            Debug.WriteLine($"[INDICATORE CURRENT TAB] Tab aggiornato: {nomeTab}");
        }
    }
}
using System;using System.Diagnostics;
using System.Diagnostics;
using System.Windows.Controls;
using AlertAutomator._01_latografico._01_livello1._03_racetelemetry._02_currenttab;

namespace AlertAutomator._01_latografico._01_livello1._03_racetelemetry._02_currenttab
{
    public partial class _00_currenttab : UserControl
    {
        public _00_currenttab()
        {
            InitializeComponent();

            Debug.WriteLine("╔════════════════════════════════════════════════════════╗");
            Debug.WriteLine("║   CURRENT TAB - INIZIALIZZAZIONE                       ║");
            Debug.WriteLine("╚════════════════════════════════════════════════════════╝");

            CaricaIndicatore();
        }

        private void CaricaIndicatore()
        {
            try
            {
                Debug.WriteLine("╔════════════════════════════════════════════════════════╗");
                Debug.WriteLine("║   CHIAMO: 01_indicatorecurrenttab                      ║");
                Debug.WriteLine("╚════════════════════════════════════════════════════════╝");

                IndicatoreCurrentTabContainer.Content = new _01_indicatorecurrenttab();
                Debug.WriteLine("[CURRENT TAB] Indicatore caricato");
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[CURRENT TAB] ERRORE: {ex.Message}");
            }
        }
    }
}
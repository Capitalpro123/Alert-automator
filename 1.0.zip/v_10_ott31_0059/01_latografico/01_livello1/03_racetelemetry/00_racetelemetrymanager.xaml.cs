using System;using System.Diagnostics;
using System.Diagnostics;
using System.Windows.Controls;
using System.Windows.Media;
using AlertAutomator._01_latografico._01_livello1._03_racetelemetry._01_currentrow;
using AlertAutomator._01_latografico._01_livello1._03_racetelemetry._02_currenttab;

namespace AlertAutomator._01_latografico._01_livello1._03_racetelemetry
{
    public partial class _00_racetelemetrymanager : UserControl
    {
        public _00_racetelemetrymanager()
        {
            InitializeComponent();

            Debug.WriteLine("╔════════════════════════════════════════════════════════╗");
            Debug.WriteLine("║   RACE TELEMETRY MANAGER - INIZIALIZZAZIONE            ║");
            Debug.WriteLine("╚════════════════════════════════════════════════════════╝");

            CaricaComponenti();
        }

        private void CaricaComponenti()
        {
            try
            {
                Debug.WriteLine("╔════════════════════════════════════════════════════════╗");
                Debug.WriteLine("║   CHIAMO: 00_currentrowmanager                         ║");
                Debug.WriteLine("╚════════════════════════════════════════════════════════╝");

                CurrentRowContainer.Content = new _00_currentrowmanager();
                Debug.WriteLine("[RACE TELEMETRY] Current Row caricato");

                Debug.WriteLine("╔════════════════════════════════════════════════════════╗");
                Debug.WriteLine("║   CHIAMO: 00_currenttab                                ║");
                Debug.WriteLine("╚════════════════════════════════════════════════════════╝");

                CurrentTabContainer.Content = new _00_currenttab();
                Debug.WriteLine("[RACE TELEMETRY] Current Tab caricato");

                Debug.WriteLine("[RACE TELEMETRY] Tutti i componenti caricati");
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[RACE TELEMETRY] ERRORE: {ex.Message}");
            }
        }

        public void AggiornaStatus(string status, string colore)
        {
            StatusText.Text = status;
            
            switch (colore.ToLower())
            {
                case "verde":
                    StatusText.Foreground = new SolidColorBrush(Color.FromRgb(0, 255, 0));
                    break;
                case "giallo":
                    StatusText.Foreground = new SolidColorBrush(Color.FromRgb(255, 255, 0));
                    break;
                case "rosso":
                    StatusText.Foreground = new SolidColorBrush(Color.FromRgb(255, 68, 68));
                    break;
                default:
                    StatusText.Foreground = new SolidColorBrush(Color.FromRgb(136, 136, 136));
                    break;
            }

            Debug.WriteLine($"[RACE TELEMETRY] Status aggiornato: {status} ({colore})");
        }
    }
}
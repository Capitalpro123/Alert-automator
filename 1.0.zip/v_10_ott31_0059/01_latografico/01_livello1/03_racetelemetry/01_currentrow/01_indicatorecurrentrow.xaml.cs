using System;using System.Diagnostics;
using System.Diagnostics;
using System.Windows.Controls;

namespace AlertAutomator._01_latografico._01_livello1._03_racetelemetry._01_currentrow
{
    public partial class _01_indicatorecurrentrow : UserControl
    {
        public _01_indicatorecurrentrow()
        {
            InitializeComponent();

            Debug.WriteLine("╔════════════════════════════════════════════════════════╗");
            Debug.WriteLine("║   INDICATORE CURRENT ROW - INIZIALIZZAZIONE            ║");
            Debug.WriteLine("╚════════════════════════════════════════════════════════╝");

            Debug.WriteLine("[INDICATORE CURRENT ROW] Componente pronto");
        }

        public void AggiornaRiga(int numeroRiga)
        {
            RowNumberText.Text = numeroRiga.ToString();
            Debug.WriteLine($"[INDICATORE CURRENT ROW] Riga aggiornata: {numeroRiga}");
        }
    }
}
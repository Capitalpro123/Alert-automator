using System;using System.Diagnostics;
using System.Diagnostics;
using System.Windows.Controls;
using AlertAutomator._01_latografico._01_livello1._03_racetelemetry._01_currentrow;

namespace AlertAutomator._01_latografico._01_livello1._03_racetelemetry._01_currentrow
{
    public partial class _00_currentrowmanager : UserControl
    {
        public _00_currentrowmanager()
        {
            InitializeComponent();

            Debug.WriteLine("╔════════════════════════════════════════════════════════╗");
            Debug.WriteLine("║   CURRENT ROW MANAGER - INIZIALIZZAZIONE               ║");
            Debug.WriteLine("╚════════════════════════════════════════════════════════╝");

            CaricaIndicatore();
        }

        private void CaricaIndicatore()
        {
            try
            {
                Debug.WriteLine("╔════════════════════════════════════════════════════════╗");
                Debug.WriteLine("║   CHIAMO: 01_indicatorecurrentrow                      ║");
                Debug.WriteLine("╚════════════════════════════════════════════════════════╝");

                IndicatoreCurrentRowContainer.Content = new _01_indicatorecurrentrow();
                Debug.WriteLine("[CURRENT ROW MANAGER] Indicatore caricato");
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[CURRENT ROW MANAGER] ERRORE: {ex.Message}");
            }
        }
    }
}
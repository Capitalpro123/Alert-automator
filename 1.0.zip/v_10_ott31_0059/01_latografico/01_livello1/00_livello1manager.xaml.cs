using System;using System.Diagnostics;
using System.Diagnostics;
using System.Windows.Controls;
using AlertAutomator._01_latografico._01_livello1._01_tradingviewconfigurationman;
using AlertAutomator._01_latografico._01_livello1._02_startproductionmenu;
using AlertAutomator._01_latografico._01_livello1._03_racetelemetry;

namespace AlertAutomator._01_latografico._01_livello1
{
    public partial class _00_livello1manager : UserControl
    {
        private _00_tradingviewconfigurationman _tradingViewConfig;
        private _00_startproductionmenu _startProductionMenu;
        private _00_racetelemetrymanager _raceTelemetry;

        public _00_livello1manager()
        {
            InitializeComponent();

            Debug.WriteLine("╔════════════════════════════════════════════════════════╗");
            Debug.WriteLine("║   LIVELLO 1 MANAGER - INIZIALIZZAZIONE                 ║");
            Debug.WriteLine("╚════════════════════════════════════════════════════════╝");

            CaricaComponenti();
        }

        private void CaricaComponenti()
        {
            try
            {
                Debug.WriteLine("╔════════════════════════════════════════════════════════╗");
                Debug.WriteLine("║   CHIAMO: 00_tradingviewconfigurationman               ║");
                Debug.WriteLine("╚════════════════════════════════════════════════════════╝");
                _tradingViewConfig = new _00_tradingviewconfigurationman();
                TradingViewConfigContainer.Content = _tradingViewConfig;
                Debug.WriteLine("[LIVELLO 1] TradingView Configuration caricato");

                Debug.WriteLine("╔════════════════════════════════════════════════════════╗");
                Debug.WriteLine("║   CHIAMO: 00_startproductionmenu                       ║");
                Debug.WriteLine("╚════════════════════════════════════════════════════════╝");
                _startProductionMenu = new _00_startproductionmenu();
                StartProductionContainer.Content = _startProductionMenu;
                Debug.WriteLine("[LIVELLO 1] Start Production Menu caricato");

                Debug.WriteLine("╔════════════════════════════════════════════════════════╗");
                Debug.WriteLine("║   CHIAMO: 00_racetelemetrymanager                      ║");
                Debug.WriteLine("╚════════════════════════════════════════════════════════╝");
                _raceTelemetry = new _00_racetelemetrymanager();
                RaceTelemetryContainer.Content = _raceTelemetry;
                Debug.WriteLine("[LIVELLO 1] Race Telemetry caricato");
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[LIVELLO 1] ERRORE: {ex.Message}");
            }
        }
    }
}
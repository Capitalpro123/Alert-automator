// 01_menutendinaStopR.xaml.cs
using System;using System.Diagnostics;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace AlertAutomator._01_latografico._01_livello1._02_startproductionmenu._03_selectstoprow
{
    public partial class _01_menutendinaStopR : UserControl
    {
        private Dictionary<string, int> _rowMapping = new Dictionary<string, int>();

        public _01_menutendinaStopR()
        {
            InitializeComponent();

            Debug.WriteLine("╔════════════════════════════════════════════════════════╗");
            Debug.WriteLine("║   MENU TENDINA STOP ROW - INIZIALIZZAZIONE             ║");
            Debug.WriteLine("╚════════════════════════════════════════════════════════╝");

            CaricaRigheDaPortfolio();
        }

        private void CaricaRigheDaPortfolio()
        {
            try
            {
                Debug.WriteLine("[MENU TENDINA STOP ROW] Inizio caricamento righe");

                string percorsoFile = @"C:\00_CapitalproCEOmanagement\01_dipartimentooperativo\01_Capitalproapp\01_appsingole\03_Alert Automator\txtdilavoro.txt";
                Debug.WriteLine($"[MENU TENDINA STOP ROW] Percorso file: {percorsoFile}");

                if (!File.Exists(percorsoFile))
                {
                    Debug.WriteLine("[MENU TENDINA STOP ROW] ERRORE: File di lavoro non trovato");
                    return;
                }

                string[] righe = File.ReadAllLines(percorsoFile);
                string linkPortfolio = null;

                foreach (var riga in righe)
                {
                    if (riga.Trim().StartsWith("linkportfolio:", StringComparison.OrdinalIgnoreCase))
                    {
                        linkPortfolio = riga.Substring(riga.IndexOf(':') + 1).Trim();
                        Debug.WriteLine($"[MENU TENDINA STOP ROW] Link portfolio trovato: {linkPortfolio}");
                        break;
                    }
                }

                if (string.IsNullOrEmpty(linkPortfolio))
                {
                    Debug.WriteLine("[MENU TENDINA STOP ROW] ERRORE: Link portfolio non trovato");
                    return;
                }

                string spreadsheetId = EstraiSpreadsheetId(linkPortfolio);
                if (string.IsNullOrEmpty(spreadsheetId))
                {
                    Debug.WriteLine("[MENU TENDINA STOP ROW] ERRORE: Impossibile estrarre spreadsheet ID");
                    return;
                }

                Debug.WriteLine($"[MENU TENDINA STOP ROW] Spreadsheet ID estratto: {spreadsheetId}");

                var tabs = OttieniTabsDaGoogleSheets(spreadsheetId);
                if (tabs == null || tabs.Length == 0)
                {
                    Debug.WriteLine("[MENU TENDINA STOP ROW] ERRORE: Nessun tab trovato");
                    return;
                }

                string primoTab = tabs[0];
                Debug.WriteLine($"[MENU TENDINA STOP ROW] Utilizzo primo tab: {primoTab}");

                var colonnaF = OttieniColonnaF(spreadsheetId, primoTab);
                if (colonnaF == null || colonnaF.Count == 0)
                {
                    Debug.WriteLine("[MENU TENDINA STOP ROW] ERRORE: Colonna F vuota");
                    return;
                }

                StopRowComboBox.Items.Clear();
                StopRowComboBox.Items.Add("-- Select Stop Row --");
                _rowMapping.Clear();

                int numeroRiga = 2;
                foreach (var contenuto in colonnaF)
                {
                    if (!string.IsNullOrWhiteSpace(contenuto))
                    {
                        string displayText = $"{numeroRiga} - {contenuto}";
                        StopRowComboBox.Items.Add(displayText);
                        _rowMapping[displayText] = numeroRiga;
                        Debug.WriteLine($"[MENU TENDINA STOP ROW] Riga aggiunta: {displayText}");
                    }
                    numeroRiga++;
                }

                StopRowComboBox.SelectedIndex = 0;
                Debug.WriteLine("[MENU TENDINA STOP ROW] Caricamento completato");
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[MENU TENDINA STOP ROW] ERRORE caricamento: {ex.Message}");
                Debug.WriteLine($"[MENU TENDINA STOP ROW] StackTrace: {ex.StackTrace}");
            }
        }

        private string EstraiSpreadsheetId(string url)
        {
            try
            {
                if (url.Contains("/spreadsheets/d/"))
                {
                    int startIndex = url.IndexOf("/spreadsheets/d/") + "/spreadsheets/d/".Length;
                    int endIndex = url.IndexOf("/", startIndex);
                    
                    string id = endIndex > startIndex 
                        ? url.Substring(startIndex, endIndex - startIndex)
                        : url.Substring(startIndex);

                    return id;
                }
                return null;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[MENU TENDINA STOP ROW] ERRORE estrazione ID: {ex.Message}");
                return null;
            }
        }

        private string[] OttieniTabsDaGoogleSheets(string spreadsheetId)
        {
            try
            {
                string credentialsPath = @"C:\00_CapitalproCEOmanagement\01_dipartimentooperativo\01_Capitalproapp\01_appsingole\03_Alert Automator\capitaljournal-6a007d9b9bd1.json";

                if (!File.Exists(credentialsPath))
                {
                    Debug.WriteLine("[MENU TENDINA STOP ROW] ERRORE: File credentials non trovato");
                    return null;
                }

                var credential = Google.Apis.Auth.OAuth2.GoogleCredential
                    .FromFile(credentialsPath)
                    .CreateScoped(Google.Apis.Sheets.v4.SheetsService.Scope.SpreadsheetsReadonly);

                var service = new Google.Apis.Sheets.v4.SheetsService(
                    new Google.Apis.Services.BaseClientService.Initializer
                    {
                        HttpClientInitializer = credential,
                        ApplicationName = "Alert Automator"
                    });

                var spreadsheet = service.Spreadsheets.Get(spreadsheetId).Execute();
                return spreadsheet.Sheets.Select(sheet => sheet.Properties.Title).ToArray();
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[MENU TENDINA STOP ROW] ERRORE Google Sheets: {ex.Message}");
                return null;
            }
        }

        private List<string> OttieniColonnaF(string spreadsheetId, string tabName)
        {
            try
            {
                string credentialsPath = @"C:\00_CapitalproCEOmanagement\01_dipartimentooperativo\01_Capitalproapp\01_appsingole\03_Alert Automator\capitaljournal-6a007d9b9bd1.json";

                var credential = Google.Apis.Auth.OAuth2.GoogleCredential
                    .FromFile(credentialsPath)
                    .CreateScoped(Google.Apis.Sheets.v4.SheetsService.Scope.SpreadsheetsReadonly);

                var service = new Google.Apis.Sheets.v4.SheetsService(
                    new Google.Apis.Services.BaseClientService.Initializer
                    {
                        HttpClientInitializer = credential,
                        ApplicationName = "Alert Automator"
                    });

                string range = $"{tabName}!F2:F1000";
                var request = service.Spreadsheets.Values.Get(spreadsheetId, range);
                var response = request.Execute();

                var risultato = new List<string>();
                if (response?.Values != null)
                {
                    foreach (var row in response.Values)
                    {
                        risultato.Add(row.Count > 0 ? row[0]?.ToString() ?? "" : "");
                    }
                }

                Debug.WriteLine($"[MENU TENDINA STOP ROW] Colonna F letta: {risultato.Count} righe");
                return risultato;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[MENU TENDINA STOP ROW] ERRORE lettura colonna F: {ex.Message}");
                return new List<string>();
            }
        }

        private void StopRowComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (StopRowComboBox.SelectedIndex > 0 && StopRowComboBox.SelectedItem is string selectedText)
            {
                Debug.WriteLine($"[MENU TENDINA STOP ROW] Riga selezionata: {selectedText}");
            }
        }

        public int GetStopRow()
        {
            if (StopRowComboBox.SelectedIndex > 0 && StopRowComboBox.SelectedItem is string selectedText)
            {
                if (_rowMapping.ContainsKey(selectedText))
                {
                    int row = _rowMapping[selectedText];
                    Debug.WriteLine($"[MENU TENDINA STOP ROW] Riga richiesta: {row}");
                    return row;
                }
            }

            Debug.WriteLine("[MENU TENDINA STOP ROW] Nessuna riga selezionata, ritorno 2");
            return 2;
        }
    }
}
using System;using System.Diagnostics;
using System.Diagnostics;
using System.Windows.Controls;

namespace AlertAutomator._01_latografico._01_livello1._02_startproductionmenu._01_selecttab
{
    public partial class _01_selecttabmanager : UserControl
    {
        private _02_menutendinaselecttab _menuTendina;

        public _01_selecttabmanager()
        {
            InitializeComponent();

            Debug.WriteLine("╔════════════════════════════════════════════════════════╗");
            Debug.WriteLine("║   SELECT TAB MANAGER - INIZIALIZZAZIONE                ║");
            Debug.WriteLine("╚════════════════════════════════════════════════════════╝");

            CaricaMenu();
        }

        private void CaricaMenu()
        {
            try
            {
                Debug.WriteLine("╔════════════════════════════════════════════════════════╗");
                Debug.WriteLine("║   CHIAMO: 02_menutendinaselecttab                      ║");
                Debug.WriteLine("╚════════════════════════════════════════════════════════╝");

                _menuTendina = new _02_menutendinaselecttab();
                MenuTendinaSelectTabContainer.Content = _menuTendina;

                Debug.WriteLine("[SELECT TAB MANAGER] Menu tendina caricato");
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[SELECT TAB MANAGER] ERRORE: {ex.Message}");
            }
        }
    }
}
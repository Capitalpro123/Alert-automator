// 02_menutendinaselecttab.xaml.cs
using System;using System.Diagnostics;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace AlertAutomator._01_latografico._01_livello1._02_startproductionmenu._01_selecttab
{
    public partial class _02_menutendinaselecttab : UserControl
    {
        public _02_menutendinaselecttab()
        {
            InitializeComponent();

            Debug.WriteLine("╔════════════════════════════════════════════════════════╗");
            Debug.WriteLine("║   MENU TENDINA SELECT TAB - INIZIALIZZAZIONE           ║");
            Debug.WriteLine("╚════════════════════════════════════════════════════════╝");

            CaricaTabsDaPortfolio();
        }

        private void CaricaTabsDaPortfolio()
        {
            try
            {
                Debug.WriteLine("[MENU TENDINA SELECT TAB] Inizio caricamento tabs");

                string percorsoFile = @"C:\00_CapitalproCEOmanagement\01_dipartimentooperativo\01_Capitalproapp\01_appsingole\03_Alert Automator\txtdilavoro.txt";
                Debug.WriteLine($"[MENU TENDINA SELECT TAB] Percorso file: {percorsoFile}");

                if (!File.Exists(percorsoFile))
                {
                    Debug.WriteLine("[MENU TENDINA SELECT TAB] ERRORE: File di lavoro non trovato");
                    return;
                }

                Debug.WriteLine("[MENU TENDINA SELECT TAB] File di lavoro trovato");

                string[] righe = File.ReadAllLines(percorsoFile);
                Debug.WriteLine($"[MENU TENDINA SELECT TAB] Righe totali nel file: {righe.Length}");

                string linkPortfolio = null;
                foreach (var riga in righe)
                {
                    if (riga.Trim().StartsWith("linkportfolio:", StringComparison.OrdinalIgnoreCase))
                    {
                        linkPortfolio = riga.Substring(riga.IndexOf(':') + 1).Trim();
                        Debug.WriteLine($"[MENU TENDINA SELECT TAB] Link portfolio trovato: {linkPortfolio}");
                        break;
                    }
                }

                if (string.IsNullOrEmpty(linkPortfolio))
                {
                    Debug.WriteLine("[MENU TENDINA SELECT TAB] ERRORE: Link portfolio non trovato nel file");
                    return;
                }

                string spreadsheetId = EstraiSpreadsheetId(linkPortfolio);
                if (string.IsNullOrEmpty(spreadsheetId))
                {
                    Debug.WriteLine("[MENU TENDINA SELECT TAB] ERRORE: Impossibile estrarre spreadsheet ID");
                    return;
                }

                Debug.WriteLine($"[MENU TENDINA SELECT TAB] Spreadsheet ID estratto: {spreadsheetId}");

                var tabs = OttieniTabsDaGoogleSheets(spreadsheetId);

                if (tabs == null || tabs.Length == 0)
                {
                    Debug.WriteLine("[MENU TENDINA SELECT TAB] ERRORE: Nessun tab trovato");
                    return;
                }

                Debug.WriteLine($"[MENU TENDINA SELECT TAB] Tabs trovati: {tabs.Length}");

                TabComboBox.Items.Clear();
                TabComboBox.Items.Add("-- Select Tab --");

                foreach (var tab in tabs)
                {
                    TabComboBox.Items.Add(tab);
                    Debug.WriteLine($"[MENU TENDINA SELECT TAB] Tab aggiunto: {tab}");
                }

                TabComboBox.SelectedIndex = 0;
                Debug.WriteLine("[MENU TENDINA SELECT TAB] Caricamento completato");
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[MENU TENDINA SELECT TAB] ERRORE caricamento: {ex.Message}");
                Debug.WriteLine($"[MENU TENDINA SELECT TAB] StackTrace: {ex.StackTrace}");
            }
        }

        private string EstraiSpreadsheetId(string url)
        {
            try
            {
                Debug.WriteLine($"[MENU TENDINA SELECT TAB] Estrazione ID da URL: {url}");

                if (url.Contains("/spreadsheets/d/"))
                {
                    int startIndex = url.IndexOf("/spreadsheets/d/") + "/spreadsheets/d/".Length;
                    int endIndex = url.IndexOf("/", startIndex);
                    
                    string id = endIndex > startIndex 
                        ? url.Substring(startIndex, endIndex - startIndex)
                        : url.Substring(startIndex);

                    Debug.WriteLine($"[MENU TENDINA SELECT TAB] ID estratto: {id}");
                    return id;
                }

                Debug.WriteLine("[MENU TENDINA SELECT TAB] ERRORE: Formato URL non valido");
                return null;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[MENU TENDINA SELECT TAB] ERRORE estrazione ID: {ex.Message}");
                return null;
            }
        }

        private string[] OttieniTabsDaGoogleSheets(string spreadsheetId)
        {
            try
            {
                Debug.WriteLine($"[MENU TENDINA SELECT TAB] Connessione a Google Sheets: {spreadsheetId}");

                string credentialsPath = @"C:\00_CapitalproCEOmanagement\01_dipartimentooperativo\01_Capitalproapp\01_appsingole\03_Alert Automator\capitaljournal-6a007d9b9bd1.json";
                Debug.WriteLine($"[MENU TENDINA SELECT TAB] Percorso credentials: {credentialsPath}");

                if (!File.Exists(credentialsPath))
                {
                    Debug.WriteLine("[MENU TENDINA SELECT TAB] ERRORE: File credentials.json non trovato");
                    return null;
                }

                var credential = Google.Apis.Auth.OAuth2.GoogleCredential
                    .FromFile(credentialsPath)
                    .CreateScoped(Google.Apis.Sheets.v4.SheetsService.Scope.SpreadsheetsReadonly);

                Debug.WriteLine("[MENU TENDINA SELECT TAB] Credenziali caricate");

                var service = new Google.Apis.Sheets.v4.SheetsService(
                    new Google.Apis.Services.BaseClientService.Initializer
                    {
                        HttpClientInitializer = credential,
                        ApplicationName = "Alert Automator"
                    });

                Debug.WriteLine("[MENU TENDINA SELECT TAB] Servizio Google Sheets inizializzato");

                var spreadsheet = service.Spreadsheets.Get(spreadsheetId).Execute();
                Debug.WriteLine($"[MENU TENDINA SELECT TAB] Spreadsheet recuperato: {spreadsheet.Properties.Title}");

                var tabs = spreadsheet.Sheets
                    .Select(sheet => sheet.Properties.Title)
                    .ToArray();

                Debug.WriteLine($"[MENU TENDINA SELECT TAB] Tabs estratti: {string.Join(", ", tabs)}");

                return tabs;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[MENU TENDINA SELECT TAB] ERRORE Google Sheets: {ex.Message}");
                Debug.WriteLine($"[MENU TENDINA SELECT TAB] StackTrace: {ex.StackTrace}");
                return null;
            }
        }

        private void TabComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (TabComboBox.SelectedIndex > 0 && TabComboBox.SelectedItem is string tabName)
            {
                Debug.WriteLine($"[MENU TENDINA SELECT TAB] Tab selezionato: {tabName}");
            }
        }

        public string GetTabSelezionata()
        {
            if (TabComboBox.SelectedIndex > 0 && TabComboBox.SelectedItem is string tab)
            {
                Debug.WriteLine($"[MENU TENDINA SELECT TAB] Tab richiesta: {tab}");
                return tab;
            }

            Debug.WriteLine("[MENU TENDINA SELECT TAB] Nessun tab selezionato");
            return null;
        }
    }
}
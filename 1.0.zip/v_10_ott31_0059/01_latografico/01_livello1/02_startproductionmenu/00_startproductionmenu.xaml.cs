using System;using System.Diagnostics;
using System.Diagnostics;
using System.Windows.Controls;
using AlertAutomator._01_latografico._01_livello1._02_startproductionmenu._01_selecttab;
using AlertAutomator._01_latografico._01_livello1._02_startproductionmenu._02_selectstartrow;
using AlertAutomator._01_latografico._01_livello1._02_startproductionmenu._03_selectstoprow;
using AlertAutomator._01_latografico._01_livello1._02_startproductionmenu._04_buttonstartrace;

namespace AlertAutomator._01_latografico._01_livello1._02_startproductionmenu
{
    public partial class _00_startproductionmenu : UserControl
    {
        private _01_selecttabmanager _selectTabManager;
        private _00_selectstartrowmanager _selectStartRowManager;
        private _00_selectstoprowmanager _selectStopRowManager;
        private _00_buttonstartracemanager _buttonStartRaceManager;

        public _00_startproductionmenu()
        {
            InitializeComponent();

            Debug.WriteLine("╔════════════════════════════════════════════════════════╗");
            Debug.WriteLine("║   START PRODUCTION MENU - INIZIALIZZAZIONE             ║");
            Debug.WriteLine("╚════════════════════════════════════════════════════════╝");

            CaricaComponenti();
        }

        private void CaricaComponenti()
        {
            try
            {
                Debug.WriteLine("╔════════════════════════════════════════════════════════╗");
                Debug.WriteLine("║   CHIAMO: 01_selecttabmanager                          ║");
                Debug.WriteLine("╚════════════════════════════════════════════════════════╝");
                _selectTabManager = new _01_selecttabmanager();
                SelectTabContainer.Content = _selectTabManager;
                Debug.WriteLine("[START PRODUCTION MENU] Select Tab caricato");

                Debug.WriteLine("╔════════════════════════════════════════════════════════╗");
                Debug.WriteLine("║   CHIAMO: 00_selectstartrowmanager                     ║");
                Debug.WriteLine("╚════════════════════════════════════════════════════════╝");
                _selectStartRowManager = new _00_selectstartrowmanager();
                SelectStartRowContainer.Content = _selectStartRowManager;
                Debug.WriteLine("[START PRODUCTION MENU] Select Start Row caricato");

                Debug.WriteLine("╔════════════════════════════════════════════════════════╗");
                Debug.WriteLine("║   CHIAMO: 00_selectstoprowmanager                      ║");
                Debug.WriteLine("╚════════════════════════════════════════════════════════╝");
                _selectStopRowManager = new _00_selectstoprowmanager();
                SelectStopRowContainer.Content = _selectStopRowManager;
                Debug.WriteLine("[START PRODUCTION MENU] Select Stop Row caricato");

                Debug.WriteLine("╔════════════════════════════════════════════════════════╗");
                Debug.WriteLine("║   CHIAMO: 00_buttonstartracemanager                    ║");
                Debug.WriteLine("╚════════════════════════════════════════════════════════╝");
                _buttonStartRaceManager = new _00_buttonstartracemanager();
                ButtonStartRaceContainer.Content = _buttonStartRaceManager;
                Debug.WriteLine("[START PRODUCTION MENU] Button Start Race caricato");
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[START PRODUCTION MENU] ERRORE: {ex.Message}");
            }
        }
    }
}
using System;using System.Diagnostics;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;

namespace AlertAutomator._01_latografico._01_livello1._02_startproductionmenu._04_buttonstartrace
{
    public partial class _01_bottonestart : UserControl
    {
        public _01_bottonestart()
        {
            InitializeComponent();

            Debug.WriteLine("╔════════════════════════════════════════════════════════╗");
            Debug.WriteLine("║   BOTTONE START - INIZIALIZZAZIONE                     ║");
            Debug.WriteLine("╚════════════════════════════════════════════════════════╝");

            Debug.WriteLine("[BOTTONE START] Componente pronto");
        }

        private async void StartRaceButton_Click(object sender, RoutedEventArgs e)
        {
            Debug.WriteLine("╔════════════════════════════════════════════════════════╗");
            Debug.WriteLine("║   START RACE - CLICK RILEVATO                          ║");
            Debug.WriteLine("╚════════════════════════════════════════════════════════╝");

            // Chiamare engine automazione
            Debug.WriteLine("[BOTTONE START] Chiamando RiceviClickDaUI.Esegui()");

            bool risultato = await AlertAutomator._02_LatoFunzioni._02_EngineAutomation.RiceviClickDaUI.Esegui();

            if (risultato)
            {
                Debug.WriteLine("[BOTTONE START] Automazione completata con successo");
            }
            else
            {
                Debug.WriteLine("[BOTTONE START] Automazione fallita");
            }
        }


        public void SetEnabled(bool enabled)
        {
            StartRaceButton.IsEnabled = enabled;
            StartRaceButton.Opacity = enabled ? 1.0 : 0.5;
            Debug.WriteLine($"[BOTTONE START] Stato button: {(enabled ? "Abilitato" : "Disabilitato")}");
        }
    }
}
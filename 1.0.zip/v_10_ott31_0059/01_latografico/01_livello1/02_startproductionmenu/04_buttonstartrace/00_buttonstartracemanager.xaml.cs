using System;using System.Diagnostics;
using System.Diagnostics;
using System.Windows.Controls;
using AlertAutomator._01_latografico._01_livello1._02_startproductionmenu._04_buttonstartrace;

namespace AlertAutomator._01_latografico._01_livello1._02_startproductionmenu._04_buttonstartrace
{
    public partial class _00_buttonstartracemanager : UserControl
    {
        public _00_buttonstartracemanager()
        {
            InitializeComponent();

            Debug.WriteLine("╔════════════════════════════════════════════════════════╗");
            Debug.WriteLine("║   BUTTON START RACE MANAGER - INIZIALIZZAZIONE         ║");
            Debug.WriteLine("╚════════════════════════════════════════════════════════╝");

            CaricaBottone();
        }

        private void CaricaBottone()
        {
            try
            {
                Debug.WriteLine("╔════════════════════════════════════════════════════════╗");
                Debug.WriteLine("║   CHIAMO: 01_bottonestart                              ║");
                Debug.WriteLine("╚════════════════════════════════════════════════════════╝");

                BottoneStartContainer.Content = new _01_bottonestart();
                Debug.WriteLine("[BUTTON START RACE MANAGER] Bottone Start caricato");
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[BUTTON START RACE MANAGER] ERRORE: {ex.Message}");
            }
        }
    }
}
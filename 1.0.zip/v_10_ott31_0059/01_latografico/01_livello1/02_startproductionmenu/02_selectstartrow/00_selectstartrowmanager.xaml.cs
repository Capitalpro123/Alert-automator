using System;using System.Diagnostics;
using System.Diagnostics;
using System.Windows.Controls;
using AlertAutomator._01_latografico._01_livello1._02_startproductionmenu._02_selectstartrow;

namespace AlertAutomator._01_latografico._01_livello1._02_startproductionmenu._02_selectstartrow
{
    public partial class _00_selectstartrowmanager : UserControl
    {
        private _01_menutendinaStartR _menuTendina;

        public _00_selectstartrowmanager()
        {
            InitializeComponent();

            Debug.WriteLine("╔════════════════════════════════════════════════════════╗");
            Debug.WriteLine("║   SELECT START ROW MANAGER - INIZIALIZZAZIONE          ║");
            Debug.WriteLine("╚════════════════════════════════════════════════════════╝");

            CaricaMenu();
        }

        private void CaricaMenu()
        {
            try
            {
                Debug.WriteLine("╔════════════════════════════════════════════════════════╗");
                Debug.WriteLine("║   CHIAMO: 01_menutendinaStartR                         ║");
                Debug.WriteLine("╚════════════════════════════════════════════════════════╝");

                _menuTendina = new _01_menutendinaStartR();
                MenuTendinaStartRContainer.Content = _menuTendina;
                Debug.WriteLine("[SELECT START ROW MANAGER] Menu Start Row caricato");
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[SELECT START ROW MANAGER] ERRORE: {ex.Message}");
            }
        }

      
    }
}
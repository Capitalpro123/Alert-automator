using System;using System.Diagnostics;
using System.Diagnostics;
using System.Windows.Controls;
using AlertAutomator._01_latografico._01_livello1;
using AlertAutomator._01_latografico._02_livello2;

namespace AlertAutomator._01_latografico
{
    public partial class _00_contenitoreprincipale : UserControl
    {
        public _00_contenitoreprincipale()
        {
            InitializeComponent();

            Debug.WriteLine("╔════════════════════════════════════════════════════════╗");
            Debug.WriteLine("║   CONTENITORE PRINCIPALE - INIZIALIZZAZIONE            ║");
            Debug.WriteLine("╚════════════════════════════════════════════════════════╝");

            CaricaLivelli();
        }

        private void CaricaLivelli()
        {
            try
            {
                Debug.WriteLine("╔════════════════════════════════════════════════════════╗");
                Debug.WriteLine("║   CHIAMO: 00_livello1manager                           ║");
                Debug.WriteLine("╚════════════════════════════════════════════════════════╝");

                Livello1Container.Content = new _00_livello1manager();
                Debug.WriteLine("[CONTENITORE PRINCIPALE] Livello 1 caricato");

                Debug.WriteLine("╔════════════════════════════════════════════════════════╗");
                Debug.WriteLine("║   CHIAMO: 00_livello2manager                           ║");
                Debug.WriteLine("╚════════════════════════════════════════════════════════╝");

                Livello2Container.Content = new _00_livello2manager();
                Debug.WriteLine("[CONTENITORE PRINCIPALE] Livello 2 caricato");

                Debug.WriteLine("[CONTENITORE PRINCIPALE] Setup completo");
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[CONTENITORE PRINCIPALE] ERRORE: {ex.Message}");
            }
        }
    }
}
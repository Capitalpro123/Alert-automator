using System;using System.Diagnostics;
using System.Diagnostics;
using System.Windows;
using AlertAutomator._01_latografico;

namespace AlertAutomator
{
    public class PuntoIngresso
    {
        [STAThread]
        public static void Main()
        {
            Debug.WriteLine("╔════════════════════════════════════════════════════════╗");
            Debug.WriteLine("║   PUNTO INGRESSO - AVVIO APPLICAZIONE                  ║");
            Debug.WriteLine("╚════════════════════════════════════════════════════════╝");

            try
            {
                var app = new Application();
                
                // Crea finestra principale
                var finestra = new Window
                {
                    Title = "Alert Automator v3.5",
                    Width = 1920,
                    Height = 2000,
                    WindowState = WindowState.Maximized,
                    WindowStartupLocation = WindowStartupLocation.CenterScreen,
                    Background = System.Windows.Media.Brushes.Black
                };

                Debug.WriteLine("╔════════════════════════════════════════════════════════╗");
                Debug.WriteLine("║   CHIAMO: 00_contenitoreprincipale                     ║");
                Debug.WriteLine("╚════════════════════════════════════════════════════════╝");

                // Carica contenitore principale
                finestra.Content = new _00_contenitoreprincipale();

                Debug.WriteLine("[PUNTO INGRESSO] Finestra configurata: 1920x1080 Maximized");
                Debug.WriteLine("[PUNTO INGRESSO] Contenitore principale caricato");

                // Mostra finestra
                app.Run(finestra);
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[PUNTO INGRESSO] ERRORE FATALE: {ex.Message}");
                Debug.WriteLine($"[PUNTO INGRESSO] Stack: {ex.StackTrace}");
                MessageBox.Show($"Errore critico: {ex.Message}", "Errore", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}